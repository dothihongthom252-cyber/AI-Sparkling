---
name: ggs-Alibaba-B2B-Expert-html
description: |
  Industry-adaptive Alibaba.com B2B market intelligence and global export strategy skill for Vietnam manufacturers, exporters, and B2B brands.

  When to Use:
    - Alibaba market reports for any requested industry
    - Vietnam export analysis for any requested industry
    - Supplier landscape research on Alibaba.com
    - Supplier list Alibaba / Alibaba supplier analysis
    - Competitor benchmarking and factory benchmark analysis
    - Pricing intelligence, MOQ analysis, lead-time comparison
    - SEO keyword mapping for Alibaba.com listings
    - Product trend analysis and product benchmark reports
    - Product image benchmark analysis
    - Premium interactive HTML export reports using the provided reference template
    - DOCX export reports using a provided or inferred template structure
    - Vietnamese requests: bao cao thi truong Alibaba, phan tich xuat khau, nghien cuu nganh hang, phan tich doi thu, phan tich supplier, bao cao B2B, bao cao HTML, bao cao xuat khau

  Core Rule:
    - Always identify the user's requested industry first.
    - Treat the bundled ceramics report as a reference sample for structure, depth, visual style, and analysis quality only.
    - Do not restrict reports to ceramics.
    - For every requested industry, build a fresh industry profile, benchmark logic, pricing logic, SEO map, and export strategy.
    - Default report mode is full-intelligence-report.
    - Default HTML style is premium-visual.
    - Every completed report must be exported as an HTML file unless the user explicitly requests another format only.
enabled: true
---

# B2B Market Intelligence Pro

Industry-adaptive Alibaba.com export intelligence toolkit for Vietnam suppliers. Use it to create full supplier research, competitor benchmarking, pricing intelligence, SEO maps, product benchmarks, image benchmarks, and export strategy reports for whichever industry the user requests.

The bundled ceramics HTML is a finished sample report. It is not the only supported industry and must not cause the agent to force every task into ceramics.

Default deliverable: a premium responsive HTML report file. Do not finish a report-generation task with only chat text when file creation is available.

---

## Part 1: Industry Profile Builder

### Core Principle

Build a fresh industry profile for every requested industry. The user may ask for furniture, apparel, food, handicrafts, packaging, machinery, beauty, home decor, agricultural products, or any other export category. The agent must adapt the report to that industry instead of using a fixed industry pack.

### Reference Sample Role

| File | Role | Important Rule |
|------|------|----------------|
| `b2b-reports/Bao_cao_mau_Alibaba.html` | Workspace sample export template | If this file exists in the workspace it becomes the primary concrete export template — replace placeholders with industry data and save outputs to `b2b-reports/` |
| `assets/templates/Gom_su_VietNam.html` | Reference sample for premium HTML structure, visual density, section depth, dashboard layout, table style, and analysis quality | Use as a visual model to adapt, not as a ceramics-only constraint |

### Industry Identification Flow

| Step | Action |
|------|--------|
| 1 | Identify the requested industry AND language AND origin country from the user prompt. Language = same as prompt language. Origin = specified country or default Vietnam |
| 2 | Create an industry slug, e.g. `noi-that-viet-nam`, `may-mac-viet-nam`, `thu-cong-my-nghe-viet-nam` |
| 3 | Define the product taxonomy for that industry |
| 4 | Define benchmark criteria specific to that industry |
| 5 | Define pricing units, MOQ logic, and sourcing assumptions for that industry |
| 6 | Define compliance/certification topics relevant to that industry |
| 7 | Define SEO keyword themes and buyer-intent keywords for that industry |
| 8 | Generate the report using the premium reference structure, replacing all sample data with verified data for the requested industry |

### Dynamic Industry Profile Schema

For every report, create this mental profile before writing:

| Field | Required Content |
|-------|------------------|
| Industry slug | Lowercase identifier for the requested industry |
| Product scope | Exact product categories covered in the report |
| Target buyers | Importers, wholesalers, retailers, distributors, brands, hotels, factories, or project buyers |
| Supplier benchmark criteria | Industry-specific credibility, capability, product, quality, and export-readiness factors |
| Product benchmark criteria | Materials, design, use cases, variants, customization, packaging, visuals, and claims |
| Pricing units | Units that make sense for the industry, such as piece, set, kg, ton, carton, sqm, cbm, container |
| MOQ logic | How MOQ is normally expressed and compared in the industry |
| Compliance focus | Certifications, safety rules, documentation, and restricted claims that are relevant and visible |
| SEO themes | Core product, material, process, origin, buyer-intent, and target-market keywords |
| Export strategy angle | Positioning, product focus, Alibaba listing strategy, RFQ strategy, sample strategy, risk controls |

### Example Industry Adaptation

If the user asks for furniture, do not use ceramics criteria. Build furniture criteria such as:

| Area | Furniture-Specific Logic |
|------|--------------------------|
| Product taxonomy | indoor furniture, outdoor furniture, wooden furniture, rattan furniture, hotel furniture, restaurant furniture, office furniture, bedroom/living/dining categories |
| Materials | solid wood, plywood, MDF, veneer, bamboo, rattan, metal frame, upholstery, foam, fabric, leather alternatives |
| Pricing units | piece, set, carton, cbm, container, FOB unit price if visible |
| MOQ | pieces, sets, mixed container, full container load when visible |
| Compliance | FSC, BSCI, ISO, CARB P2, TSCA Title VI, fire retardant, OEKO-TEX for upholstery only if visible |
| Benchmark | factory scale, OEM/ODM, project experience, packaging, KD/flat-pack capability, customization, export markets |
| SEO | Vietnam furniture supplier, wooden furniture manufacturer, custom hotel furniture, rattan outdoor furniture, OEM furniture factory |

---

## Part 2: Execution Modes

### Default Mode

Always use `full-intelligence-report` for report generation requests unless the user explicitly asks for a quick, simplified, or lightweight output.

Always use `premium-visual` as the default HTML style unless the user explicitly requests simple HTML.

### Mode Table

| Mode | Use When | Minimum Evidence | Output Depth |
|------|----------|------------------|--------------|
| `quick-analysis` | User explicitly asks for a fast snapshot | 3+ suppliers, 5+ products when available | Key findings, price corridor, risks, next actions |
| `standard-report` | User explicitly asks for a medium report | 5-10 suppliers, 10+ products when available | Supplier landscape, pricing, product benchmark, SEO map, strategy |
| `full-intelligence-report` | Default for reports, HTML, DOCX, dashboards, or competitor analysis | MUST include: 10+ suppliers, 20+ products, 10+ SEO keywords. If fewer exist on Alibaba, include ALL available and state the shortfall explicitly. | Full industry report, premium template-based HTML/DOCX, charts/tables, source list |

### Full-Intelligence Report Must Include

- Supplier landscape analysis.
- Competitor positioning analysis.
- Pricing intelligence tables.
- Product benchmark analysis.
- Factory benchmark analysis when data exists.
- Product image benchmark analysis when image/listing evidence exists.
- SEO keyword mapping.
- Buyer persona analysis.
- Channel strategy.
- Alibaba optimization recommendations.
- Export strategy recommendations.
- Market opportunity analysis.
- Risk analysis.
- Sourcing intelligence.
- Premium visual deliverables in requested formats.

### Supported Formats

| Format | Default Behavior |
|--------|------------------|
| Markdown | Use structured report sections and tables |
| Responsive HTML | Default required deliverable; use premium-visual template style |
| DOCX | Use template-first document structure when a DOCX template is available |

Do not downgrade to `quick-analysis`, `standard-report`, `simple-html`, or `advanced-interactive` unless the user explicitly requests a simplified output.

### HTML File Output Contract

For every report-generation request, create a physical `.html` file unless the user explicitly asks for Markdown-only, DOCX-only, or no file output.

| Requirement | Instruction |
|-------------|-------------|
| Output format | Always create a premium responsive HTML file by default |
| File naming | Use a readable industry slug, e.g. `Bao_cao_nganh_Noi_that_Alibaba.html`, `Bao_cao_nganh_May_mac_Alibaba.html` |
| Output folder | Prefer `b2b-reports/` in the current workspace or the platform-provided output directory |
| Output creation | Automatically create `b2b-reports/` if it does not exist and save the report there |
| Template | Use the workspace sample `b2b-reports/Bao_cao_mau_Alibaba.html` as the primary export template when available; otherwise use `assets/templates/Gom_su_VietNam.html` as the visual reference |
| Final response | Include the saved HTML file path and a short completion note |
| No silent completion | Do not stop after analysis; the task is complete only when the HTML file exists or the environment prevents file creation |

If the environment prevents writing files, explain the blocker and provide the complete HTML content as a fallback.

### Data Freshness and Export Contract

- Never reuse prior session or cached report content; rebuild every report from verified current sources.
- Verify that supplier links, product listings, prices, and certifications are refreshed for each new report.
- Automatically write the HTML report file as part of the final response flow, without requiring a separate manual save step.

---

## Part 3: Research Workflow

### Data Collection

1. Confirm or infer industry, product scope, origin country, target market, buyer segment, language, and output format.
2. Build the dynamic industry profile before writing.
3. Use `b2b-reports/Bao_cao_mau_Alibaba.html` as the concrete export template when present; otherwise use the ceramics visual reference `assets/templates/Gom_su_VietNam.html` as the premium visual model for output.
4. **Perform web searches and browse Alibaba.com** to collect real data. For EACH data type below, you MUST extract the specific information listed AND capture the exact source URL where it was found:

| Data Type | What to Extract | Where to Find | URL to Capture |
|-----------|----------------|---------------|----------------|
| **Suppliers** (Ch3) | Company name, store URL (`SUPPLIER.en.alibaba.com`), country, years on Alibaba, verification status, certifications, MOQ, price range, lead time, factory size, employee count, export markets | Alibaba supplier store pages, Alibaba search results | Store URL for EACH supplier (e.g., `https://supplier.en.alibaba.com`) |
| **Products** (Ch4) | Product title, image URL from `s.alicdn.com` CDN, FOB price range in USD, MOQ with unit, supplier name, product page URL (`alibaba.com/product-detail/...`) | Alibaba product listing pages, category pages | Product detail page URL for EACH product |
| **Pricing** (Ch5) | Price ranges per product category, FOB vs CIF pricing, price tiers by quantity, MOQ-based pricing, currency and Incoterms | Alibaba product pages, trade data sites | URL for EACH price data point |
| **Market data** (Ch1-2) | Market size (USD value), growth rate (% CAGR), export volume, demand trends, top importing countries, trade statistics, industry forecasts | Industry reports, trade databases, news articles, Alibaba market pages | URL for EACH statistic or claim |
| **Trade policy** (Ch7) | Trade agreements (EVFTA, CPTPP, RCEP), tariff rates, compliance requirements, certification standards (ISO, CE, FDA), restricted substances, documentation requirements | Government trade portals, customs databases, industry compliance sites | URL for EACH regulation or policy cited |
| **Keywords** (Ch6) | Search terms buyers use, search volume if available, keyword categories (core product, material, buyer-intent, origin, compliance), Alibaba search result URLs | Alibaba search bar autocomplete, Alibaba category pages, keyword tools | Alibaba search results URL for EACH keyword group |
| **Strategy sources** (Ch7) | Channel effectiveness data, competitor strategies, best practices, case studies, risk assessments | Industry publications, trade journals, Alibaba seller resources | URL for EACH strategic claim |

5. **For every data point extracted, IMMEDIATELY record the source URL.** Do NOT collect data first and try to find URLs later — capture the URL at the moment of extraction.
6. Preserve original company names, listing titles, URLs, countries, certifications, MOQ, price ranges, and lead times exactly as found.
7. **If a web search returns no results for a data type**: Record the search query used, note "Data not found via web search [date]", and still provide a clickable `<a href>` link to the most relevant Alibaba category or search results page as a fallback source.

### Supplier Intelligence

| Required Field | Notes |
|----------------|-------|
| Supplier name | Preserve original spelling |
| Alibaba Store URL | Do not invent or shorten fake URLs. MUST be a direct clickable link to the supplier's Alibaba store page. Format: `<a href="https://SUPPLIER.en.alibaba.com" target="_blank" class="link-store-btn">LABEL_VIEW_STORE</a>` — Use translated label matching report language (EN: "View Store", VI: "Xem Store", ZH: "查看店铺") |
| Country/region | Record exactly as shown |
| Product focus | Product categories from the requested industry |
| Alibaba tenure | Include only if visible |
| Verification status | Include only if visible |
| Certifications | Preserve exact certification names only if visible |
| MOQ | Include unit and caveat |
| Price range | Include unit, MOQ, and visible Incoterms if available |
| Lead time | Include only if visible |
| Strengths/risks | Separate verified facts from analysis |

### Product Benchmarking

Benchmark products using attributes that belong to the requested industry. Do not reuse ceramics attributes unless the requested industry is ceramics.

For every industry, compare:

- Product type and subcategory.
- Materials, process, specifications, and variants.
- Use case and buyer segment.
- Customization/OEM/ODM options.
- Packaging and export readiness.
- Listing image quality and product presentation.
- Compliance or certification claims only when visible.
- MOQ, price range, lead time, and sample policy when visible.

### Pricing Intelligence

Build pricing by the correct industry unit. Examples:

| Industry Type | Possible Units |
|---------------|----------------|
| Furniture | piece, set, carton, cbm, container |
| Apparel | piece, set, size/color SKU, carton |
| Food/agriculture | kg, ton, bag, carton, container |
| Packaging | piece, roll, sqm, carton, ton |
| Machinery | unit, set, line, spare part package |
| Ceramics | piece, set, carton, pallet |

Always include MOQ and confidence notes. If prices are hidden, state `Unavailable`.

### SEO Mapping

Map keywords by the requested industry:

| Keyword Type | Required Logic |
|--------------|----------------|
| Core product | Main product terms buyers search |
| Origin/value | Vietnam, Vietnamese, handmade, OEM, factory, manufacturer, supplier when relevant |
| Buyer intent | wholesale, bulk, custom, private label, OEM, ODM, project, distributor |
| Material/process | Industry-specific material and process terms |
| Market/use case | Retail, hotel, restaurant, outdoor, industrial, food service, construction, etc. |
| Compliance | Only include compliance keywords that are relevant and verified or clearly framed as target keywords |

---

## Part 4: Premium Template-Based Output

### Template Priority

If a designed HTML, DOCX, or other report template is available, use it as the primary output structure. Do not redesign the report unless the user explicitly asks for a redesign.

For stored templates or workspace-provided samples, prefer `b2b-reports/Bao_cao_mau_Alibaba.html` if present in the workspace; otherwise look under `assets/templates/`.

| Template | Role | Use |
|----------|------|-----|
| `b2b-reports/Bao_cao_mau_Alibaba.html` | Workspace sample template | Use this concrete file as the export template when it exists; replace placeholders with industry data and save the final `.html` into `b2b-reports/` |
| `assets/templates/Gom_su_VietNam.html` | Finished reference sample | Study and preserve its report depth, visual density, section style, tables, dashboard cards, and navigation pattern |

### Mandatory Adaptation Rule

When using the reference sample for a new industry:

1. Replace the report title, meta text, sidebar section names if needed, and all industry wording.
2. Replace all ceramics-specific suppliers, products, market statements, chart values, keywords, and recommendations.
3. Rebuild benchmark criteria for the requested industry.
4. Rebuild pricing units and MOQ logic for the requested industry.
5. Rebuild SEO keyword map for the requested industry.
6. Rebuild export strategy for the requested industry.
7. Keep the premium visual structure and interaction style.

### Premium HTML Requirements

- Premium dashboard layout.
- Responsive sections.
- Executive summary cards.
- Advanced tables.
- Visual benchmark blocks.
- Image comparison sections when data exists.
- Pricing intelligence sections.
- Keyword heatmaps when supported by data.
- Modern typography.
- Print-friendly formatting.
- Branded visual structure.
- Interactive navigation when supported.

### Template Rules

| Rule | Instruction |
|------|-------------|
| Preserve design | Keep layout, typography, colors, sidebar, headers, footers, spacing, cards, chart containers, and table styles |
| Replace data | Replace placeholders, sample text, old supplier data, chart values, and conclusions with verified research data |
| Adapt industry | Rewrite all product taxonomy, benchmark logic, pricing logic, SEO logic, and export strategy for the requested industry |
| Keep structure | Keep section depth and premium feel; section names may change to fit the requested industry |
| Handle missing data | Use `Unavailable` and explain the limitation |
| Treat sample as sample | Re-verify every supplier, price, market figure, certification, and source claim in completed sample templates |
| Avoid fake content | Do not invent suppliers, prices, certifications, URLs, charts, or product claims |

### Template Protection Rules (STRICT - NO EXCEPTIONS)

| Rule | Instruction |
|------|-------------|
| READ-ONLY SOURCE | Files in `assets/templates/` are READ-ONLY references. NEVER modify, overwrite, or save output back to `assets/templates/`. |
| OUTPUT LOCATION | ALL generated reports MUST be saved to `b2b-reports/` directory. NEVER save to `assets/templates/`. |
| OUTPUT NAMING | Use format: `b2b-reports/Bao_cao_nganh_INDUSTRY_SLUG_Alibaba.html` (e.g., `Bao_cao_nganh_Noi_that_Alibaba.html`) |
| STRUCTURAL LOCK | The following elements from the template MUST remain IDENTICAL in the output: CSS styles, sidebar navigation structure, section order (1-7), header/footer, responsive grid layout, typography, color scheme |
| ALLOWED CHANGES | Replace `PLACEHOLDER` values with real data; translate section titles to match industry; add data rows within existing table/grid structures |
| FORBIDDEN CHANGES | Do NOT modify CSS; Do NOT remove sections; Do NOT reorder sections; Do NOT change layout/grid structure; Do NOT remove sidebar; Do NOT alter JavaScript functions; Do NOT change fonts or colors; Do NOT restructure HTML nesting |

### File I/O Contract (STRICT)

```
INPUT:  Read template from `assets/templates/Gom_su_VietNam.html` (or workspace sample) → NEVER write back
OUTPUT: Create NEW file at `b2b-reports/Bao_cao_nganh_INDUSTRY_SLUG_Alibaba.html`
```

Workflow:
1. Read source template (read-only)
2. Replace all `PLACEHOLDER` tags with industry-specific data
3. Verify all 7 sections are present in output
4. Audit all source citations BEFORE saving — verify: (a) "Research Notes" Research Notes section present before Chapter 1 with 5+ sources and 5+ search queries, (b) Chapters 1-6 each have inline `<a href>` source links (Ch1-2: 2+, Ch3: 10+, Ch4: 20+, Ch5-6: 2+), (c) Chapter 7 has "Chapter References" source block, (d) Chapter 7 has comprehensive "Data Source Table" table (20+ rows from all chapters), (e) Chapter 7 has compiled "Reference List" source list organized by category with 10+ URLs, (f) Chapter 7 has 2+ Chart.js interactive charts, (g) every Chapter 4 product has a "View on Alibaba" button, (h) every table with 5+ rows has a search/filter bar, (i) ALL data types have source URLs (suppliers, products, prices, market data, trade policy, keywords, strategy). If any check fails, fix before saving.
5. Save to `b2b-reports/` directory (create directory if needed)
6. Confirm output file path ≠ source template path

### Recommended Placeholder Map

Use or infer these fields when editing templates:

| Placeholder | Meaning |
|-------------|---------|
| `{{report_title}}` | Report title |
| `{{date}}` | Report date |
| `{{industry_slug}}` | Requested industry slug |
| `{{product_scope}}` | Product/category scope |
| `{{target_markets}}` | Target export markets |
| `{{executive_summary}}` | Summary findings |
| `{{supplier_table}}` | Supplier landscape table |
| `{{pricing_table}}` | Pricing intelligence table |
| `{{product_benchmark}}` | Product comparison |
| `{{image_benchmark}}` | Product image benchmark |
| `{{seo_keywords}}` | SEO keyword map |
| `{{strategy_recommendations}}` | Export strategy |
| `{{sources}}` | Source list |

### HTML Output

- Prefer the workspace sample `b2b-reports/Bao_cao_mau_Alibaba.html` as the concrete export template when available; otherwise use the reference `assets/templates/Gom_su_VietNam.html` as the base visual model for new industries.
- Use `Gom_su_VietNam.html` only as a reference sample unless the requested industry is ceramics.
- Create and save a `.html` file as the default final artifact.
- Do not finish with only a summary if an HTML report file can be created.
- Preserve responsiveness and print-friendly styling.
- Use charts only when verified data supports them.
- If Chart.js or JavaScript fails, keep all content in static HTML.
- If images are blocked or unavailable, continue without images and mark image data unavailable.

### DOCX Output

- Prefer a matched DOCX template when available.
- If no DOCX template exists, mirror the premium HTML report structure in a clean DOCX layout.
- Preserve paragraph styles, table styles, headers, footers, brand colors, and pagination when using a template.
- Keep clickable source `<a href>` URLs in tables or footnotes.
- Use compact supplier, product, pricing, and keyword matrices.

---

## Part 5: Report Structure (MANDATORY 7 SECTIONS + RESEARCH NOTES)

For `full-intelligence-report`, the report MUST contain the **Research Notes** section (before Chapter 1) AND ALL 7 chapter sections listed below. No section may be omitted, merged, or skipped. Section names may be translated or adapted to the industry, but the section MUST still exist with equivalent content.

### RESEARCH NOTES (MANDATORY — BEFORE CHAPTER 1)

The report MUST begin with a **"Research Notes"** (Research Notes) section placed BEFORE Chapter 1. This section documents all data collected during web research and provides full transparency on sources.

#### Research Notes Requirements:

| Component | Description | Minimum |
|-----------|-------------|--------|
| Sources visited | List of websites/pages visited during research with clickable `<a href>` links | 5+ sources |
| Keywords searched | Search queries used to find data (e.g., "Vietnam furniture suppliers Alibaba", "FOB price wooden table") | 5+ search queries |
| Key data per source | For each source: what data was extracted (supplier names, prices, market stats, etc.) | Match each source to its data |
| URLs captured | The exact URL where each data point was found | Every data point must have a URL |

#### Research Notes HTML Structure:

```html
<div class="research-notes" style="margin-bottom: 2rem; padding: 1.5rem; background: #f0f4f8; border-left: 4px solid var(--primary); border-radius: 4px;">
  <h2 class="section-title" style="font-size: 1.1rem;"><i class="fa-solid fa-magnifying-glass"></i> LABEL_RESEARCH_NOTES</h2>
  <p style="font-size: 0.82rem; color: #576574; margin-bottom: 1rem;">Data in this report was collected from the following verified sources:</p>
  
  <h3 style="font-size: 0.9rem; margin-bottom: 0.5rem;"><i class="fa-solid fa-globe"></i> Sources Accessed</h3>
  <table style="width: 100%; font-size: 0.8rem; border-collapse: collapse; margin-bottom: 1.5rem;">
    <thead>
      <tr style="background: var(--primary); color: white;">
        <th style="padding: 6px 8px; text-align: left;">#</th>
        <th style="padding: 6px 8px; text-align: left;">Source</th>
        <th style="padding: 6px 8px; text-align: left;">Data Collected</th>
        <th style="padding: 6px 8px; text-align: left;">Link</th>
      </tr>
    </thead>
    <tbody>
      <!-- EXAMPLE ROW - Replace with REAL URLs from actual research -->
      <tr>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">1</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">Alibaba.com - Supplier Search "vietnam ceramic"</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">10 supplier names, store URLs, MOQ, price ranges</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;"><a href="https://www.alibaba.com/trade/search?SearchText=vietnam+ceramic+supplier" target="_blank" class="citation">View</a></td>
      </tr>
      <tr>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">2</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">Alibaba.com - Product Listing</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">20 product listings, images, FOB prices</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;"><a href="https://www.alibaba.com/trade/search?SearchText=ceramic+planter+pot+vietnam" target="_blank" class="citation">View</a></td>
      </tr>
      <!-- Repeat for ALL sources visited - EVERY link MUST be a REAL working URL -->
    </tbody>
  </table>

  <h3 style="font-size: 0.9rem; margin-bottom: 0.5rem;"><i class="fa-solid fa-magnifying-glass"></i> Search Queries Used</h3>
  <ul style="font-size: 0.8rem; line-height: 1.7; padding-left: 1.2rem;">
    <li><code>vietnam INDUSTRY supplier alibaba</code></li>
    <li><code>INDUSTRY FOB price wholesale</code></li>
    <li><code>INDUSTRY export market data 2025</code></li>
    <!-- List ALL search queries used -->
  </ul>
</div>
```

#### CRITICAL: ALL LINKS MUST BE REAL AND WORKING

**EVERY `<a href="...">` in the generated HTML report MUST point to a REAL, accessible URL.** Links that do not work when clicked are a critical failure.

| Rule | Instruction |
|------|-------------|
| NO placeholder URLs | NEVER use generic URLs like `alibaba.com/suppliers/...`, `alibaba.com/category/...`, or any URL with `...` or `placeholder` |
| NO invented URLs | NEVER fabricate URLs. Every URL must come from an actual page you visited during research |
| URL format for Alibaba search | Use: `https://www.alibaba.com/trade/search?SearchText=keyword+keyword` (replace spaces with +) |
| URL format for Alibaba product | Use: `https://www.alibaba.com/product-detail/Product-Name_PRODUCTID.html` (exact URL from the listing) |
| URL format for Alibaba store | Use: `https://STORENAME.en.alibaba.com` (exact store URL from supplier profile) |
| VALIDATION | Before saving: mentally verify every URL follows a valid pattern. If any URL contains `...`, `placeholder`, `example`, or looks generic — it is INVALID. Replace with a real URL or remove the link |

**How to get REAL URLs:**
1. When you search Alibaba, the search page URL is: `https://www.alibaba.com/trade/search?SearchText=your+search+query` — USE THIS EXACT URL as the source
2. When you find a product, the listing URL is: `https://www.alibaba.com/product-detail/Product-Title_1234567890.html` — COPY THIS EXACT URL
3. When you find a supplier, their store URL is: `https://storename.en.alibaba.com` — COPY THIS EXACT URL
4. If you cannot obtain a real URL for a source, write "URL unavailable — data collected from Alibaba search results" instead of a fake link

#### Research Notes Rules:

1. **MUST appear before Chapter 1** — The Research Notes section is the FIRST content section in the report, placed before the Executive Summary.
2. **Every source visited MUST be listed** with a clickable `<a href>` link and description of data extracted.
3. **Every search query used MUST be listed** so the reader can verify or replicate the research.
4. **Minimum 5 sources and 5 search queries** — a report with fewer is considered under-researched.
5. **The "Link" column MUST contain clickable `<a href>` tags** — plain text URLs are NOT acceptable.
6. **ENFORCED — No exceptions**: Missing the Research Notes section makes the output invalid. Do NOT save the HTML file without it.

### STRICT SECTION REQUIREMENTS

| # | Section | Purpose | Minimum Content |
|---|---------|---------|-----------------|
| 1 | Executive Summary | Top opportunities, risks, and recommended direction | 3+ key findings, 2+ recommendations, 3+ inline `<a href>` citation links (market statistics, growth rate, opportunity size) |
| 2 | Market Overview & Industry Scope | Demand signals, export context, product scope, target buyers, target markets | 1+ market context paragraph, buyer segments identified, 2+ inline `<a href>` citation links |
| 3 | Supplier Landscape | Alibaba suppliers with credibility comparison, factory benchmark, competitor positioning | MINIMUM 10 suppliers total with name, working URL, MOQ, price range, strengths. For NICHE industries: split into Part A (origin country, real links only) + Part B (global, to reach 10 total). See NICHE INDUSTRY HANDLING rules. |
| 4 | Top Selling Products & Product Benchmark | Materials, use cases, customization, packaging, image benchmark | MINIMUM 20 products. EACH product MUST have: (1) product image URL from Alibaba CDN `s.alicdn.com`, (2) original product name from listing, (3) FOB price range in USD, (4) MOQ, (5) supplier name, (6) direct clickable `<a href>` link to the product page on alibaba.com, (7) "View on Alibaba" button linking to the real Alibaba product page. 20+ product `<a href>` links |
| 5 | Pricing Intelligence | Price corridor, MOQ, unit caveats, confidence levels | Price table with 3+ price tiers, unit consistency, 2+ inline `<a href>` citation links |
| 6 | SEO Keyword Map & Buyer Persona | Primary, long-tail, material/process, buyer-intent keywords; buyer segments | MINIMUM 10 keywords mapped by category, 2+ inline `<a href>` citation links |
| 7 | Export Strategy, Channel Strategy & Risk Analysis | Positioning, Alibaba optimization, RFQ plan, risks, charts, source list | ALL 11 COMPONENTS REQUIRED (see CHAPTER 7 COMPLETE STRUCTURE): (1) Strategy intro, (2) 3+ strategy recommendations with `<a href>` citations, (3) channel strategy analysis, (4) risk analysis table (4+ risks), (5) 2+ Chart.js interactive charts, (6) Alibaba optimization plan, (7) action roadmap, (8) 2+ inline `<a href>` citations, (9) "Chapter References" source block, (10) "Data Source Table" table (3+ rows), (11) compiled "Reference List" master source list. Chapter 7 MUST be comprehensive — NOT a short summary. |

### SECTION COUNT ENFORCEMENT RULES

1. Count your output sections BEFORE finalizing. If fewer than 7 sections exist, STOP and add the missing sections.
2. If data for a section is genuinely unavailable, keep the section header and write: "Data unavailable for this industry on Alibaba.com. Recommendation: [suggest alternative data source]."
3. NEVER silently omit a section. NEVER merge two sections into one without including all required content from both.
4. Section names may be renamed to fit the industry (e.g., "Supplier Landscape" → "Featured Suppliers") but must cover the same scope.
5. **DO NOT OMIT ANY CONTENT (KHÔNG ĐƯỢC BỎ SÓT BẤT KỲ NỘI DUNG NÀO)**: Every section, data point, source citation, and structural component defined in this skill MUST be included in the final output. If you are unsure whether something is required, INCLUDE IT. Omitting required content is a critical failure. Before saving the HTML file, you MUST verify every item in the **Pre-Save Verification Checklist** below. If any item fails, STOP and fix it before saving.

### PRE-SAVE VERIFICATION CHECKLIST (MANDATORY — RUN BEFORE EVERY SAVE)

Before saving the HTML file, you MUST mentally (or in scratchpad) check each item below. Mark each as PASS or FAIL. If ANY item is FAIL, DO NOT SAVE — fix it first:

| # | Item to Verify | PASS Criteria | FAIL Action |
|---|---------------|--------------|-------------|
| 0 | Research Notes section | "Research Notes" section present BEFORE Chapter 1 with 5+ sources visited (table with `<a href>` links) and 5+ search queries listed | Add Research Notes section with all captured data |
| 1 | All 7 sections present | Count = 7 sections in HTML output | Add missing sections immediately |
| 2 | Chapter 1 content | 3+ key findings, 2+ recommendations, 3+ inline `<a href>` citations | Add missing content |
| 3 | Chapter 2 content | Market context, buyer segments, 2+ inline `<a href>` citations | Add missing content |
| 4 | Chapter 3 suppliers | 10+ suppliers with store `<a href>` links (or explicit shortage note) | Search for more suppliers or add shortage note |
| 5 | Chapter 4 products | 20+ products with images, prices, product `<a href>` links, "View on Alibaba" buttons (or explicit shortage note) | Search for more products or add shortage note |
| 6 | Chapter 5 pricing | Price table with 3+ tiers, 2+ inline `<a href>` citations | Add missing content |
| 7 | Chapter 6 keywords | 10+ keywords by category, 2+ inline `<a href>` citations | Add missing keywords |
| 8 | Chapter 7 completeness | ALL 11 components present (see CHAPTER 7 COMPLETE STRUCTURE): strategy, recommendations, channels, risks, charts, optimization, roadmap, citations, source block, data table, compiled source list | Add missing components |
| 9 | Chapter 7 source block | "Chapter References" block with 2+ clickable `<a href>` links | Add source block |
| 10 | Chapter 7 data table | "Data Source Table" table with 20+ rows from ALL chapters | Expand table with missing data points |
| 11 | Chapter 7 compiled source list | "Reference List" with 10+ URLs organized by category | Add missing source URLs |
| 12 | Chapter 7 charts | 2+ Chart.js `<canvas>` elements with real data | Add charts |
| 13 | Chapter 7 length | Substantial content (not a short summary) | Expand with missing components |
| 14 | No plain text URLs | All URLs wrapped in `<a href>` tags | Wrap bare URLs in links |
| 15 | Template preserved | CSS, layout unchanged from template. Sidebar LABELS translated to report_language (structure preserved, text translated) | Restore template structure; translate sidebar labels |
| 16 | Output location | File saved to `b2b-reports/`, not `assets/templates/` | Change save path |
| 17 | Search/filter bars | Every table with 5+ rows has a search input above it | Add missing search inputs |
| 18 | No placeholders | No `...` or unreplaced tags remain | Replace all placeholders |

**CRITICAL**: If you skip this checklist and save an incomplete file, the output is INVALID. The checklist is NOT optional — it is a MANDATORY final gate before every save.

### DATA QUANTITY ENFORCEMENT RULES

1. Suppliers: MUST list at minimum 10 suppliers. If Alibaba shows fewer than 10 for the industry, list ALL available and add a note: "Only X suppliers found. Industry has limited Alibaba presence."
2. Products: MUST list at minimum 20 products. If fewer than 20 exist, list ALL available and add a note: "Only X products found on Alibaba for this category."
3. SEO Keywords: MUST include at minimum 10 keywords across categories (core product, origin, buyer-intent, material/process, market/use-case).
4. NEVER silently reduce quantities. If you list fewer than the minimum, you MUST include an explicit shortage explanation.

### NICHE INDUSTRY HANDLING (WHEN ORIGIN COUNTRY HAS LIMITED SUPPLIERS)

When searching Alibaba for suppliers from the user's specified origin country and the industry is niche (fewer than 10 active, verified suppliers found), apply this TWO-PART structure:

#### Detection Rule:
If you search Alibaba for the specified industry + origin country and find FEWER than 10 suppliers with active, working store pages — the industry is classified as **NICHE** for that country.

#### Two-Part Supplier Structure:

**Part A: Suppliers from ORIGIN_COUNTRY** (Niche Market)

| Requirement | Instruction |
|-------------|-------------|
| Header | Clearly label: "Nhà cung cấp từ COUNTRY (Thị trường ngách - Số lượng hạn chế)" / "Suppliers from COUNTRY (Niche Market - Limited Availability)" — match report language |
| Content | List ALL real, verified suppliers found from that country (even if only 2-3) |
| Niche indicator | Add a visible note/badge: "This is a niche industry on Alibaba with limited supplier presence from COUNTRY" |
| Links | EVERY supplier MUST have a real, working Alibaba store link. If the store page doesn't load, DO NOT list that supplier |
| Minimum | No minimum for Part A — list only what is genuinely available and verified |

**Part B: Top Global Suppliers on Alibaba** (All Countries)

| Requirement | Instruction |
|-------------|-------------|
| Header | Clearly label: "Nhà cung cấp hàng đầu trên Alibaba (Toàn cầu)" / "Top Alibaba Suppliers (Global)" — match report language |
| Content | List additional suppliers from ANY country to reach the minimum total of 10 suppliers |
| Country tag | Each supplier MUST show their country of origin (e.g., "China", "India", "Turkey") |
| Links | EVERY supplier MUST have a real, working Alibaba store link |
| Combined total | Part A + Part B combined MUST reach minimum 10 suppliers |

#### Visual Structure in HTML:

```html
<!-- Part A: Origin Country Suppliers -->
<div class="niche-notice" style="background: #FFF9E6; border-left: 4px solid #D4A017; padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem;">
  <strong>⚠️ Niche Market Notice:</strong> INDUSTRY from COUNTRY has limited supplier presence on Alibaba.com. Only X verified suppliers found from this country.
</div>

<h3 class="sub-title">Part A: Suppliers from COUNTRY (X found)</h3>
<!-- Supplier table with only verified, active suppliers from origin country -->

<h3 class="sub-title">Part B: Top Global Suppliers (Y additional)</h3>
<!-- Supplier table with top suppliers from other countries to reach minimum 10 total -->
```

#### Rules:

1. **NEVER list a supplier with a non-working link** just to meet the quantity minimum. It is better to have 3 real suppliers than 10 fake ones.
2. **ALWAYS verify links work** before including a supplier. If you cannot confirm the store page exists, exclude that supplier.
3. **The niche notice is MANDATORY** when Part A has fewer than 5 suppliers — this tells the user the industry has limited online presence.
4. **Part B fills the gap** — search broadly on Alibaba (any country) for the same product category to find additional real suppliers.
5. **Same format for Chapter 4 (Products)**: If fewer than 20 products from the origin country, split into Part A (origin country products) and Part B (global top products) to reach 20 total.
6. **Country column required in Part B**: Every supplier/product in Part B MUST show its country of origin so the user knows it's not from their specified country.

### CHAPTER 4 PRODUCT DATA FORMAT (MANDATORY)

Every product listed in Chapter 4 MUST follow this exact data structure (matching the reference template `Gom_su_VietNam.html`):

| # | Required Field | Format | Source |
|---|----------------|--------|--------|
| 1 | Product Image | `<img src="https://s.alicdn.com/...">` - actual product thumbnail from Alibaba CDN | Extract directly from Alibaba product listing |
| 2 | Product Name | Original listing title in English, wrapped in `<strong>` tag | Copy exactly from Alibaba listing |
| 3 | FOB Price Range | Format: `$X.XX - $Y.YY` in USD | From Alibaba listing price display |
| 4 | MOQ | Number + unit (e.g., "100 pieces", "50 sets") | From Alibaba listing |
| 5 | Supplier Name | Full company name as shown on Alibaba | From supplier profile |
| 6 | Product Link | Direct URL to `alibaba.com/product-detail/...` wrapped in clickable `<a href>` button with class `link-store-btn` | From Alibaba product page URL |
| 7 | View on Alibaba Button | `<a href="PRODUCT_URL" target="_blank" class="link-store-btn">View on Alibaba</a>` — MUST link to the actual Alibaba product listing page | Same URL as field 6 |

#### HTML Table Structure (MUST follow this format):

```html
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>Product Image (Alibaba CDN)</th>
      <th>Product Name (Original)</th>
      <th>FOB Price Range (USD)</th>
      <th>MOQ</th>
      <th>Verified Supplier</th>
      <th>Product Link</th>
      <th>View on Alibaba</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td><img src="https://s.alicdn.com/@sc04/kf/..." style="border-radius:4px; object-fit:cover; width:60px; height:60px;" alt="p1"></td>
      <td><strong>Original Product Title From Alibaba</strong></td>
      <td>$X.XX - $Y.YY</td>
      <td>100 pieces</td>
      <td>SUPPLIER NAME</td>
      <td><a href="https://www.alibaba.com/product-detail/..." target="_blank" class="link-store-btn">LABEL_VIEW_DETAILS</a></td>
      <td><a href="https://www.alibaba.com/product-detail/..." target="_blank" class="link-store-btn">View on Alibaba</a></td>
    </tr>
    <!-- Repeat for all 20 products -->
  </tbody>
</table>
```

#### STRICT RULES FOR CHAPTER 4:

1. **Image URLs MUST be real**: Extract actual image URLs from `s.alicdn.com` CDN. NEVER use placeholder images, stock photos, or invented URLs.
2. **Product links MUST be real**: Every product MUST have a working direct clickable `<a href>` link to its Alibaba.com product page (`alibaba.com/product-detail/...`). NEVER invent or fabricate product URLs.
3. **All 20 products MUST have images and links**: Do NOT list products as text-only. If an image URL cannot be found, use the supplier's store logo as fallback and note "Image unavailable."
4. **Supplier links**: In Chapter 3 (Supplier Landscape), each supplier MUST also have a direct clickable `<a href>` link to their Alibaba store page.
5. **Link format**: All links must use `target="_blank"` and class `link-store-btn` for consistent button styling.
6. **If images are blocked by the environment**: Keep the `<img>` tags with correct `src` URLs even if you cannot visually verify them. The URLs must be genuine Alibaba CDN paths extracted during research.
7. **"View on Alibaba" button is MANDATORY**: Every product row MUST include a “View on Alibaba” button (`<a href>` with class `link-store-btn`) that links to the actual Alibaba product page. This button must use the same real product URL as field 6. NEVER omit this button.

### SOURCE CITATION RULES (MANDATORY - ALL CHAPTERS)

Every chapter in the report MUST include inline source citations with clickable links. Data without a source link is considered unverified and incomplete.

#### Citation Format:

Use the `citation` class for inline source links within the text:
```html
<a href="https://www.alibaba.com/..." target="_blank" class="citation">[Source]</a>
```

#### Per-Chapter Source Requirements:

| Chapter | What MUST be cited with links | Link Format |
|---------|-------------------------------|-------------|
| 1 - Executive Summary | Key market statistics, growth claims, opportunity figures | `<a href="SOURCE_URL" target="_blank" class="citation">[Source]</a>` after each claim |
| 2 - Market Overview | Market size data, demand trends, export statistics, trade data | Inline citation links after each statistic or market claim |
| 3 - Supplier Landscape | Each supplier's Alibaba store URL, verification status source | `<a href="https://SUPPLIER.en.alibaba.com" target="_blank" class="link-store-btn">LABEL_VIEW_STORE</a>` per supplier row |
| 4 - Products | Product page URL for each product (already enforced above) | `<a href="https://www.alibaba.com/product-detail/..." target="_blank" class="link-store-btn">LABEL_VIEW_DETAILS</a>` |
| 5 - Pricing Intelligence | Source URL for each price data point, price comparison source | Footnote or inline link per price row: `<a href="URL" target="_blank" class="citation">[Price Source]</a>` |
| 6 - SEO & Buyer Persona | Keyword research source, search volume source if cited | Link to Alibaba search results page: `<a href="https://www.alibaba.com/trade/search?SearchText=..." target="_blank" class="citation">[Alibaba Search]</a>` |
| 7 - Strategy & Risk | Sources for recommendations, trade regulations, compliance requirements | `<a href="URL" target="_blank" class="citation">[Source]</a>` after each factual claim |

#### Source Citation Strict Rules:

1. **Every factual claim MUST have a source**: Any data point (price, MOQ, market size, growth rate, certification, trade statistic) MUST be followed by a clickable source link.
2. **Sources MUST be clickable**: Plain text URLs or "(Source: alibaba.com)" without `<a href>` tags are NOT acceptable. All sources must be wrapped in clickable `<a>` tags.
3. **Sources MUST be real**: NEVER fabricate source URLs. If a source cannot be found, write "Source: Alibaba.com research [date]" but still attempt to link to the relevant search or category page.
4. **Minimum sources per chapter**: Each chapter MUST have at least 2 source citations with clickable links. Chapter 3 and 4 will naturally have 10+ and 20+ respectively. Chapter 7 must also have the compiled "Reference List" list containing ALL source URLs from all chapters.
5. **Compiled Source List Rule ("Reference List")**: Chapter 7 MUST end with a compiled "Reference List" list containing ALL URLs referenced throughout all 7 chapters of the report, formatted as a clickable `<a href>` list. This list is the MASTER bibliography of the entire report and MUST include EVERY URL from ALL of the following categories:
   - **Supplier URLs**: Direct links to every supplier's Alibaba store page (from Chapter 3)
   - **Product URLs**: Direct links to every product's Alibaba listing page (from Chapter 4)
   - **Price data source URLs**: URLs where price ranges, FOB pricing, and cost data were obtained (from Chapter 5)
   - **Market research source URLs**: URLs for market size, growth rate, export volume, demand trends, and industry statistics (from Chapters 1-2)
   - **Trade policy & regulation source URLs**: URLs for trade agreements, compliance requirements, certifications, and regulatory data cited in the report
   - **Keyword research source URLs**: URLs for Alibaba search results pages and keyword data sources (from Chapter 6)
   - **Strategy source URLs**: URLs supporting strategic recommendations, channel analysis, and risk assessments (from Chapter 7)
   - **Any other data source URL**: Every remaining URL cited anywhere in the report that does not fall into the above categories

**CRITICAL**: The compiled source list MUST be organized by category with clear headings (e.g., "Suppliers", "Products", "Price Data", "Market Research", "Trade Policy", "Keywords", "Strategy"). Each entry must include the source name/description AND the clickable URL. A compiled list with only generic links or fewer than 10 total URLs is INCOMPLETE.

#### Source List HTML Structure (at end of Chapter 7):

```html
<div class="source-list" style="margin-top: 2rem; padding-top: 1.5rem; border-top: 2px solid var(--bg);">
  <h2 class="sub-title"><i class="fa-solid fa-link"></i> LABEL_REFERENCE_LIST</h2>
  <ol style="font-size: 0.82rem; line-height: 1.8;">
    <!-- SUPPLIER URLs (from Chapter 3) -->
    <li><strong>Suppliers:</strong> <a href="https://supplier.en.alibaba.com" target="_blank" class="citation">Supplier Name - Alibaba Store</a></li>
    <!-- PRODUCT URLs (from Chapter 4) -->
    <li><strong>Products:</strong> <a href="https://www.alibaba.com/product-detail/..." target="_blank" class="citation">Product Name - Product Page</a></li>
    <!-- PRICE DATA URLs (from Chapter 5) -->
    <li><strong>Price Data:</strong> <a href="https://www.alibaba.com/..." target="_blank" class="citation">Price Source Description</a></li>
    <!-- MARKET RESEARCH URLs (from Chapters 1-2) -->
    <li><strong>Market Research:</strong> <a href="https://..." target="_blank" class="citation">Market Data Source - Description</a></li>
    <!-- TRADE POLICY URLs -->
    <li><strong>Trade Policy:</strong> <a href="https://..." target="_blank" class="citation">Trade Policy Source</a></li>
    <!-- KEYWORD RESEARCH URLs (from Chapter 6) -->
    <li><strong>Keywords:</strong> <a href="https://www.alibaba.com/trade/search?SearchText=..." target="_blank" class="citation">Keyword - Alibaba Search Results</a></li>
    <!-- STRATEGY URLs (from Chapter 7) -->
    <li><strong>Strategy:</strong> <a href="https://..." target="_blank" class="citation">Strategy Source Description</a></li>
    <!-- ALL other cited URLs -->
  </ol>
</div>
```

#### Per-Chapter Research Sources Display (Chapter 7 ONLY — "Chapter References"):

**Chapters 1-6**: Only need inline `<a href>` citation links within the text. Do NOT add source blocks or data tables to Chapters 1-6.

**Chapter 7 ONLY**: MUST end with a visible **"Chapter References"** block that lists the actual URLs used as sources for Chapter 7. This block must be rendered in the HTML output.

##### Per-Chapter Source Block HTML Structure:

```html
<div class="chapter-sources" style="margin-top: 1.5rem; padding: 1rem; background: #f8f9fa; border-left: 3px solid var(--primary); border-radius: 4px;">
  <h3 style="font-size: 0.9rem; margin-bottom: 0.5rem;"><i class="fa-solid fa-bookmark"></i> LABEL_CHAPTER_REFERENCES</h3>
  <ul style="font-size: 0.8rem; line-height: 1.7; padding-left: 1.2rem;">
    <li><a href="https://www.alibaba.com/..." target="_blank" class="citation">Source description - Supplier/data name</a></li>
    <li><a href="https://www.alibaba.com/product-detail/..." target="_blank" class="citation">Product Name - Product Page</a></li>
    <!-- List ALL sources used in this chapter -->
  </ul>
</div>
```

##### Per-Chapter Source Block Rules (Chapter 7 ONLY):

1. **Only Chapter 7 displays this block** — Chapters 1-6 use inline `<a href>` citations only and do NOT have source blocks.
2. **Sources MUST be clickable `<a href>` links** — plain text URLs are NOT acceptable.
3. **Minimum 2 sources in the Chapter 7 block** — listing all strategy, regulation, and optimization sources used in Chapter 7.
4. **Source descriptions must be meaningful** — include the data description, not just raw URLs.
5. **Chapter 7 source block is IN ADDITION TO the end-of-report compiled source list** — Chapter 7 will have both its own chapter source block AND the compiled "Reference List" list.
6. **ENFORCED — No exceptions**: All 5 rules above are mandatory for Chapter 7.

#### Chapter 7 Comprehensive Data Source Table (MANDATORY — Chapter 7 ONLY):

**Chapters 1-6**: Do NOT include data source tables. Use inline `<a href>` citations only.

**Chapter 7 ONLY**: A comprehensive **"Data Source Table"** must be displayed showing ALL data points used across the entire report along with their source URLs. This table consolidates data from ALL 7 chapters into a single transparency table.

##### Data Source Table HTML Structure:

```html
<div class="data-source-table" style="margin-top: 1.5rem;">
  <h3 style="font-size: 0.9rem; margin-bottom: 0.5rem;"><i class="fa-solid fa-table"></i> LABEL_DATA_SOURCE_TABLE</h3>
  <table style="width: 100%; font-size: 0.8rem; border-collapse: collapse;">
    <thead>
      <tr style="background: var(--primary); color: white;">
        <th style="padding: 6px 8px; text-align: left;">Data</th>
        <th style="padding: 6px 8px; text-align: left;">Value</th>
        <th style="padding: 6px 8px; text-align: left;">Source</th>
        <th style="padding: 6px 8px; text-align: left;">Link</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">Supplier name</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">ABC Co., Ltd</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">Alibaba Store</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;"><a href="https://supplier.en.alibaba.com" target="_blank" class="citation">View</a></td>
      </tr>
      <tr>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">Product price</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">$2.50 - $5.00</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">Alibaba Product Page</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;"><a href="https://www.alibaba.com/product-detail/..." target="_blank" class="citation">View</a></td>
      </tr>
      <!-- Repeat for ALL data points in this chapter -->
    </tbody>
  </table>
</div>
```

##### Data Source Table Rules (Chapter 7 ONLY):

1. **Only Chapter 7 includes this table** — Chapters 1-6 do NOT have data source tables. The Chapter 7 table consolidates ALL data from ALL chapters.
2. **Every data point used across ALL chapters MUST appear as a row**: prices, MOQs, supplier names, market statistics, growth rates, certifications, SEO keywords, strategy claims, trade policies, etc.
3. **The "Link" column MUST contain clickable `<a href>` tags** — plain text URLs are NOT acceptable.
4. **Data descriptions must be specific**: include exact values (e.g., "$2.50 - $5.00/piece", "MOQ 100 pieces", "Growth rate 15%") not generic labels.
5. **Minimum total rows**: The Chapter 7 comprehensive table must have 20+ rows covering data from all chapters (suppliers, products, prices, market data, keywords, strategy).
6. **ENFORCED — No exceptions**: All 5 rules above are mandatory for Chapter 7. Do NOT save the HTML file if Chapter 7 is missing the comprehensive "Data Source Table" table.

### CHAPTER 7 INTERACTIVE CHART.JS CHARTS (MANDATORY)

Chapter 7 MUST include at least **2 interactive charts** built with Chart.js (or fallback static charts if Chart.js is unavailable). These charts must visualize strategy, risk, or market data from the report.

#### Chart Requirements:

1. **Minimum 2 charts** in Chapter 7. Recommended chart types:
   - Market trend line/bar chart (growth over time, export volume)
   - Risk radar or polar area chart (risk categories scored)
   - Strategy comparison bar chart (channel effectiveness, ROI projections)
   - Market share pie/doughnut chart
2. **Charts MUST use real data** from the report — never use placeholder or dummy data.
3. **Chart.js CDN MUST be included**: `<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>` in the HTML `<head>` or before the chart `<canvas>` elements.
4. **Each chart MUST have**: a `<canvas>` element, a Chart.js initialization script with real labels and datasets, responsive sizing, and a visible title.
5. **Fallback**: If Chart.js fails to load, the chart data MUST still be visible as a static HTML table below the `<canvas>` element.
6. **ENFORCED — No exceptions**: Chapter 7 without at least 2 charts is considered incomplete. Do NOT save the HTML file if Chapter 7 has fewer than 2 charts.

#### Chart HTML Structure Example:

```html
<div class="chart-container" style="position: relative; margin: 2rem 0; max-width: 600px;">
  <h3 class="sub-title"><i class="fa-solid fa-chart-line"></i> Market Trends</h3>
  <canvas id="marketTrendChart"></canvas>
  <noscript>
    <table><!-- Fallback data table --></table>
  </noscript>
</div>
```

### CHAPTER 7 COMPLETE STRUCTURE (MANDATORY — DO NOT SKIP ANY PART)

Chapter 7 is the LONGEST and MOST COMPREHENSIVE chapter. It MUST contain ALL of the following components IN THIS EXACT ORDER. Missing ANY component makes the output INVALID:

| # | Component | Description | MANDATORY |
|---|-----------|-------------|----------|
| 1 | Chapter Title & Introduction | `<h2>` section title, 2+ paragraphs of strategy overview and key findings summary | YES — ENFORCED |
| 2 | Strategy Recommendations | 3+ detailed strategy recommendations with supporting data, each followed by `<a href>` source citations | YES — ENFORCED |
| 3 | Channel Strategy Analysis | Analysis of sales channels (Alibaba, direct B2B, trade shows, e-commerce), with data and `<a href>` source links | YES — ENFORCED |
| 4 | Risk Analysis Table | Risk table with at least 4 risks (trade policy, logistics, competition, compliance), severity rating, mitigation strategy, `<a href>` source links | YES — ENFORCED |
| 5 | 2+ Interactive Chart.js Charts | At least 2 `<canvas>` elements with Chart.js initialization using REAL report data. Chart.js CDN `<script>` tag included. Fallback static `<table>` inside `<noscript>` for each chart | YES — ENFORCED |
| 6 | Alibaba Optimization Plan | Specific recommendations for store optimization, listing SEO, product images, RFQ strategy | YES — ENFORCED |
| 7 | Action Roadmap | Step-by-step action plan (3-6 steps) with timeline and priorities for the Vietnam exporter | YES — ENFORCED |
| 8 | Inline Source Citations | 2+ `<a href>` citation links throughout the chapter text (after factual claims, statistics, recommendations) | YES — ENFORCED |
| 9 | "Chapter References" Block | `<h3>` source block with 2+ clickable `<a href>` links listing ALL sources used specifically in Chapter 7 | YES — ENFORCED |
| 10 | "Data Source Table" Table | `<h3>` data source table (4 columns: Data, Value, Source, Link) with 3+ rows of Chapter 7 data points | YES — ENFORCED |
| 11 | "Reference List" Compiled Source List | `<div class="source-list">` with `<h2>` heading containing ALL URLs from ALL 7 chapters as clickable `<a href>` links. This is the MASTER source list for the entire report | YES — ENFORCED |

**Chapter 7 MUST NOT be a short summary section.** If Chapter 7 is shorter than Chapters 3, 4, or 5, it is INCOMPLETE. Chapter 7 should typically be 2000-4000 words including all components above.

**CRITICAL**: The template's Chapter 7 may be short (just an SEO action plan). DO NOT copy the template's short structure. You MUST expand Chapter 7 to include ALL 11 components listed above with full content.

### DATA TABLE SEARCH/FILTER BAR (MANDATORY - ALL TABLES)

Every data table in the report (supplier tables, product tables, pricing tables, SEO keyword tables, risk tables, source tables) MUST include a **search/filter bar** above the table so users can quickly find specific rows.

#### Search/Filter Requirements:

1. **Every `<table>` with 5+ rows MUST have a search input** above it.
2. **Search input HTML structure**:
```html
<input type="text" class="table-search" placeholder="Search..." style="width: 100%; padding: 8px 12px; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 0.85rem;" onkeyup="filterTable(this)">
```
3. **JavaScript filter function** MUST be included in the HTML file:
```html
<script>
function filterTable(input) {
  const filter = input.value.toLowerCase();
  const table = input.nextElementSibling;
  const rows = table.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const text = row.textContent.toLowerCase();
    row.style.display = text.includes(filter) ? '' : 'none';
  });
}
</script>
```
4. **The search input MUST appear directly above each data table** — not in a sidebar or separate section.
5. **Styling**: Search input must match the report's visual style (use CSS variables from the template).
6. **ENFORCED — No exceptions**: Any table with 5+ rows that lacks a search/filter bar makes the output invalid. Do NOT save the HTML file if any qualifying table is missing its search bar.

### LANGUAGE & ORIGIN COUNTRY MATCHING (STRICT - NO EXCEPTIONS)

#### Language Matching Rule:

The ENTIRE output HTML report MUST be written in the SAME language as the user's prompt. This is automatic and non-negotiable:

| User Prompt Language | Report Output Language | Example |
|---------------------|----------------------|--------|
| English | ALL content in English | "Generate a report for pepper from India" → English report |
| Vietnamese (Tiếng Việt) | ALL content in Vietnamese | "Tạo báo cáo ngành gia vị Ấn Độ" → Vietnamese report |
| Chinese (中文) | ALL content in Chinese | "生成印度香料行业报告" → Chinese report |
| Any other language | Match that language | Report follows user's language |

#### What "ALL content" means — EVERY element must be in the matched language:

| Element | Must Match Language |
|---------|-------------------|
| Section titles & sidebar labels | YES — MUST be fully translated to report_language (see SIDEBAR NAVIGATION & CHAPTER NAMING table) |
| Table headers | YES |
| Button labels ("Xem Chi Tiết" / "View Details" / "查看详情") | YES |
| Analysis text and descriptions | YES |
| Executive summary | YES |
| Strategy recommendations | YES |
| Risk analysis | YES |
| Source list labels | YES |
| Sidebar navigation labels | YES |
| Search bar placeholder text | YES |
| Metadata (date format, currency labels) | YES |

#### EXCEPTIONS (keep original language regardless):
- Supplier company names → Keep original (e.g., "AURORA JSC" stays English)
- Product listing titles → Keep original from Alibaba (usually English)
- URLs → Keep as-is
- Certification names (ISO, FSC, BSCI) → Keep original
- Technical terms with no translation → Keep original + add translation in parentheses

#### Origin Country Matching Rule:

The report MUST focus on the country/region specified by the user, NOT default to Vietnam:

| User Request | Origin Country | Suppliers From |
|-------------|----------------|----------------|
| "report for pepper from India" | India | Indian suppliers on Alibaba |
| "báo cáo gốm sứ Việt Nam" | Vietnam | Vietnamese suppliers on Alibaba |
| "report for furniture from China" | China | Chinese suppliers on Alibaba |
| "análisis de café de Colombia" | Colombia | Colombian suppliers on Alibaba |
| No country specified | Vietnam (default) | Vietnamese suppliers on Alibaba |

**Rules:**
1. If the user specifies a country, ALL supplier research must focus on that country's sellers on Alibaba.com.
2. Only default to Vietnam if NO origin country is mentioned or implied.
3. The report title, industry slug, and file name must reflect the correct origin country.
4. File naming: `b2b-reports/Bao_cao_nganh_INDUSTRY_COUNTRY_Alibaba.html` (e.g., `Bao_cao_nganh_Pepper_India_Alibaba.html`)
5. If the report language is English, use English file naming: `b2b-reports/Report_INDUSTRY_COUNTRY_Alibaba.html`

#### Language Detection Flow:

| Step | Action |
|------|--------|
| 1 | Detect the language of the user's prompt |
| 2 | Set `report_language` = detected language |
| 3 | Detect origin country from prompt (default: Vietnam if not specified) |
| 4 | Set `origin_country` = detected country |
| 5 | Generate ALL report content in `report_language` |
| 6 | Search Alibaba for suppliers from `origin_country` |
| 7 | Name output file using `report_language` conventions |

#### UI Label Translation Table (MANDATORY):

All report UI labels MUST be translated to match `report_language`. Use these exact translations:

| Vietnamese (default) | English | Chinese (中文) | Usage |
|---------------------|---------|---------------|-------|
| Ghi chú nghiên cứu | Research Notes | 研究笔记 | Section before Chapter 1 |
| Nguồn tham khảo chương này | Chapter References | 本章参考来源 | Source block in Chapter 7 |
| Bảng nguồn dữ liệu | Data Source Table | 数据来源表 | Data table in Chapter 7 |
| Danh sách nguồn tham khảo | Reference List | 参考来源列表 | Compiled source list in Chapter 7 |
| Xem Chi Tiết | View Details | 查看详情 | Product link button |
| Xem Store | View Store | 查看店铺 | Supplier store link button |
| Ảnh Sản Phẩm | Product Image | 产品图片 | Table header |
| Tên Sản Phẩm Bán Chạy | Product Name | 产品名称 | Table header |
| Dải Giá FOB | FOB Price Range | FOB价格区间 | Table header |
| Nhà Cung Cấp Uy Tín | Verified Supplier | 优质供应商 | Table header |
| Link Sản Phẩm Thực Tế | Product Link | 产品链接 | Table header |
| STT | # | 序号 | Row number header |
| Nguồn | Source | 来源 | Citation label |
| Nguồn giá | Price Source | 价格来源 | Price citation label |

**RULE: If `report_language` is NOT Vietnamese, you MUST translate ALL labels above to the matching language column. Do NOT leave any Vietnamese labels in a non-Vietnamese report. This applies to ALL HTML elements including headings, table headers, button text, section titles, and citation labels.**

**If `report_language` is a language not listed above (e.g., Spanish, Japanese, Korean), translate all labels to that language following the same pattern.**

#### SIDEBAR NAVIGATION & CHAPTER NAMING (MUST MATCH report_language):

ALL chapter titles, sidebar navigation labels, and section headings MUST be fully translated to `report_language`. Do NOT mix languages. Do NOT leave Vietnamese labels in a non-Vietnamese report.

**Sidebar Navigation Translation Table:**

| # | Vietnamese | English | Chinese (中文) |
|---|-----------|---------|---------------|
| Research Notes | 🔍 Ghi chú nghiên cứu | 🔍 Research Notes | 🔍 研究笔记 |
| Chapter 1 | 📋 Chương 1: Tóm tắt | 📋 Chapter 1: Executive Summary | 📋 第1章: 执行摘要 |
| Chapter 2 | 🌐 Chương 2: Tổng quan thị trường | 🌐 Chapter 2: Market Overview | 🌐 第2章: 市场概览 |
| Chapter 3 | 🏭 Chương 3: Nhà cung cấp | 🏭 Chapter 3: Supplier Landscape | 🏭 第3章: 供应商概况 |
| Chapter 4 | 🏆 Chương 4: SP bán chạy | 🏆 Chapter 4: Top Products | 🏆 第4章: 热销产品 |
| Chapter 5 | 💰 Chương 5: Định giá | 💰 Chapter 5: Pricing Intelligence | 💰 第5章: 价格分析 |
| Chapter 6 | 🔑 Chương 6: SEO & Người mua | 🔑 Chapter 6: SEO & Buyer Persona | 🔑 第6章: SEO与买家画像 |
| Chapter 7 | 🚀 Chương 7: Chiến lược & Rủi ro | 🚀 Chapter 7: Strategy & Risk | 🚀 第7章: 战略与风险 |

**STRICT RULES:**
1. The sidebar navigation `<a>` text MUST use the labels from the column matching `report_language`.
2. The main content `<h2>` section titles MUST also match `report_language` (same translations).
3. Do NOT use "Chapter" prefix in non-English reports. Use: Vietnamese = "Chương", Chinese = "第X章", English = "Chapter X".
4. Do NOT mix languages in the sidebar. If ONE label is in Chinese, ALL must be in Chinese.
5. If `report_language` is not in the table above, translate all labels to that language consistently.

**Sidebar HTML Example (Chinese report):**
```html
<nav>
  <ul>
    <li><a href="#research-notes"><i class="fa-solid fa-magnifying-glass"></i> 研究笔记</a></li>
    <li><a href="#sec1"><i class="fa-solid fa-clipboard"></i> 第1章: 执行摘要</a></li>
    <li><a href="#sec2"><i class="fa-solid fa-globe"></i> 第2章: 市场概览</a></li>
    <li><a href="#sec3"><i class="fa-solid fa-industry"></i> 第3章: 供应商概况</a></li>
    <li><a href="#sec4"><i class="fa-solid fa-award"></i> 第4章: 热销产品</a></li>
    <li><a href="#sec5"><i class="fa-solid fa-tags"></i> 第5章: 价格分析</a></li>
    <li><a href="#sec6"><i class="fa-solid fa-key"></i> 第6章: SEO与买家画像</a></li>
    <li><a href="#sec7"><i class="fa-solid fa-rocket"></i> 第7章: 战略与风险</a></li>
  </ul>
</nav>
```

**Note on LABEL_* placeholders in this skill document:** When you see `LABEL_RESEARCH_NOTES`, `LABEL_CHAPTER_REFERENCES`, `LABEL_DATA_SOURCE_TABLE`, `LABEL_REFERENCE_LIST`, `LABEL_VIEW_DETAILS`, or `LABEL_VIEW_STORE` in HTML examples within this skill, replace them with the correct translated text from the UI Label Translation Table above based on `report_language`. These are NOT literal placeholders to leave in the output HTML — they represent the translated text you must insert.

---

## Part 6: Compliance And Fallbacks

> **Source citations are part of data completeness.** The output HTML file is NOT valid and NOT complete if any chapter is missing source citations with clickable `<a href>` links.

### Evidence Rules (STRICT - Source Citation Enforcement)

| Rule | Instruction | Must be verified | Must be enforced |
|------|-------------|------------------|------------------|
| No fake data | Never invent suppliers, URLs, certifications, prices, images, or product claims. ALL `<a href>` links MUST be real working URLs — no placeholders, no generic patterns, no `...` in URLs | Pre-output: scan all supplier names, URLs, and product claims against research notes | ENFORCED — No exceptions |
| Preserve originals | Keep company names, listing titles, URLs, certifications, MOQ, and prices exactly as found | Pre-output: compare output data against captured source data | ENFORCED — No exceptions |
| Separate analysis | Clearly separate verified facts from recommendations and assumptions | Pre-output: check that recommendations are not presented as facts | ENFORCED — No exceptions |
| Current data | Browse or verify when data may have changed | Pre-output: confirm data was collected in current session | ENFORCED — No exceptions |
| Source list | Include clickable source URLs (`<a href>` tags) for ALL supplier, product, pricing, and market claims in EVERY chapter. Plain text URLs are NOT acceptable - all must be clickable links | Pre-output: count `<a href>` tags per chapter; Ch1-2: 2+, Ch3: 10+, Ch4: 20+, Ch5-7: 2+ | ENFORCED — No exceptions |
| No plain text URLs | Any URL in the output HTML that is not inside an `<a href>` tag is a defect. Scan the final HTML before saving and wrap ALL bare URLs in clickable links | Pre-output: search HTML for any bare `http://` or `https://` strings not inside `<a href="...">` | ENFORCED — No exceptions |
| Minimum sources per chapter | Chapters 1-6 MUST have inline `<a href>` citation links (Ch1-2: 2+, Ch3: 10+ supplier store links, Ch4: 20+ product links, Ch5-6: 2+). Chapter 7 MUST have: inline citations, "Chapter References" source block, comprehensive "Data Source Table" table (20+ rows), and compiled "Reference List" list with ALL URLs. If any chapter has fewer than 2 inline citations, STOP and add more before saving | Pre-output: count `<a href>` citation links per chapter before saving; verify Chapter 7 has source block + data table + compiled source list | ENFORCED — No exceptions |
| URL captured at extraction | Every data point (supplier, product, price, market stat, trade policy, keyword, strategy claim) MUST have its source URL captured at the moment of extraction. Do NOT write data without a URL and try to find the source later. If no URL was captured during research, the data point is INVALID and must be re-researched or marked `Unavailable` | Pre-output: verify every data point has a corresponding source URL in the Chapter 7 "Data Source Table" table or inline citations | ENFORCED — No exceptions |

### Fallback Policy

| Failure Case | Fallback | Must be verified | Must be enforced |
|--------------|----------|------------------|------------------|
| Missing data | Mark `Unavailable` and explain | Check all `Unavailable` entries are genuinely missing, not skipped | ENFORCED — No exceptions |
| Thin data / Niche industry | If origin country has fewer than 10 suppliers for the industry: apply NICHE INDUSTRY HANDLING — split into Part A (origin country, verified only) + Part B (global suppliers to reach minimum). Mark as niche market. NEVER pad with fake/non-working links | Verify minimum data quantities are still met | ENFORCED — No exceptions |
| No dedicated industry template | Use `assets/templates/Gom_su_VietNam.html` and adapt all industry content | Verify all 7 sections adapted, no ceramics content remains | ENFORCED — No exceptions |
| Cannot write HTML file | Explain the blocker and provide complete HTML content | Verify complete HTML content is provided as fallback | ENFORCED — No exceptions |
| Charts unsupported | Replace with tables | Verify chart data is preserved in table format | ENFORCED — No exceptions |
| Images unavailable | Continue without images | Verify `<img>` tags are kept with correct `src` URLs even if not visually verified | ENFORCED — No exceptions |
| HTML failure | Produce simplified responsive HTML that follows the premium template | Verify all 7 sections present in simplified output | ENFORCED — No exceptions |
| JavaScript failure | Disable interactions and preserve static content | Verify static content is complete | ENFORCED — No exceptions |
| Conflicting data | Show conflict, clickable source `<a href>` URLs, and confidence level | Verify conflicting sources are shown as clickable `<a href>` links | ENFORCED — No exceptions |
| Source URL not found | Write “Source: Alibaba.com research [date]” and still provide a clickable `<a href>` link to the relevant Alibaba search or category page — never output a bare URL without a link | Verify every source has a clickable `<a href>` link, even fallback sources | ENFORCED — No exceptions |
| Source citations missing | Do NOT output the HTML file until all citations are added. Go back and add inline `<a href>` links to all factual claims in Chapters 1-6. Ensure Chapter 7 has: source block, comprehensive data table, and compiled "Reference List" list. | Pre-output: count inline citations per chapter (Ch1-6: 2+, Ch3: 10+, Ch4: 20+); verify Chapter 7 source block + data table + compiled list exist | ENFORCED — No exceptions |
| Chapter 7 charts missing | Add 2+ Chart.js interactive charts with real data before saving. Include Chart.js CDN and fallback static tables. | Pre-output: count `<canvas>` elements in Chapter 7; if < 2, STOP and add charts | ENFORCED — No exceptions |
| "View on Alibaba" buttons missing | Add "View on Alibaba" button to every Chapter 4 product row before saving. Each button links to real Alibaba product page. | Pre-output: count "View on Alibaba" buttons in Ch4; if < 20, STOP and add missing buttons | ENFORCED — No exceptions |
| Table search bars missing | Add search input with `filterTable()` function above every table with 5+ rows. Include the script in the HTML. | Pre-output: count tables with 5+ rows; verify each has a search input above it | ENFORCED — No exceptions |
| Research Notes missing | Add "Research Notes" section before Chapter 1 with sources visited table (5+ rows with `<a href>` links and data extracted per source) and search queries list (5+ queries). | Pre-output: verify "Research Notes" section exists before Chapter 1 with required content | ENFORCED — No exceptions |

---

## Part 7: Final Quality Checklist (MANDATORY VERIFICATION)

### Pre-Output Verification (MUST complete before finalizing)

STOP and verify each item. If ANY check fails, fix it before outputting. Do NOT save the HTML file until ALL checks pass:

| # | Check | Pass Criteria |
|---|-------|---------------|
| 0 | Research Notes | "Research Notes" section present BEFORE Chapter 1 with table of sources visited (5+ rows with `<a href>` links) and list of search queries (5+ queries). |
| 1 | Section count | Exactly 7 sections present in the HTML output (PLUS Research Notes before Ch1) |
| 2 | Section 1: Executive Summary | Has 3+ key findings and 2+ recommendations |
| 3 | Section 3: Supplier Landscape | Lists 10+ suppliers with name, clickable `<a href>` store link (`<a href="https://SUPPLIER.en.alibaba.com" target="_blank" class="link-store-btn">LABEL_VIEW_STORE</a>`), MOQ, price (or states shortfall) |
| 4 | Section 4: Products | Lists 20+ products with image (`<img src="https://s.alicdn.com/...">`), name, price, MOQ, supplier, and clickable `<a href>` product detail link (`<a href="https://www.alibaba.com/product-detail/..." target="_blank" class="link-store-btn">LABEL_VIEW_DETAILS</a>`) (or states shortfall) |
| 5 | Section 6: SEO Keywords | Lists 10+ keywords by category (or states shortfall) |
| 6 | Template structure | CSS, sidebar, section order, layout IDENTICAL to source template |
| 7 | Output file location | Saved in `b2b-reports/` directory, NOT in `assets/templates/` |
| 8 | Source template unchanged | `assets/templates/` files are unmodified |
| 9 | No placeholder remnants | No `...` tags remain unreplaced (or marked as "Data Unavailable") |
| 10 | Industry adaptation | All content is specific to the requested industry, not ceramics |
| 11 | Source citations | Chapters 1-6 have inline `<a href>` citation links (Ch1-2: 2+, Ch3: 10+, Ch4: 20+, Ch5-6: 2+). No plain-text-only URLs. |
| 12 | Ch7 source block | Chapter 7 ends with a visible "Chapter References" block (`<h3>` heading) containing clickable `<a href>` source links (2+ sources) |
| 13 | Ch7 comprehensive data table | Chapter 7 ends with a "Data Source Table" table (`<h3>` heading) with 4 columns (Data, Value, Source, Link). Link column has clickable `<a href>` tags. 20+ rows covering data from ALL chapters. |
| 14 | Ch1 citations | Chapter 1 has 2+ inline `<a href>` citation links after key statistics/claims |
| 15 | Ch2 citations | Chapter 2 has 2+ inline `<a href>` citation links after market data/export statistics |
| 16 | Ch3 citations | Chapter 3 has 10+ supplier store `<a href>` links (one per supplier) |
| 17 | Ch4 citations | Chapter 4 has 20+ product `<a href>` links (one per product) |
| 18 | Ch5-Ch6 citations | Chapters 5 and 6 each have 2+ inline `<a href>` citation links |
| 19 | Ch7 citations + compiled source list | Chapter 7 has inline `<a href>` citations, "Chapter References" block (`<h3>`), "Data Source Table" table (`<h3>`), AND the end-of-report compiled "Reference List" clickable list (`<h2>` heading inside `<div class="source-list">`) organized by category: Suppliers, Products, Price Data, Market Research, Trade Policy, Keywords, Strategy, Other — with 10+ total URLs |
| 20 | Ch7 Chart.js interactive charts | Chapter 7 contains 2+ Chart.js interactive charts (`<canvas>` elements with Chart.js initialization scripts). Chart.js CDN is included. Charts use real report data. Fallback static tables present if Chart.js fails. |
| 21 | Ch4 "View on Alibaba" buttons | Every product row in Chapter 4 has a "View on Alibaba" button (`<a href>` with class `link-store-btn`) linking to the real Alibaba product page. All 20+ products have this button. |
| 22 | Data table search/filter bars | Every `<table>` with 5+ rows has a search input above it with `filterTable()` JavaScript function. Search inputs are styled consistently and functional. |
| 23 | Chapter 7 completeness | Chapter 7 contains ALL 11 required components: strategy intro, 3+ recommendations, channel strategy, risk table (4+ risks), 2+ Chart.js charts, Alibaba optimization plan, action roadmap, 2+ inline citations, "Chapter References" block, "Data Source Table" table, "Reference List" compiled list. Chapter 7 is NOT a short summary. |
| 24 | Chapter 7 length | Chapter 7 is substantial (comparable to or longer than Chapters 3-5). If Chapter 7 is noticeably shorter than other chapters, it is INCOMPLETE — go back and add missing components. |

### Completion Contract

The task is considered COMPLETE only when ALL conditions below are satisfied:

1. Industry research completed with verified data.
2. ALL 7 SECTIONS present in the report (count and verify).
3. Minimum data quantities met: 10+ suppliers, 20+ products, 10+ SEO keywords (or explicit shortage noted).
4. Pricing intelligence completed with correct industry units.
5. Template structure preserved (CSS, layout, sidebar unchanged).
6. Final HTML report saved to `b2b-reports/Bao_cao_nganh_INDUSTRY_Alibaba.html`.
7. Source template files in `assets/templates/` are UNMODIFIED.
8. File path returned in final response.
9. Chapters 1-6 contain inline `<a href>` citation links (Ch1-2: 2+, Ch3: 10+ supplier store links, Ch4: 20+ product links, Ch5-6: 2+). Per **SOURCE CITATION RULES (MANDATORY - ALL CHAPTERS)** > **Per-Chapter Source Requirements** table.
10. Chapter 7 end-of-report compiled source list per **Compiled Source List Rule ("Reference List")**: `<div class="source-list">` block with `<h2>` title containing ALL referenced URLs organized by category (Suppliers, Products, Price Data, Market Research, Trade Policy, Keywords, Strategy, Other). Every URL cited anywhere in all 7 chapters MUST appear as a clickable `<a href>` link. A list with fewer than 10 total URLs or missing any data category is INCOMPLETE.
11. Chapter 7 displays a **"Chapter References"** source block (using `<h3>` tag) per **Per-Chapter Research Sources Display (Chapter 7 ONLY)** > **Per-Chapter Source Block Rules (Chapter 7 ONLY)** (6 rules):
    - Only Chapter 7 displays this block (Chapters 1-6 use inline citations only)
    - Sources MUST be clickable `<a href>` links
    - Minimum 2 sources in the block
    - Source descriptions must be meaningful
    - Block is IN ADDITION TO the compiled "Reference List" list
12. Chapter 7 includes a comprehensive **"Data Source Table"** table (using `<h3>` tag) per **Chapter 7 Comprehensive Data Source Table (Chapter 7 ONLY)** > **Data Source Table Rules (Chapter 7 ONLY)** (6 rules):
    - Only Chapter 7 includes this table (Chapters 1-6 do NOT have data source tables)
    - EVERY data point from ALL chapters MUST appear as a row
    - "Link" column MUST contain clickable `<a href>` tags
    - Data descriptions must be specific (exact values)
    - Minimum 20+ rows total covering all chapters
13. **Evidence Rules (STRICT - Source Citation Enforcement)** satisfied: all 8 rules pass including **No plain text URLs**, **Minimum sources per chapter** (Ch1-6 inline citations, Ch7 source block + data table + compiled list), **URL captured at extraction**. All 8 rules have "ENFORCED — No exceptions".
14. **Fallback Policy** source citation rows satisfied: **Source URL not found** and **Source citations missing** (Ch1-6 inline citations, Ch7 source block + data table + compiled list) fallback rules applied. All 14 fallback cases verified (all "ENFORCED — No exceptions").
15. **Chapter 7 Interactive Chart.js Charts** satisfied: Chapter 7 contains 2+ interactive Chart.js charts (`<canvas>` elements with real data), Chart.js CDN is included in the HTML, each chart has responsive sizing and a visible title, and fallback static tables are present for each chart. Per **CHAPTER 7 INTERACTIVE CHART.JS CHARTS (MANDATORY)** (6 rules).
16. **Chapter 4 "View on Alibaba" buttons** satisfied: Every product row in Chapter 4 has a "View on Alibaba" button (`<a href>` with class `link-store-btn`) linking to the actual Alibaba product page URL. All 20+ products include this button. Per **CHAPTER 4 PRODUCT DATA FORMAT** field 7 and strict rule 7.
17. **Data Table Search/Filter Bars** satisfied: Every `<table>` with 5+ rows has a search/filter input above it, the `filterTable()` JavaScript function is included in the HTML, and all search inputs are styled consistently. Per **DATA TABLE SEARCH/FILTER BAR (MANDATORY - ALL TABLES)** (6 rules).
18. **Chapter 7 Complete Structure** satisfied: Chapter 7 contains ALL 11 mandatory components in order (strategy intro, 3+ recommendations, channel strategy, risk table, 2+ Chart.js charts, Alibaba optimization, action roadmap, inline citations, source block, data table, compiled source list). Chapter 7 is NOT a short/summary chapter. Per **CHAPTER 7 COMPLETE STRUCTURE (MANDATORY — DO NOT SKIP ANY PART)**.
19. **Pre-Save Verification Checklist** completed: ALL 19 items (including item 0: Research Notes) in the **PRE-SAVE VERIFICATION CHECKLIST (MANDATORY — RUN BEFORE EVERY SAVE)** were checked and PASSED before saving. No item was skipped. The DO NOT OMIT rule was followed. Per **SECTION COUNT ENFORCEMENT RULES** rule 5.
20. **Research Notes** satisfied: Report begins with a "Research Notes" section before Chapter 1 containing: table of 5+ sources visited (with `<a href>` links and data descriptions) and list of 5+ search queries used. Per **RESEARCH NOTES (MANDATORY — BEFORE CHAPTER 1)** (6 rules).

### FAILURE RECOVERY

If you discover during verification that any check fails, fix it BEFORE saving the HTML file. Do NOT output an incomplete report. All Evidence Rules and Fallback Policy rules are marked "ENFORCED — No exceptions" — none may be skipped. **You MUST run the Pre-Save Verification Checklist (18 items) before every save. If any item fails, DO NOT SAVE until it is fixed.**
- Research Notes section missing → Add "Research Notes" section before Chapter 1 with: table of sources visited (5+ rows with `<a href>` links, data extracted per source) and list of search queries used (5+ queries). Do NOT save without this section
- Sections are missing → Add them immediately before saving
- Product count < 20 → Search for more products; if unavailable, add explicit note
- Supplier count < 10 → Search for more suppliers; if unavailable, add explicit note
- Template was modified → Discard changes, re-read fresh template, start output generation again
- Source citations missing → Add inline `<a href>` citation links to all factual claims in Chapters 1-6 before saving; ensure Chapter 7 has: "Chapter References" source block, comprehensive "Data Source Table" data table (20+ rows), AND compiled "Reference List" source list
- Any chapter has fewer than 2 inline source citations → STOP and add more `<a href>` citation links before saving (Ch3: 10+, Ch4: 20+)
- Chapter 7 missing source block or data table → Add "Chapter References" block (2+ `<a href>` sources) AND "Data Source Table" comprehensive table (20+ rows from ALL chapters) to Chapter 7 before saving
- Chapter 1 or 2 missing citations → Add 2+ inline `<a href>` citation links before continuing
- Chapter 5 or 6 missing citations → Add 2+ inline `<a href>` citation links before continuing
- Chapter 7 missing compiled source list → Add "Reference List" list before saving. This list MUST contain EVERY URL from ALL 7 chapters organized by category: (1) Supplier store URLs, (2) Product listing URLs, (3) Price data source URLs, (4) Market research source URLs, (5) Trade policy & regulation URLs, (6) Keyword research URLs, (7) Strategy source URLs, (8) All other cited URLs. Each entry must have a meaningful description AND a clickable `<a href>` link. If any category is missing or the list has fewer than 10 URLs, go back and add missing sources
- Before final output, verify: (a) Chapters 1-6 each have inline `<a href>` citations (Ch1-2: 2+, Ch3: 10+, Ch4: 20+, Ch5-6: 2+), (b) Chapter 7 has source block + comprehensive data table + compiled source list. If any chapter is missing citations, go back and add them before saving the file
- Before final output, verify Chapter 7 has the compiled "Reference List" list (`<div class="source-list">` block with `<h2>` title) containing ALL URLs cited in all 7 chapters organized by category (Suppliers, Products, Price Data, Market Research, Trade Policy, Keywords, Strategy, Other) as clickable `<a href>` links. If this list is missing, incomplete, or has fewer than 10 URLs, go back and add all missing URLs before saving
- Chapter 7 missing Chart.js charts → Add 2+ interactive Chart.js charts with real report data before saving. Include Chart.js CDN `<script>` tag. Add fallback static tables for each chart. Do NOT save if Chapter 7 has fewer than 2 charts
- Chapter 4 missing "View on Alibaba" buttons → Add a "View on Alibaba" button (`<a href>` with class `link-store-btn`) to EVERY product row linking to the real Alibaba product page. All 20+ products must have this button before saving
- Data tables missing search/filter bars → Add a search input with `filterTable()` JavaScript function above every `<table>` with 5+ rows. Include the `filterTable()` script in the HTML file. Do NOT save if any qualifying table lacks a search bar
- Chapter 7 is too short or missing components → Chapter 7 MUST have ALL 11 components (see CHAPTER 7 COMPLETE STRUCTURE table). If ANY component is missing, STOP and add it before saving. Chapter 7 must NOT be a short summary — it should be comparable in length to Chapters 3-5. Verify: strategy recommendations, channel analysis, risk table, 2+ charts, optimization plan, action roadmap, citations, source block, data table, compiled source list
- Chapter 7 copied template structure without expansion → The reference template's Chapter 7 may be short. DO NOT replicate this. You MUST expand Chapter 7 with full strategy analysis, risk table, charts, action roadmap, and all source components

Never stop after research.
Never stop after analysis.
Never stop after recommendations.
Never reduce scope without explicit shortage explanation.

The final deliverable is the HTML report with ALL 7 sections and minimum data quantities.

Research alone does NOT satisfy task completion.