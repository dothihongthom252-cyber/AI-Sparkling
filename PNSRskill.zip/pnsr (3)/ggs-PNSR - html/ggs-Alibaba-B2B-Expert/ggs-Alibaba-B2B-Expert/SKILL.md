---
name: ggs-Alibaba-B2B-Expert-html
description: |
  Industry-adaptive Alibaba.com B2B market intelligence and global export strategy skill for Vietnam manufacturers, exporters, and B2B brands.

  When to Use:
    - Alibaba market reports for any requested industry
    - Vietnam export analysis for any requested industry
    - Supplier landscape research on Alibaba.com
    - Supplier list Alibaba / Alibaba supplier analysis
    - Competitor benchmarking and factory benchmark analysis
    - Pricing intelligence, MOQ analysis, lead-time comparison
    - SEO keyword mapping for Alibaba.com listings
    - Product trend analysis and product benchmark reports
    - Product image benchmark analysis
    - Premium interactive HTML export reports using the provided reference template
    - DOCX export reports using a provided or inferred template structure
    - Vietnamese requests: bao cao thi truong Alibaba, phan tich xuat khau, nghien cuu nganh hang, phan tich doi thu, phan tich supplier, bao cao B2B, bao cao HTML, bao cao xuat khau

  Core Rule:
    - Always identify the user's requested industry first.
    - Use `assets/templates/Template.html` as the base template for structure, depth, visual style, and analysis quality.
    - Adapt the template to any requested industry; do not restrict reports to a single industry.
    - For every requested industry, build a fresh industry profile, benchmark logic, pricing logic, buyer personas, and strategy recommendations.
    - Default report mode is full-intelligence-report.
    - Default HTML style is premium-visual.
    - Every completed report must be exported as an HTML file unless the user explicitly requests another format only.
enabled: true
---

## ⚡ PERFORMANCE PRIORITY

This skill MUST complete report generation within 10 MINUTES. To achieve this:
- Do NOT re-read or re-open the output file after saving — the task is complete once the file is written
- ONE verification pass only (Pre-Save Checklist) — no additional audits
- Write all chapters in a SINGLE output pass — do not write chapter by chapter
- Do NOT spawn sub-agents for verification — verify inline during generation
- Prioritize SPEED over exhaustive data collection — quality data over quantity
- DO NOT open the generated HTML file in a browser
- DO NOT use browser tools or browser agents for verification
- DO NOT spawn verification sub-agents that require browser connection
- All verification is done by reading the HTML source code directly (text-based only)

# Alibaba B2B Expert

Industry-adaptive Alibaba.com export intelligence toolkit for Vietnam suppliers. Use it to create full supplier research, competitor benchmarking, pricing intelligence, buyer persona analysis, product benchmarks, image analysis, and strategy reports for whichever industry the user requests.

Default deliverable: a premium responsive HTML report file. Do not finish a report-generation task with only chat text when file creation is available.

## 📅 CURRENT DATE ENFORCEMENT (MANDATORY)

- The current year is 2026. ALL data, statistics, and market information MUST be from 2025-2026.
- Report title, badge, and dates MUST show 2026 (e.g., "2026 Export Report")
- DO NOT use outdated data from 2023, 2024, or earlier unless showing historical trends
- When researching, always search for the LATEST available data (2025-2026)
- If only older data is available, clearly label it as historical and note the year

## 🔗 LINK VERIFICATION (MANDATORY)

ALL links in the report MUST be real and currently working:
- Supplier store links: Must be actual Alibaba.com store URLs that load correctly (e.g., `https://[supplier-name].en.alibaba.com`)
- Product links: Must be actual Alibaba.com product page URLs (e.g., `https://www.alibaba.com/product-detail/[product-name]_[product-id].html`)
- Source/citation links: Must be real, accessible URLs to the cited source
- DO NOT use placeholder URLs like `https://www.alibaba.com/...` or `#`
- DO NOT use made-up/fabricated URLs
- DO NOT use expired or dead links
- Every `<a href="...">` tag must point to a REAL, WORKING page
- If you cannot verify a link works, DO NOT include it — use descriptive text instead

### How to find real links:
1. Supplier stores: Search Alibaba.com for the supplier name → use their actual storefront URL
2. Products: Search Alibaba.com for the product → use the actual product detail page URL
3. Sources: Use the actual URL from your research (Statista, ITC Trade Map, etc.)

⚠️ CRITICAL: A report with broken or fake links is INVALID. Verify each URL is real before including it.

## 🏷️ BRAND NAME (STRICT)

The brand name is ALWAYS "Alibaba B2B Expert".
DO NOT use: "Sales Buddy", "Frank", "Market Intelligence Pro", or any other name.
Sidebar brand text should show: "Báo cáo thị trường B2B" (Vietnamese) / "B2B Market Report" (English) / "B2B市场报告" (Chinese)

---

## Part 1: Industry Profile Builder

### Core Principle

Build a fresh industry profile for every requested industry. The user may ask for furniture, apparel, food, handicrafts, packaging, machinery, beauty, home decor, agricultural products, or any other export category. The agent must adapt the report to that industry instead of using a fixed industry pack.

### Reference Sample Role

| File | Role | Important Rule |
|------|------|----------------|
| `assets/templates/Template.html` | Base template for premium HTML structure, visual density, section depth, dashboard layout, table style, and analysis quality | Use as the visual model to adapt for any industry. READ-ONLY — never modify. |

### Industry Identification Flow

| Step | Action |
|------|--------|
| 1 | Identify the requested industry AND language AND origin country from the user prompt. Language = same as prompt language. Origin = specified country or default Vietnam |
| 2 | Create an industry slug, e.g. `noi-that-viet-nam`, `may-mac-viet-nam`, `thu-cong-my-nghe-viet-nam` |
| 3 | Define the product taxonomy for that industry |
| 4 | Define benchmark criteria specific to that industry |
| 5 | Define pricing units, MOQ logic, and sourcing assumptions for that industry |
| 6 | Define compliance/certification topics relevant to that industry |
| 7 | Define SEO keyword themes and buyer-intent keywords for that industry |
| 8 | Generate the report using the premium reference structure, replacing all sample data with verified data for the requested industry |

### Dynamic Industry Profile Schema

For every report, create this mental profile before writing:

| Field | Required Content |
|-------|------------------|
| Industry slug | Lowercase identifier for the requested industry |
| Product scope | Exact product categories covered in the report |
| Target buyers | Importers, wholesalers, retailers, distributors, brands, hotels, factories, or project buyers |
| Supplier benchmark criteria | Industry-specific credibility, capability, product, quality, and export-readiness factors |
| Product benchmark criteria | Materials, design, use cases, variants, customization, packaging, visuals, and claims |
| Pricing units | Units that make sense for the industry, such as piece, set, kg, ton, carton, sqm, cbm, container |
| MOQ logic | How MOQ is normally expressed and compared in the industry |
| Compliance focus | Certifications, safety rules, documentation, and restricted claims that are relevant and visible |
| SEO themes | Core product, material, process, origin, buyer-intent, and target-market keywords |
| Export strategy angle | Positioning, product focus, Alibaba listing strategy, RFQ strategy, sample strategy, risk controls, buyer persona targeting |

### Example Industry Adaptation

If the user asks for furniture, build furniture-specific criteria such as:

| Area | Furniture-Specific Logic |
|------|--------------------------|
| Product taxonomy | indoor furniture, outdoor furniture, wooden furniture, rattan furniture, hotel furniture, restaurant furniture, office furniture, bedroom/living/dining categories |
| Materials | solid wood, plywood, MDF, veneer, bamboo, rattan, metal frame, upholstery, foam, fabric, leather alternatives |
| Pricing units | piece, set, carton, cbm, container, FOB unit price if visible |
| MOQ | pieces, sets, mixed container, full container load when visible |
| Compliance | FSC, BSCI, ISO, CARB P2, TSCA Title VI, fire retardant, OEKO-TEX for upholstery only if visible |
| Benchmark | factory scale, OEM/ODM, project experience, packaging, KD/flat-pack capability, customization, export markets |
| SEO | Vietnam furniture supplier, wooden furniture manufacturer, custom hotel furniture, rattan outdoor furniture, OEM furniture factory |

> **Note on SEO**: SEO keyword research is used during data collection to inform content, but there is no longer a dedicated "SEO Keyword Map" chapter in the report. Keywords inform the analysis across all chapters.

---

## Part 2: Execution Modes

### Default Mode

Always use `full-intelligence-report` for report generation requests unless the user explicitly asks for a quick, simplified, or lightweight output.

Always use `premium-visual` as the default HTML style unless the user explicitly requests simple HTML.

### Mode Table

| Mode | Use When | Minimum Evidence | Output Depth |
|------|----------|------------------|--------------|
| `quick-analysis` | User explicitly asks for a fast snapshot | 5+ suppliers, 10+ products when available | Key findings, price corridor, risks, next actions |
| `standard-report` | User explicitly asks for a medium report | 10+ suppliers, 20+ products when available | Supplier landscape, pricing, product benchmark, buyer personas, strategy |
| `full-intelligence-report` | Default for reports, HTML, DOCX, dashboards, or competitor analysis | MUST include: 10+ suppliers, 20+ products, 3+ buyer personas. If fewer exist on Alibaba, include ALL available and state the shortfall explicitly. | Full industry report, premium template-based HTML/DOCX, charts/tables, source list |

### Full-Intelligence Report Must Include

- Supplier landscape analysis.
- Competitor positioning analysis.
- Pricing intelligence tables and charts.
- Product benchmark analysis.
- Factory benchmark analysis when data exists.
- Product image analysis and assessment when image/listing evidence exists.
- Buyer persona analysis with persona cards.
- RFQ (Request for Quotation) analysis.
- Strategy recommendations.
- Research notes with source transparency.
- Premium visual deliverables in requested formats.

### Supported Formats

| Format | Default Behavior |
|--------|------------------|
| Markdown | Use structured report sections and tables |
| Responsive HTML | Default required deliverable; use premium-visual template style |
| DOCX | Use template-first document structure when a DOCX template is available |

Do not downgrade to `quick-analysis`, `standard-report`, `simple-html`, or `advanced-interactive` unless the user explicitly requests a simplified output.

### HTML File Output Contract

For every report-generation request, create a physical `.html` file unless the user explicitly asks for Markdown-only, DOCX-only, or no file output.

| Requirement | Instruction |
|-------------|-------------|
| Output format | Always create a premium responsive HTML file by default |
| File naming | Use a readable industry slug, e.g. `Bao_cao_nganh_Noi_that_Alibaba.html`, `Bao_cao_nganh_May_mac_Alibaba.html` |
| Output folder | Prefer `b2b-reports/` in the current workspace or the platform-provided output directory |
| Output creation | Automatically create `b2b-reports/` if it does not exist and save the report there |
| Template | Use `assets/templates/Template.html` as the base template |
| Final response | Include the saved HTML file path and a short completion note |
| No silent completion | Do not stop after analysis; the task is complete only when the HTML file exists or the environment prevents file creation |

If the environment prevents writing files, explain the blocker and provide the complete HTML content as a fallback.

### Data Freshness and Export Contract

- Never reuse prior session or cached report content; rebuild every report from verified current sources.
- Verify that supplier links, product listings, prices, and certifications are refreshed for each new report.
- Automatically write the HTML report file as part of the final response flow, without requiring a separate manual save step.

---

## Part 3: Research Workflow

### Data Collection

1. Confirm or infer industry, product scope, origin country, target market, buyer segment, language, and output format.
2. Build the dynamic industry profile before writing.
3. Use `assets/templates/Template.html` as the base template for output.
4. **Perform web searches and browse Alibaba.com** to collect real data. For EACH data type below, you MUST extract the specific information listed AND capture the exact source URL where it was found:

| Data Type | What to Extract | Where to Find | URL to Capture |
|-----------|----------------|---------------|----------------|
| **Suppliers** (Ch3) | Company name, store URL (`SUPPLIER.en.alibaba.com`), country, years on Alibaba, verification status, certifications, MOQ, price range, lead time, factory size, employee count, export markets, **estimated revenue (as reported by Alibaba)** | Alibaba supplier store pages, Alibaba search results | Store URL for EACH supplier (e.g., `https://supplier.en.alibaba.com`) |
| **Products** (Ch4) | Product title, image URL from `s.alicdn.com` CDN, FOB price range in USD, MOQ with unit, supplier name, product page URL (`alibaba.com/product-detail/...`) | Alibaba product listing pages, category pages | Product detail page URL for EACH product |
| **Pricing** (Ch7) | Price ranges per product category, FOB vs CIF pricing, price tiers by quantity, MOQ-based pricing, currency and Incoterms | Alibaba product pages, trade data sites | URL for EACH price data point |
| **Market data** (Ch1-2) | Market size (USD value), growth rate (% CAGR), export volume, demand trends, top exporting countries, top importing countries, trade statistics, industry forecasts | Industry reports, trade databases, news articles, Alibaba market pages | URL for EACH statistic or claim |
| **Trade policy** (Ch8) | Trade agreements (EVFTA, CPTPP, RCEP), tariff rates, compliance requirements, certification standards (ISO, CE, FDA), restricted substances, documentation requirements | Government trade portals, customs databases, industry compliance sites | URL for EACH regulation or policy cited |
| **Keywords** (research) | Search terms buyers use, search volume if available, keyword categories (core product, material, buyer-intent, origin, compliance), Alibaba search result URLs | Alibaba search bar autocomplete, Alibaba category pages, keyword tools | Alibaba search results URL for EACH keyword group |
| **Strategy sources** (Ch8) | Channel effectiveness data, competitor strategies, best practices, case studies, risk assessments | Industry publications, trade journals, Alibaba seller resources | URL for EACH strategic claim |

5. **For every data point extracted, IMMEDIATELY record the source URL.** Do NOT collect data first and try to find URLs later — capture the URL at the moment of extraction.
6. Preserve original company names, listing titles, URLs, countries, certifications, MOQ, price ranges, and lead times exactly as found.
7. **If a web search returns no results for a data type**: Record the search query used, note "Data not found via web search [date]", and use descriptive text instead of a link. Only include a fallback `<a href>` link if you can verify it points to a real, working Alibaba category or search results page (see 🔗 LINK VERIFICATION above).

### Supplier Intelligence

| Required Field | Notes |
|----------------|-------|
| Supplier name | Preserve original spelling |
| Alibaba Store URL | Do not invent or shorten fake URLs. MUST be a direct clickable link to the supplier's Alibaba store page. Format: `<a href="https://SUPPLIER.en.alibaba.com" target="_blank" class="link-store-btn">LABEL_VIEW_STORE</a>` — Use translated label matching report language (EN: "View Store", VI: "Xem Store", ZH: "查看店铺") |
| Country/region | Record exactly as shown |
| Product focus | Product categories from the requested industry |
| Alibaba tenure | Include only if visible |
| Verification status | Include only if visible |
| Certifications | Preserve exact certification names only if visible |
| MOQ | Include unit and caveat |
| Price range | Include unit, MOQ, and visible Incoterms if available |
| Lead time | Include only if visible |
| Strengths/risks | Separate verified facts from analysis |
| Estimated revenue (as reported by Alibaba) | Include annual revenue range in USD as shown on Alibaba supplier profiles. Format: `$X.XM - $Y.YM`. Mark `Unavailable` if not visible on Alibaba |

### Product Benchmarking

Benchmark products using attributes that belong to the requested industry.

For every industry, compare:

- Product type and subcategory.
- Materials, process, specifications, and variants.
- Use case and buyer segment.
- Customization/OEM/ODM options.
- Packaging and export readiness.
- Listing image quality and product presentation.
- Compliance or certification claims only when visible.
- MOQ, price range, lead time, and sample policy when visible.

### Pricing Intelligence

Build pricing by the correct industry unit. Examples:

| Industry Type | Possible Units |
|---------------|----------------|
| Furniture | piece, set, carton, cbm, container |
| Apparel | piece, set, size/color SKU, carton |
| Food/agriculture | kg, ton, bag, carton, container |
| Packaging | piece, roll, sqm, carton, ton |
| Machinery | unit, set, line, spare part package |
| Building materials | piece, sqm, ton, pallet, container |

Always include MOQ and confidence notes. If prices are hidden, state `Unavailable`.

### SEO Mapping (for research — informs content across all chapters)

Map keywords by the requested industry to inform the analysis:

| Keyword Type | Required Logic |
|--------------|----------------|
| Core product | Main product terms buyers search |
| Origin/value | Vietnam, Vietnamese, handmade, OEM, factory, manufacturer, supplier when relevant |
| Buyer intent | wholesale, bulk, custom, private label, OEM, ODM, project, distributor |
| Material/process | Industry-specific material and process terms |
| Market/use case | Retail, hotel, restaurant, outdoor, industrial, food service, construction, etc. |
| Compliance | Only include compliance keywords that are relevant and verified or clearly framed as target keywords |

---

## Part 4: Premium Template-Based Output

### Template Priority

If a designed HTML, DOCX, or other report template is available, use it as the primary output structure. Do not redesign the report unless the user explicitly asks for a redesign.

For stored templates or workspace-provided samples, look under `assets/templates/`.

| Template | Role | Use |
|----------|------|-----|
| `assets/templates/Template.html` | Base template | Use as the visual and structural model; adapt all industry content while preserving the premium layout |

### Mandatory Adaptation Rule

When using the reference sample for a new industry:

1. Replace the report title, meta text, sidebar section names if needed, and all industry wording.
2. Replace all industry-specific suppliers, products, market statements, chart values, and recommendations with those of the requested industry.
3. Rebuild benchmark criteria for the requested industry.
4. Rebuild pricing units and MOQ logic for the requested industry.
5. Rebuild buyer personas for the requested industry.
6. Rebuild strategy recommendations for the requested industry.
7. Keep the premium visual structure and interaction style.

### Premium HTML Requirements

- Premium dashboard layout.
- Responsive sections.
- Executive summary metric cards.
- Advanced tables.
- Visual benchmark blocks.
- Product image analysis sections when data exists.
- Buyer persona cards.
- Pricing intelligence charts.
- Modern typography.
- Print-friendly formatting.
- Branded visual structure.
- Interactive navigation when supported.

### Template Rules

| Rule | Instruction |
|------|-------------|
| Preserve design | Keep layout, typography, colors, sidebar, headers, footers, spacing, cards, chart containers, and table styles |
| Replace data | Replace placeholders, sample text, old supplier data, chart values, and conclusions with verified research data |
| Adapt industry | Rewrite all product taxonomy, benchmark logic, pricing logic, buyer personas, and strategy for the requested industry |
| Keep structure | Keep section depth and premium feel; section names may change to fit the requested industry |
| Handle missing data | Use `Unavailable` and explain the limitation |
| Treat sample as sample | Re-verify every supplier, price, market figure, certification, and source claim in completed sample templates |
| Avoid fake content | Do not invent suppliers, prices, certifications, URLs, charts, or product claims |

### Template Protection Rules (STRICT - NO EXCEPTIONS)

| Rule | Instruction |
|------|-------------|
| READ-ONLY SOURCE | Files in `assets/templates/` are READ-ONLY references. NEVER modify, overwrite, or save output back to `assets/templates/`. |
| OUTPUT LOCATION | ALL generated reports MUST be saved to `b2b-reports/` directory. NEVER save to `assets/templates/`. |
| OUTPUT NAMING | Use format: `b2b-reports/Bao_cao_nganh_INDUSTRY_SLUG_Alibaba.html` (e.g., `Bao_cao_nganh_Noi_that_Alibaba.html`) |
| STRUCTURAL LOCK | The following elements from the template MUST remain IDENTICAL in the output: CSS styles, sidebar navigation structure, section order (1-8), header/footer, responsive grid layout, typography, color scheme |
| FOOTER LAYOUT | The footer MUST retain `margin-left: 0` (it inherits sidebar offset from `.main-content { margin-left: var(--sw) }`). Never remove or alter the footer's margin-left property, as this causes overlap with the sidebar. |
| GOOGLE TRANSLATE (BANNED) | Google Translate is NOT allowed in reports. The AI MUST NOT add Google Translate scripts (`translate.google.com`), widgets (`#google_translate_element`), iframes, or any translation-related JavaScript. Reports must be written directly in the user's requested language. The language is set per report and must not be switchable at runtime. |
| ALLOWED CHANGES | Replace `PLACEHOLDER` values with real data; translate section titles to match industry; add data rows within existing table/grid structures |
| FORBIDDEN CHANGES | Do NOT modify CSS; Do NOT remove sections; Do NOT reorder sections; Do NOT change layout/grid structure; Do NOT remove sidebar; Do NOT alter JavaScript functions; Do NOT change fonts or colors; Do NOT restructure HTML nesting; Do NOT add Google Translate scripts, widgets, iframes, or any translation-related code; Do NOT remove footer `margin-left: 0` property |

### File I/O Contract (STRICT)

```
INPUT:  Read template from `assets/templates/Template.html` → NEVER write back
OUTPUT: Create NEW file at `b2b-reports/Bao_cao_nganh_INDUSTRY_SLUG_Alibaba.html`
```

Workflow:
1. Read source template (read-only)
2. Replace all `PLACEHOLDER` tags with industry-specific data
3. Mentally verify all 8 sections are present in output (text-based check during generation, NOT by re-reading the saved file)
4. Audit all source citations BEFORE saving — verify: (a) Chapters 1-7 each have inline `<a href>` source links (Ch1-2: 2+, Ch3: 10+, Ch4: 20+, Ch5: product images per card, Ch6-7: 2+), (b) Chapter 8 has compiled "Reference List" source list organized by category with 5+ URLs, (d) all 5 Chart.js charts present (Ch2: shareChart, growthChart, exportCountriesChart, importCountriesChart; Ch7: priceChart), (e) every Chapter 4 product has a "View on Alibaba" button, (f) NO search bars or filter inputs in any table, (g) ALL data types have source URLs (suppliers, products, RFQs, prices, market data, trade policy, keywords, strategy), (h) Chapter 8 ends with "Research Notes" subsection containing sources visited table and search queries list. If any check fails, fix before saving.
5. Save to `b2b-reports/` directory (create directory if needed)
6. Confirm output file path ≠ source template path
7. **WORKFLOW ENDS HERE** — Do NOT open the file in a browser, do NOT re-read the saved file, do NOT perform any post-save verification. The task is COMPLETE.

### Recommended Placeholder Map

Use or infer these fields when editing templates:

| Placeholder | Meaning |
|-------------|--------|
| `{{header_banner_image}}` | URL for header banner background image (product/industry relevant) |
| `{{report_title}}` | Report title (in `<title>` tag) |
| `{{report_title_heading}}` | Report title (in header banner `<h1>`) |
| `{{report_subtitle}}` | Report subtitle text |
| `{{badge_text}}` | Badge text above title |
| `{{sidebar_brand}}` | Sidebar brand name |
| `{{report_date}}` | Report date |
| `{{creator_name}}` | Name of the person/company who created the report |
| `{{creator_email}}` | Email address of the report creator (for `mailto:` link) |
| `{{creator_phone}}` | Phone number of the report creator (for `tel:` link) |
| `{{ch1_nav_label}}` to `{{ch8_nav_label}}` | Sidebar navigation labels for each chapter |
| `{{ch1_title}}` to `{{ch8_title}}` | Section title for each chapter |
| `{{footer_brand}}` | Footer brand name |
| `{{footer_description}}` | Footer description text |
| `{{footer_contact_heading}}` | Footer contact card heading |
| `{{footer_year}}` | Copyright year |
| `{{sources}}` | Source list |

### HTML Output

- Use `assets/templates/Template.html` as the base template for all industries.
- Create and save a `.html` file as the default final artifact.
- Do not finish with only a summary if an HTML report file can be created.
- Preserve responsiveness and print-friendly styling.

### FOOTER CREATOR CONTACT (MANDATORY)

Before generating the report, the AI MUST ask the user for their contact information:
- "Vui lòng cung cấp thông tin liên hệ của bạn để hiển thị trong báo cáo:"
  - Tên (name)
  - Email
  - Số điện thoại (phone)

If the user does not provide this info, use the placeholders `creator_name`, `creator_email`, `creator_phone` and remind the user to fill them in later.

The footer displays this as STATIC TEXT (not a form):
- Creator name
- Email (as clickable `mailto:` link)
- Phone number (as clickable `tel:` link)

| Placeholder | Meaning |
|-------------|--------|
| `{{creator_name}}` | Name of the person or company who created/commissioned the report |
| `{{creator_email}}` | Their email address (used in `mailto:` link) |
| `{{creator_phone}}` | Their phone number (used in `tel:` link) |

#### Rules:

1. **Always fill in the placeholders.** If the user provides their name, email, or phone, replace the `{{creator_*}}` placeholders with the real values. If any field is not provided, use the placeholder as-is and remind the user.
2. **Each report is personalized.** Different creators will have different contact info — this makes each report unique to its creator.
3. **Preserve the 2-column grid layout.** The footer uses `.footer-grid` with 2 columns: brand block (left, `.footer-brand-block`) + contact card (right, `.footer-contact-card`). Do NOT alter this layout.
4. **Preserve the `margin-left: 0`** on the `<footer>` element as required by the FOOTER LAYOUT rule.
5. **Keep the copyright bar** (`<div class="foot-bottom">`) below the contact section.

⚠️ This is NOT a form for customers to fill in. This is the report creator's OWN contact info displayed for readers to reach out directly.

- Use charts only when verified data supports them.
- If Chart.js or JavaScript fails, keep all content in static HTML.
- If images are blocked or unavailable, continue without images and mark image data unavailable.

### Chart.js Rendering Rules (MANDATORY — NO EXCEPTIONS)

All Chart.js charts in generated HTML reports MUST follow these rules to prevent broken rendering, infinite-height canvases, and empty chart containers:

| Rule | Requirement |
|------|-------------|
| Canvas attributes | ALL `<canvas>` elements MUST have explicit `width` and `height` HTML attributes set (e.g., `width="700" height="350"`). Never leave a `<canvas>` without dimensions. |
| Chart options | ALL Chart.js initializations MUST include `options: { responsive: true, maintainAspectRatio: true, aspectRatio: 2 }` (or a similar numeric `aspectRatio` between 1.4 and 2.5). |
| Container sizing | Every chart `<canvas>` MUST be wrapped in a `.chart-box` div (or equivalent fixed-height container) with `max-height: 420px`, `overflow: hidden`, and `position: relative`. |
| Null/undefined checks | Before creating any `new Chart(...)`, verify that the canvas element exists AND that `Chart` is defined. Use the `initChart()` helper from `Template.html` as the pattern. |
| Graceful fallback | If Chart.js CDN fails to load or chart data is unavailable, display a styled `.chart-fallback` placeholder message (e.g., "Chart data unavailable") instead of an empty or broken canvas. |
| No infinite stretch | NEVER set `maintainAspectRatio: false` without also providing explicit container height constraints. Prefer `maintainAspectRatio: true` with `aspectRatio` set. |
| CSS safety net | The CSS MUST include `canvas { max-height: 400px !important; }` and `.chart-box canvas { max-height: 400px !important; }` to prevent any canvas from stretching infinitely. |

#### Chart Font Rules (MANDATORY):

ALL Chart.js charts MUST specify font family as 'Lexend' in ALL text elements to prevent broken/messy font rendering:

| Chart Element | Required Font Config |
|---------------|---------------------|
| Legend labels | `plugins.legend.labels.font.family = 'Lexend'`, size 12px |
| Chart title | `plugins.title.font.family = 'Lexend'`, size 16px |
| X-axis ticks | `scales.x.ticks.font.family = 'Lexend'`, size 11px |
| Y-axis ticks | `scales.y.ticks.font.family = 'Lexend'`, size 11px |

- DO NOT leave font family undefined on any chart element — it causes rendering issues
- The `initChart()` helper MUST merge Lexend font family into ALL chart options including scales
- Every individual chart config MUST also specify `font: { family: 'Lexend' }` on title and tick elements

### Header Banner Rules

| Rule | Requirement |
|------|-------------|
| Background image | The `.header-banner` MUST use a relevant product/industry image URL as `background-image` via the `{{header_banner_image}}` placeholder. Choose an Unsplash, Pexels, or industry-relevant image URL that matches the report's product category. |
| Gradient overlay | The banner MUST have a semi-transparent dark gradient overlay (e.g., `linear-gradient(135deg, rgba(7,22,44,0.92), rgba(0,43,91,0.82))`) layered ON TOP of the background image so text remains readable. |
| Fallback color | When no image URL is provided, the banner MUST fall back to a solid `background-color: var(--p)` (dark navy) so the header never appears broken. |
| CSS properties | The banner MUST include `background-size: cover; background-position: center center;` and a constrained height (`min-height: 260px; max-height: 320px`). |

### DOCX Output

- Prefer a matched DOCX template when available.
- If no DOCX template exists, mirror the premium HTML report structure in a clean DOCX layout.
- Preserve paragraph styles, table styles, headers, footers, brand colors, and pagination when using a template.
- Keep clickable source `<a href>` URLs in tables or footnotes.
- Use compact supplier, product, pricing, and keyword matrices.

### Chapter 6: Buyer Personas & Image Analysis (MANDATORY — Visual Analysis Required)

Chapter 6 MUST include buyer persona cards AND actual product image analysis from suppliers on Alibaba. This chapter combines buyer segmentation with visual product assessment.

#### Chapter 6 Requirements:

| Requirement | Description |
|-------------|-------------|
| **Buyer Personas** | Display 3+ buyer persona cards in a 3-column grid layout. Each persona card MUST have: (1) heading with persona name/type, (2) checklist of 3-5 characteristics (buyer type, requirements, purchasing behavior, preferences) |
| **Product images** | MUST include ACTUAL product image URLs from `s.alicdn.com` (real Alibaba CDN image URLs). At least **2-4 product images** displayed with AI analysis |
| **Image display** | Each image shown as `<img src="https://s.alicdn.com/...">` with prominent sizing (~200-250px height) |
| **Supplier info** | Each image MUST show: supplier name, product name |
| **AI analysis** | Each image MUST have: quality assessment, visual appeal evaluation, improvement suggestions, comparison notes |
| **Layout** | Use `.persona-grid` (3-column) for persona cards and `.grid-2` for image analysis cards per the Template |

#### Chapter 6 Structure:

1. **Buyer Persona Subsection**: 3+ persona cards in `.persona-grid` (3-column grid). Each card has `<h4>` heading + `<ul>` checklist of characteristics
2. **Image Analysis Subsection**: 2-4 product images in `.grid-2` layout. Each card has: product image (220px height), analysis paragraph (2-3 sentences on quality, lighting, staging, visual appeal)

#### Chapter 6 Strict Rules:

1. **Image URLs MUST be real**: Extract actual image URLs from `s.alicdn.com` CDN. NEVER use placeholder images or stock photos.
2. **Minimum 2-4 images**: A report with fewer than 2 product images analyzed is considered incomplete.
3. **Analysis MUST be substantive**: Each analysis paragraph must address: lighting quality, background cleanliness, product staging, color accuracy, visual appeal for B2B buyers, and specific improvement recommendations.
4. **Persona cards required**: At least 3 buyer personas with detailed characteristics checklists.
5. **Grid layouts required**: Use `.persona-grid` for personas and `.grid-2` for image analysis per the Template structure.

---

## Google Translate — BANNED (MANDATORY — NO EXCEPTIONS)

Google Translate is **NOT allowed** in generated reports. The AI MUST NOT add, preserve, or re-add any Google Translate components.

| Rule | Requirement |
|------|-------------|
| No scripts | NEVER include `<script src="translate.google.com/...">` or any Google Translate CDN script tag |
| No widgets | NEVER include `<div id="google_translate_element">` or any Google Translate widget markup |
| No init functions | NEVER include `googleTranslateElementInit()` or any Google Translate initialization JavaScript |
| No CSS | NEVER include `.goog-te-*` CSS rules or any Google Translate styling |
| No iframes | NEVER include Google Translate iframe elements |
| Single language | Each report is written in ONE language (the user's requested language). The language is fixed at generation time and MUST NOT be switchable at runtime |
| Remove if inherited | If the template contains Google Translate components, the AI MUST **remove them entirely** from the generated output — do NOT copy them over |

⚠️ CRITICAL: If a generated report contains any Google Translate code, the report is INVALID.

### Footer Layout Rule

The `<footer>` element lives inside `.main-content` (which already applies `margin-left: var(--sw)` to offset the sidebar). The footer's own CSS must include `margin-left: 0` and must NOT be moved outside `.main-content` or given an additional `margin-left: var(--sw)`, as that would cause a double-offset. On responsive breakpoints (≤720px) the footer must reset padding to `2rem 1.5rem 1rem 1.5rem`.

---

## Part 5: Report Structure (MANDATORY 8 SECTIONS)

For `full-intelligence-report`, the report MUST contain ALL 8 chapter sections listed below. No section may be omitted, merged, or skipped. Section names may be translated or adapted to the industry, but the section MUST still exist with equivalent content. Research Notes are included as a subsection at the END of Chapter 8 (not as a separate section).

### RESEARCH NOTES (MANDATORY — INSIDE CHAPTER 8, AT THE END)

The report MUST include a **"Research Notes"** (Research Notes) subsection placed at the **END of Chapter 8** (after all other Chapter 8 components). This subsection documents all data collected during web research and provides full transparency on sources.

#### Research Notes Requirements:

| Component | Description | Minimum |
|-----------|-------------|--------|
| Sources visited | List of websites/pages visited during research with clickable `<a href>` links | 3+ sources |
| Keywords searched | Search queries used to find data (e.g., "Vietnam furniture suppliers Alibaba", "FOB price wooden table") | 3+ search queries |
| Key data per source | For each source: what data was extracted (supplier names, prices, market stats, etc.) | Match each source to its data |
| URLs captured | The exact URL where each data point was found | Every data point must have a URL |

#### Research Notes HTML Structure:

```html
<!-- Research Notes — placed as the LAST subsection inside Chapter 8 (sec8) -->
<div class="research-notes" style="margin-top: 2rem; padding: 1.5rem; background: #f0f4f8; border-left: 4px solid var(--primary); border-radius: 4px;">
  <h2 class="section-title" style="font-size: 1.1rem;"><i class="fa-solid fa-magnifying-glass"></i> LABEL_RESEARCH_NOTES</h2>
  <p style="font-size: 0.82rem; color: #576574; margin-bottom: 1rem;">Data in this report was collected from the following verified sources:</p>
  
  <h3 style="font-size: 0.9rem; margin-bottom: 0.5rem;"><i class="fa-solid fa-globe"></i> Sources Accessed</h3>
  <table style="width: 100%; font-size: 0.8rem; border-collapse: collapse; margin-bottom: 1.5rem;">
    <thead>
      <tr style="background: var(--primary); color: white;">
        <th style="padding: 6px 8px; text-align: left;">#</th>
        <th style="padding: 6px 8px; text-align: left;">Source</th>
        <th style="padding: 6px 8px; text-align: left;">Data Collected</th>
        <th style="padding: 6px 8px; text-align: left;">Link</th>
      </tr>
    </thead>
    <tbody>
      <!-- EXAMPLE ROW - Replace with REAL URLs from actual research -->
      <tr>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">1</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">Alibaba.com - Supplier Search "vietnam [industry]"</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">10 supplier names, store URLs, MOQ, price ranges</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;"><a href="https://www.alibaba.com/trade/search?SearchText=vietnam+industry+supplier" target="_blank" class="citation">View</a></td>
      </tr>
      <tr>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">2</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">Alibaba.com - Product Listing</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;">20 product listings, images, FOB prices</td>
        <td style="padding: 4px 8px; border-bottom: 1px solid #eee;"><a href="https://www.alibaba.com/trade/search?SearchText=industry+product+vietnam" target="_blank" class="citation">View</a></td>
      </tr>
      <!-- Repeat for ALL sources visited - EVERY link MUST be a REAL working URL -->
    </tbody>
  </table>

  <h3 style="font-size: 0.9rem; margin-bottom: 0.5rem;"><i class="fa-solid fa-magnifying-glass"></i> Search Queries Used</h3>
  <ul style="font-size: 0.8rem; line-height: 1.7; padding-left: 1.2rem;">
    <li><code>vietnam INDUSTRY supplier alibaba</code></li>
    <li><code>INDUSTRY FOB price wholesale</code></li>
    <li><code>INDUSTRY export market data 2026</code></li>
    <!-- List ALL search queries used -->
  </ul>
</div>
```

#### CRITICAL: ALL LINKS MUST BE REAL AND WORKING

**EVERY `<a href="...">` in the generated HTML report MUST point to a REAL, accessible URL.** Links that do not work when clicked are a critical failure.

| Rule | Instruction |
|------|-------------|
| NO placeholder URLs | NEVER use generic URLs like `alibaba.com/suppliers/...`, `alibaba.com/category/...`, or any URL with `...` or `placeholder` |
| NO invented URLs | NEVER fabricate URLs. Every URL must come from an actual page you visited during research |
| URL format for Alibaba search | Use: `https://www.alibaba.com/trade/search?SearchText=keyword+keyword` (replace spaces with +) |
| URL format for Alibaba product | Use: `https://www.alibaba.com/product-detail/Product-Name_PRODUCTID.html` (exact URL from the listing) |
| URL format for Alibaba store | Use: `https://STORENAME.en.alibaba.com` (exact store URL from supplier profile) |
| VALIDATION | Before saving: mentally verify every URL follows a valid pattern. If any URL contains `...`, `placeholder`, `example`, or looks generic — it is INVALID. Replace with a real URL or remove the link |

**How to get REAL URLs:**
1. When you search Alibaba, the search page URL is: `https://www.alibaba.com/trade/search?SearchText=your+search+query` — USE THIS EXACT URL as the source
2. When you find a product, the listing URL is: `https://www.alibaba.com/product-detail/Product-Title_1234567890.html` — COPY THIS EXACT URL
3. When you find a supplier, their store URL is: `https://storename.en.alibaba.com` — COPY THIS EXACT URL
4. If you cannot obtain a real URL for a source, write "URL unavailable — data collected from Alibaba search results" instead of a fake link

#### Research Notes Rules:

1. **MUST appear at the END of Chapter 8** — The Research Notes subsection is the LAST content subsection inside Chapter 8 (sec8), placed after all other Chapter 8 components.
2. **Every source visited MUST be listed** with a clickable `<a href>` link and description of data extracted.
3. **Every search query used MUST be listed** so the reader can verify or replicate the research.
4. **Minimum 3 sources and 3 search queries** — a report with fewer is considered under-researched.
5. **The "Link" column MUST contain clickable `<a href>` tags** — plain text URLs are NOT acceptable.
6. **ENFORCED — No exceptions**: Missing the Research Notes subsection makes the output invalid. Do NOT save the HTML file without it.

### STRICT SECTION REQUIREMENTS

| # | Section | Purpose | Minimum Content |
|---|---------|---------|------------------|
| 1 | Executive Summary (Tóm tắt điều hành) | Top opportunities, risks, and recommended direction | 3+ key metric cards, 1 highlight box, summary paragraph, 3+ inline `<a href>` citation links (market statistics, growth rate, opportunity size) |
| 2 | Global Market Overview (Tổng quan thị trường toàn cầu) | Demand signals, export context, product scope, target buyers, target markets, top exporting AND importing countries | **MANDATORY STRUCTURE (MUST follow this EXACT order — NO exceptions):** (1) 3 insight pills with key stats; (2) Market share doughnut chart (`shareChart`) + growth line chart (`growthChart`) in `.market-chart-grid`; (3) "Top Exporting Countries" section: `<h3>` heading, table with minimum 5–10 countries (columns: #, Country, Est. Export Volume/Share, Key Insights), horizontal bar chart (`exportCountriesChart`); (4) "Top Importing Countries" section: `<h3>` heading, table with minimum 5–10 countries (columns: #, Country, Est. Import Share, Trend), horizontal bar chart (`importCountriesChart`); 2+ inline `<a href>` citation links. **Both exporting AND importing country tables + charts are REQUIRED — NEVER omit either one.** |
| 3 | Supplier Landscape (Bức tranh nhà cung cấp) | Alibaba suppliers with credibility comparison, factory benchmark, competitor positioning | MINIMUM 10 suppliers total with name, working store URL, products, revenue, years on platform, "View Store" button. For NICHE industries: split into Part A (origin country, real links only) + Part B (global, to reach 10 total). See NICHE INDUSTRY HANDLING rules. |
| 4 | Top-Selling Products (Sản phẩm bán chạy) | Materials, use cases, customization, packaging, image benchmark | MINIMUM 20 products. EACH product MUST have: (1) product image URL from Alibaba CDN `s.alicdn.com`, (2) original product name from listing, (3) FOB price range in USD, (4) MOQ, (5) supplier name, (6) direct clickable `<a href>` link to the product page on alibaba.com, (7) "View on Alibaba" button linking to the real Alibaba product page. 20+ product `<a href>` links |
| 5 | Buyer RFQ Requests (Yêu cầu báo giá RFQ) | Related RFQs on Alibaba.com displayed as card-based grid layout with images and rich descriptions | MINIMUM 5 RFQ cards displayed as **card-based grid layout** (2 columns desktop, 1 column mobile). Each RFQ card MUST have: (1) product image from `s.alicdn.com`, (2) RFQ title (original from Alibaba, bold), (3) detailed description (2-3 sentences minimum — product specifications, materials, intended use, certifications, volume potential). Use `.rfq-grid` wrapper with `.rfq-card` class per the Template. **Do NOT add individual "View RFQ on Alibaba" buttons** to cards |
| 6 | Buyer Personas & Image Analysis (Chân dung người mua & Phân tích hình ảnh) | Buyer segmentation with persona cards + visual product image assessment | 3+ buyer persona cards in 3-column `.persona-grid` (each with heading + checklist of 3-5 characteristics), AND 2-4 product images with AI analysis in `.grid-2` layout (quality, lighting, staging, visual appeal assessment). 2+ inline `<a href>` citation links |
| 7 | Pricing Intelligence (Phân tích giá bán) | Price corridor, MOQ, unit caveats, confidence levels, sub-category pricing | Price chart (`priceChart` — grouped bar) + market potential box + sub-category pricing table (3+ tiers), unit consistency, source note, 2+ inline `<a href>` citation links |
| 8 | Strategy & Research Notes (Chiến lược & Ghi chú nghiên cứu) | Positioning, strategy recommendations, conclusion, source list, research notes | ALL COMPONENTS REQUIRED: (1) Strategy intro paragraph, (2) 3+ strategy cards with numbered badges (01, 02, 03...) in `.strategy-grid`, (3) conclusion highlight box, (4) Research Notes subsection at the end (sources visited table with `<a href>` links + search queries list). Chapter 8 MUST be comprehensive — NOT a short summary. |

### SECTION COUNT ENFORCEMENT RULES

1. Count your output sections BEFORE finalizing. If fewer than 8 sections exist, STOP and add the missing sections.
2. If data for a section is genuinely unavailable, keep the section header and write: "Data unavailable for this industry on Alibaba.com. Recommendation: [suggest alternative data source]."
3. NEVER silently omit a section. NEVER merge two sections into one without including all required content from both.
4. Section names may be renamed to fit the industry (e.g., "Supplier Landscape" → "Featured Suppliers") but must cover the same scope.
5. **DO NOT OMIT ANY CONTENT (KHÔNG ĐƯỢC BỎ SÓT BẤT KỲ NỘI DUNG NÀO)**: Every section, data point, source citation, and structural component defined in this skill MUST be included in the final output. If you are unsure whether something is required, INCLUDE IT. Omitting required content is a critical failure. Before saving the HTML file, you MUST verify every item in the **Pre-Save Verification Checklist** below. If any item fails, STOP and fix it before saving.

### CHAPTER 2 STABILITY ENFORCEMENT (MANDATORY — FIXED STRUCTURE, NO DEVIATION)

The Chapter 2 (Market Overview) structure is **FIXED**. The AI MUST follow the EXACT HTML structure from `Template.html` every single time. This is NOT optional — consistency across all generated reports is CRITICAL.

**Chapter 2 MANDATORY STRUCTURE (MUST follow this EXACT order — NO exceptions):**

1. **3 insight pills** with key market statistics
2. **Share and growth charts**: `<canvas id="shareChart">` (doughnut) and `<canvas id="growthChart">` (line) in a `.market-chart-grid` wrapper
3. **"Top Exporting Countries (Sellers/Producers)"** section:
   a. `<h3>` heading with icon
   b. Table inside `.table-container`: minimum 5–10 countries, columns: `#`, `Country`, `Est. Export Volume / Market Share`, `Key Insights`
   c. Chart.js horizontal bar chart: `<canvas id="exportCountriesChart" width="700" height="350">` inside `.chart-box.wide`, using green color palette (#27AE60)
4. **"Top Importing Countries (Buyers)"** section:
   a. `<h3>` heading with icon
   b. Table inside `.table-container`: minimum 5–10 countries, columns: `#`, `Country`, `Est. Import Share`, `Trend`
   c. Chart.js horizontal bar chart: `<canvas id="importCountriesChart" width="700" height="350">` inside `.chart-box.wide`, using gold color palette (var(--g))

**STABILITY RULES (NON-NEGOTIABLE):**

- The template structure is **FIXED** — AI MUST follow the EXACT HTML structure from `Template.html`
- Every section ID (`sec1` through `sec8`) MUST be present in every output
- Every chart canvas ID MUST match EXACTLY: `shareChart`, `growthChart`, `exportCountriesChart`, `importCountriesChart`
- The AI MUST NOT skip, reorder, or rename any section or subsection
- If data is unavailable for a section, show "Data not available" placeholder text — NEVER omit the section entirely
- Exporting countries MUST appear BEFORE importing countries (exporters first, then importers)
- Both tables MUST use the `.table-container` wrapper and identical column structure
- Both charts MUST use the `initChart()` helper function with null-check pattern

**Chapter 2 ELEMENT CHECKLIST (verify ALL present before saving):**

- [ ] 3 insight pills (`.chart-insight` > `.insight-pill`) with key statistics
- [ ] `<canvas id="shareChart">` inside `.market-chart-grid` wrapper
- [ ] `<canvas id="growthChart">` inside `.market-chart-grid` wrapper
- [ ] `<h3>` heading: "Top Exporting Countries" with sub-title style
- [ ] Exporting countries table (5–10 rows) inside `.table-container`
- [ ] `<canvas id="exportCountriesChart">` inside `.chart-box.wide`
- [ ] `exportCountriesChart` Chart.js init in `<script>` (horizontal bar, green palette)
- [ ] `<h3>` heading: "Top Importing Countries" with sub-title style
- [ ] Importing countries table (5–10 rows) inside `.table-container`
- [ ] `<canvas id="importCountriesChart">` inside `.chart-box.wide`
- [ ] `importCountriesChart` Chart.js init in `<script>` (horizontal bar, gold palette)
- [ ] 2+ inline `<a href>` citation links in Chapter 2 text

### PRE-SAVE VERIFICATION CHECKLIST (MANDATORY — RUN BEFORE EVERY SAVE)

Before saving the HTML file, you MUST mentally (or in scratchpad) check each item below. Mark each as PASS or FAIL. If ANY item is FAIL, DO NOT SAVE — fix it first:

| # | Item to Verify | PASS Criteria | FAIL Action |
|---|---------------|--------------|-------------|
| 0 | Research Notes subsection | "Research Notes" subsection present at the END of Chapter 8 with 3+ sources visited (table with `<a href>` links) and 3+ search queries listed | Add Research Notes subsection inside Chapter 8 with all captured data |
| 1 | All 8 sections present | Count = 8 sections in HTML output | Add missing sections immediately |
| 2 | Chapter 1 content | 3+ key metric cards, 1 highlight box, summary paragraph, 3+ inline `<a href>` citations | Add missing content |
| 3 | Chapter 2 content | 3 insight pills, shareChart + growthChart in `.market-chart-grid`, **TOP exporting countries table (5-10 countries) + `exportCountriesChart`**, AND **TOP importing countries table (5-10 countries) + `importCountriesChart`**, 2+ inline `<a href>` citations | Add missing content — BOTH export AND import sections required |
| 4 | Chapter 3 suppliers | 10+ suppliers with store `<a href>` links, estimated revenue per supplier (or explicit shortage note) | Search for more suppliers or add shortage note |
| 5 | Chapter 4 products | 20+ products with images, prices, product `<a href>` links, "View on Alibaba" buttons (or explicit shortage note) | Search for more products or add shortage note |
| 5 | Chapter 5 RFQ cards | 5+ RFQ cards in card-based grid layout, each with product image from `s.alicdn.com` and detailed description (2-3 sentences), NO individual RFQ detail links or "View RFQ on Alibaba" buttons (or explicit shortage note) | Search for more RFQs or add shortage note |
| 6 | Chapter 6 buyer personas & images | 3+ buyer persona cards in `.persona-grid` (each with heading + checklist), AND 2-4 product images with AI analysis in `.grid-2`, 2+ inline `<a href>` citations | Add missing persona cards or image analysis |
| 7 | Chapter 7 pricing | `priceChart` (grouped bar) + market potential box + sub-category pricing table (3+ tiers), source note, 2+ inline `<a href>` citations | Add missing content |
| 8 | Chapter 8 completeness | ALL components present: strategy intro, 3+ strategy cards with numbered badges in `.strategy-grid`, conclusion highlight box, Research Notes subsection (sources table + search queries) | Add missing components |
| 10 | Chapter 8 compiled source list | "Reference List" with 5+ URLs organized by category | Add missing source URLs |
| 13 | Chapter 8 length | Substantial content (not a short summary) | Expand with missing components |
| 14 | No plain text URLs | All URLs wrapped in `<a href>` tags | Wrap bare URLs in links |
| 15 | Template preserved | CSS, layout unchanged from template. Sidebar LABELS translated to match report language (structure preserved, text translated) | Restore template structure; translate sidebar labels |
| 16 | Output location | File saved to `b2b-reports/`, not `assets/templates/` | Change save path |
| 17 | No search/filter bars | NO search bars or filter inputs present in any table | Remove any search/filter inputs |
| 18 | No placeholders | No `...` or unreplaced tags remain | Replace all placeholders |
| 19 | Footer shows creator contact info | Footer displays creator name, email (mailto: link), and phone (tel: link) as static text in 2-column grid layout (brand left + contact card right). No `<form>`, `<input>`, or `<textarea>` elements present. | Ensure creator contact info is filled in and displayed as static text |
| 20 | No Google Translate code | NO `translate.google.com` scripts, `#google_translate_element` divs, `googleTranslateElementInit` functions, `.goog-te-*` CSS, or any translation-related iframes present | Remove ALL Google Translate code from the report |

**CRITICAL**: If you skip this checklist and save an incomplete file, the output is INVALID. The checklist is NOT optional — it is a MANDATORY final gate before every save.

### DATA QUANTITY ENFORCEMENT RULES

1. Suppliers: MUST list at minimum 10 suppliers. If Alibaba shows fewer than 10 for the industry, list ALL available and add a note: "Only X suppliers found. Industry has limited Alibaba presence."
2. Products: MUST list at minimum 20 products. If fewer than 20 exist, list ALL available and add a note: "Only X products found on Alibaba for this category."
3. SEO Keywords: MUST include at minimum 5 keywords across categories (core product, origin, buyer-intent, material/process, market/use-case).
4. NEVER silently reduce quantities. If you list fewer than the minimum, you MUST include an explicit shortage explanation.

### NICHE INDUSTRY HANDLING (WHEN ORIGIN COUNTRY HAS LIMITED SUPPLIERS)

When searching Alibaba for suppliers from the user's specified origin country and the industry is niche (fewer than 10 active, verified suppliers found), apply this TWO-PART structure:

#### Detection Rule:
If you search Alibaba for the specified industry + origin country and find FEWER than 10 suppliers with active, working store pages — the industry is classified as **NICHE** for that country.

#### Two-Part Supplier Structure:

**Part A: Suppliers from ORIGIN_COUNTRY** (Niche Market)

| Requirement | Instruction |
|-------------|-------------|
| Header | Clearly label: "Nhà cung cấp từ COUNTRY (Thị trường ngách - Số lượng hạn chế)" / "Suppliers from COUNTRY (Niche Market - Limited Availability)" — match report language |
| Content | List ALL real, verified suppliers found from that country (even if only 2-3) |
| Niche indicator | Add a visible note/badge: "This is a niche industry on Alibaba with limited supplier presence from COUNTRY" |
| Links | EVERY supplier MUST have a real, working Alibaba store link. If the store page doesn't load, DO NOT list that supplier |
| Minimum | No minimum for Part A — list only what is genuinely available and verified |

**Part B: Top Global Suppliers on Alibaba** (All Countries)

| Requirement | Instruction |
|-------------|-------------|
| Header | Clearly label: "Nhà cung cấp hàng đầu trên Alibaba (Toàn cầu)" / "Top Alibaba Suppliers (Global)" — match report language |
| Content | List additional suppliers from ANY country to reach the minimum total of 10 suppliers |
| Country tag | Each supplier MUST show their country of origin (e.g., "China", "India", "Turkey") |
| Links | EVERY supplier MUST have a real, working Alibaba store link |
| Combined total | Part A + Part B combined MUST reach minimum 10 suppliers |

#### Visual Structure in HTML:

```html
<!-- Part A: Origin Country Suppliers -->
<div class="niche-notice" style="background: #FFF9E6; border-left: 4px solid #D4A017; padding: 1rem; border-radius: 4px; margin-bottom: 1.5rem;">
  <strong>⚠️ Niche Market Notice:</strong> INDUSTRY from COUNTRY has limited supplier presence on Alibaba.com. Only X verified suppliers found from this country.
</div>

<h3 class="sub-title">Part A: Suppliers from COUNTRY (X found)</h3>
<!-- Supplier table with only verified, active suppliers from origin country -->

<h3 class="sub-title">Part B: Top Global Suppliers (Y additional)</h3>
<!-- Supplier table with top suppliers from other countries to reach minimum 10 total -->
```

#### Rules:

1. **NEVER list a supplier with a non-working link** just to meet the quantity minimum. It is better to have 5 real suppliers than 10 fake ones.
2. **ALWAYS verify links work** before including a supplier. If you cannot confirm the store page exists, exclude that supplier.
3. **The niche notice is MANDATORY** when Part A has fewer than 3 suppliers — this tells the user the industry has limited online presence.
4. **Part B fills the gap** — search broadly on Alibaba (any country) for the same product category to find additional real suppliers.
5. **Same format for Chapter 4 (Products)**: If fewer than 20 products from the origin country, split into Part A (origin country products) and Part B (global top products) to reach 20 total.
6. **Country column required in Part B**: Every supplier/product in Part B MUST show its country of origin so the user knows it's not from their specified country.

### CHAPTER 4 PRODUCT DATA FORMAT (MANDATORY)

Every product listed in Chapter 4 MUST follow this exact data structure (matching the reference template `Template.html`):

| # | Required Field | Format | Source |
|---|----------------|--------|--------|
| 1 | Product Image | `<img src="https://s.alicdn.com/...">` - actual product thumbnail from Alibaba CDN | Extract directly from Alibaba product listing |
| 2 | Product Name | Original listing title in English, wrapped in `<strong>` tag | Copy exactly from Alibaba listing |
| 3 | FOB Price Range | Format: `$X.XX - $Y.YY` in USD | From Alibaba listing price display |
| 4 | MOQ | Number + unit (e.g., "100 pieces", "50 sets") | From Alibaba listing |
| 5 | Supplier Name | Full company name as shown on Alibaba | From supplier profile |
| 6 | Product Link | Direct URL to `alibaba.com/product-detail/...` wrapped in clickable `<a href>` button with class `link-store-btn` | From Alibaba product page URL |
| 7 | View on Alibaba Button | `<a href="PRODUCT_URL" target="_blank" class="link-store-btn">View on Alibaba</a>` — MUST link to the actual Alibaba product listing page | Same URL as field 6 |

#### HTML Table Structure (MUST follow this format):

```html
<table>
  <thead>
    <tr>
      <th>#</th>
      <th>Product Image (Alibaba CDN)</th>
      <th>Product Name (Original)</th>
      <th>FOB Price Range (USD)</th>
      <th>MOQ</th>
      <th>Verified Supplier</th>
      <th>Product Link</th>
      <th>View on Alibaba</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>1</td>
      <td><img src="https://s.alicdn.com/@sc04/kf/..." style="border-radius:4px; object-fit:cover; width:60px; height:60px;" alt="p1"></td>
      <td><strong>Original Product Title From Alibaba</strong></td>
      <td>$X.XX - $Y.YY</td>
      <td>100 pieces</td>
      <td>SUPPLIER NAME</td>
      <td><a href="https://www.alibaba.com/product-detail/..." target="_blank" class="link-store-btn">LABEL_VIEW_DETAILS</a></td>
      <td><a href="https://www.alibaba.com/product-detail/..." target="_blank" class="link-store-btn">View on Alibaba</a></td>
    </tr>
    <!-- Repeat for all 20 products -->
  </tbody>
</table>
```

#### STRICT RULES FOR CHAPTER 4:

1. **Image URLs MUST be real**: Extract actual image URLs from `s.alicdn.com` CDN. NEVER use placeholder images, stock photos, or invented URLs.
2. **Product links MUST be real**: Every product MUST have a working direct clickable `<a href>` link to its Alibaba.com product page (`alibaba.com/product-detail/...`). NEVER invent or fabricate product URLs.
3. **All 20 products MUST have images and links**: Do NOT list products as text-only. If an image URL cannot be found, use the supplier's store logo as fallback and note "Image unavailable."
4. **Supplier links**: In Chapter 3 (Supplier Landscape), each supplier MUST also have a direct clickable `<a href>` link to their Alibaba store page.
5. **Link format**: All links must use `target="_blank"` and class `link-store-btn` for consistent button styling.
6. **If images are blocked by the environment**: Keep the `<img>` tags with correct `src` URLs even if you cannot visually verify them. The URLs must be genuine Alibaba CDN paths extracted during research.
7. **"View on Alibaba" button is MANDATORY**: Every product row MUST include a “View on Alibaba” button (`<a href>` with class `link-store-btn`) that links to the actual Alibaba product page. This button must use the same real product URL as field 6. NEVER omit this button.

### SOURCE CITATION RULES (MANDATORY - ALL CHAPTERS)

Every chapter in the report MUST include inline source citations with clickable links. Data without a source link is considered unverified and incomplete.

#### Citation Format:

Use the `citation` class for inline source links within the text:
```html
<a href="https://www.alibaba.com/..." target="_blank" class="citation">[Source]</a>
```

#### Per-Chapter Source Requirements:

| Chapter | What MUST be cited with links | Link Format |
|---------|-------------------------------|-------------|
| 1 - Executive Summary | Key market statistics, growth claims, opportunity figures | `<a href="SOURCE_URL" target="_blank" class="citation">[Source]</a>` after each claim |
| 2 - Global Market Overview | Market size data, demand trends, export statistics, trade data | Inline citation links after each statistic or market claim |
| 3 - Supplier Landscape | Each supplier's Alibaba store URL, verification status source | `<a href="https://SUPPLIER.en.alibaba.com" target="_blank" class="link-store-btn">LABEL_VIEW_STORE</a>` per supplier row |
| 4 - Top-Selling Products | Product page URL for each product (already enforced above) | `<a href="https://www.alibaba.com/product-detail/..." target="_blank" class="link-store-btn">LABEL_VIEW_DETAILS</a>` |
| 5 - Buyer RFQ Requests | Illustrative product images for each RFQ card | Each card MUST have a product image from `s.alicdn.com` |
| 6 - Buyer Personas & Image Analysis | Persona research source, image analysis source | `<a href="URL" target="_blank" class="citation">[Source]</a>` after persona data and image analysis |
| 7 - Pricing Intelligence | Source URL for each price data point, price comparison source | Footnote or inline link per price row: `<a href="URL" target="_blank" class="citation">[Price Source]</a>` |
| 8 - Strategy & Research Notes | Sources for recommendations, trade regulations, compliance requirements | `<a href="URL" target="_blank" class="citation">[Source]</a>` after each factual claim |

#### Source Citation Strict Rules:

1. **Every factual claim MUST have a source**: Any data point (price, MOQ, market size, growth rate, certification, trade statistic) MUST be followed by a clickable source link.
2. **Sources MUST be clickable**: Plain text URLs or "(Source: alibaba.com)" without `<a href>` tags are NOT acceptable. All sources must be wrapped in clickable `<a>` tags.
3. **Sources MUST be real**: NEVER fabricate source URLs. If a source cannot be found, write "Source: Alibaba.com research [date]" but still attempt to link to the relevant search or category page.
4. **Minimum sources per chapter**: Each chapter MUST have at least 2 source citations with clickable links. Chapter 3 and 4 will naturally have 5+ and 10+ respectively. Chapter 8 must also have the compiled "Reference List" list containing ALL source URLs from all chapters.
5. **Compiled Source List Rule ("Reference List")**: Chapter 8 MUST end with a compiled "Reference List" list containing ALL URLs referenced throughout all 8 chapters of the report, formatted as a clickable `<a href>` list. This list is the MASTER bibliography of the entire report and MUST include EVERY URL from ALL of the following categories:
   - **Supplier URLs**: Direct links to every supplier's Alibaba store page (from Chapter 3)
   - **Product URLs**: Direct links to every product's Alibaba listing page (from Chapter 4)
   - **Price data source URLs**: URLs where price ranges, FOB pricing, and cost data were obtained (from Chapter 7)
   - **Market research source URLs**: URLs for market size, growth rate, export volume, demand trends, and industry statistics (from Chapters 1-2)
   - **Trade policy & regulation source URLs**: URLs for trade agreements, compliance requirements, certifications, and regulatory data cited in the report
   - **Keyword research source URLs**: URLs for Alibaba search results pages and keyword data sources (research phase)
   - **Strategy source URLs**: URLs supporting strategic recommendations (from Chapter 8)
   - **Any other data source URL**: Every remaining URL cited anywhere in the report that does not fall into the above categories

**CRITICAL**: The compiled source list MUST be organized by category with clear headings (e.g., "Suppliers", "Products", "Price Data", "Market Research", "Trade Policy", "Keywords", "Strategy"). Each entry must include the source name/description AND the clickable URL. A compiled list with only generic links or fewer than 5 total URLs is INCOMPLETE.

#### Source List HTML Structure (at end of Chapter 8):

```html
<div class="source-list" style="margin-top: 2rem; padding-top: 1.5rem; border-top: 2px solid var(--bg);">
  <h2 class="sub-title"><i class="fa-solid fa-link"></i> LABEL_REFERENCE_LIST</h2>
  <ol style="font-size: 0.82rem; line-height: 1.8;">
    <!-- SUPPLIER URLs (from Chapter 3) -->
    <li><strong>Suppliers:</strong> <a href="https://supplier.en.alibaba.com" target="_blank" class="citation">Supplier Name - Alibaba Store</a></li>
    <!-- PRODUCT URLs (from Chapter 4) -->
    <li><strong>Products:</strong> <a href="https://www.alibaba.com/product-detail/..." target="_blank" class="citation">Product Name - Product Page</a></li>
    <!-- PRICE DATA URLs (from Chapter 7) -->
    <li><strong>Price Data:</strong> <a href="https://www.alibaba.com/..." target="_blank" class="citation">Price Source Description</a></li>
    <!-- MARKET RESEARCH URLs (from Chapters 1-2) -->
    <li><strong>Market Research:</strong> <a href="https://..." target="_blank" class="citation">Market Data Source - Description</a></li>
    <!-- TRADE POLICY URLs -->
    <li><strong>Trade Policy:</strong> <a href="https://..." target="_blank" class="citation">Trade Policy Source</a></li>
    <!-- KEYWORD RESEARCH URLs -->
    <li><strong>Keywords:</strong> <a href="https://www.alibaba.com/trade/search?SearchText=..." target="_blank" class="citation">Keyword - Alibaba Search Results</a></li>
    <!-- STRATEGY URLs (from Chapter 8) -->
    <li><strong>Strategy:</strong> <a href="https://..." target="_blank" class="citation">Strategy Source Description</a></li>
    <!-- ALL other cited URLs -->
  </ol>
</div>
```

*(Data Source Table removed — no longer required)*

### CHART.JS CHARTS ACROSS THE REPORT (MANDATORY)

The report contains **5 Chart.js charts** distributed across Chapters 2 and 7. All charts MUST use real data from the report — never use placeholder or dummy data.

#### Chart Distribution:

| Chapter | Chart ID | Chart Type | Description |
|---------|----------|------------|-------------|
| Chapter 2 | `shareChart` | Doughnut | Global market share by country/region |
| Chapter 2 | `growthChart` | Line | Export growth trend over years |
| Chapter 2 | `exportCountriesChart` | Horizontal bar (`indexAxis: 'y'`) | Top exporting countries |
| Chapter 2 | `importCountriesChart` | Horizontal bar (`indexAxis: 'y'`) | Top importing markets |
| Chapter 7 | `priceChart` | Grouped bar | Price range by sub-category (low/high) |

#### Chart Requirements:

1. **Charts MUST use real data** from the report — never use placeholder or dummy data.
2. **Chart.js CDN MUST be included**: `<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js">` in the HTML `<head>`.
3. **Use `initChart()` helper** from the template for all chart initialization (includes null-check pattern).
4. **Each chart MUST have**: a `<canvas>` element inside a `.chart-box` container, a Chart.js initialization script with real labels and datasets, responsive sizing, and a visible title.
5. **Fallback**: If Chart.js fails to load, the chart data MUST still be visible as a static HTML table below the `<canvas>` element.
6. **ENFORCED — No exceptions**: A report with fewer than 5 charts (or missing any chart ID above) is considered incomplete.

### CHAPTER 8 COMPLETE STRUCTURE (MANDATORY — DO NOT SKIP ANY PART)

Chapter 8 is the capstone chapter. It MUST contain ALL of the following components IN THIS EXACT ORDER. Missing ANY component makes the output INVALID:

| # | Component | Description | MANDATORY |
|---|-----------|-------------|----------|
| 1 | Chapter Title & Introduction | `<h2>` section title, intro paragraph setting the strategic context | YES — ENFORCED |
| 2 | Strategy Cards | 3+ strategy cards in `.strategy-grid` (3-column layout). Each card has: numbered badge (`<span class="strategy-no">01</span>`), `<h4>` title, `<p>` description | YES — ENFORCED |
| 3 | Conclusion Highlight Box | `<div class="highlight strategy-highlight">` with bold conclusion label + conclusion text summarizing the key strategic direction | YES — ENFORCED |
| 4 | Research Notes Subsection | `<div class="research-notes">` placed as the LAST subsection. Contains: sources visited table (`<table class="source-table">` with 3+ rows with `<a href>` links) and search queries list. Uses template CSS classes (`.research-notes`, `.source-table`) — NO inline styles needed | YES — ENFORCED |

**Chapter 8 MUST NOT be a short summary section.** If Chapter 8 is shorter than Chapters 3, 4, or 5, it is INCOMPLETE. Chapter 8 should typically be 800-1500 words including all components above.

**CRITICAL**: The template's Chapter 8 structure uses `.strategy-grid` for strategy cards (6 cards with numbered badges), `.highlight.strategy-highlight` for the conclusion box, and `.research-notes` for the final research notes subsection. Follow this exact template structure.

### NO SEARCH BARS OR FILTER INPUTS (STRICT - NO EXCEPTIONS)

DO NOT add any search bars or filter inputs to any table in the report. Tables are displayed as-is without filtering functionality. Do NOT include any `filterTable()` JavaScript function. Do NOT add any `<input>` elements with placeholder text like "Search products...", "Filter countries...", "Search data...", or similar filter/search inputs to any section.

### LANGUAGE & ORIGIN COUNTRY MATCHING (STRICT - NO EXCEPTIONS)

#### Language Matching Rule:

The ENTIRE output HTML report MUST be written in the SAME language as the user's prompt. This is automatic and non-negotiable:

| User Prompt Language | Report Output Language | Example |
|---------------------|----------------------|--------|
| English | ALL content in English | "Generate a report for pepper from India" → English report |
| Vietnamese (Tiếng Việt) | ALL content in Vietnamese | "Tạo báo cáo ngành gia vị Ấn Độ" → Vietnamese report |
| Chinese (中文) | ALL content in Chinese | "生成印度香料行业报告" → Chinese report |
| Any other language | Match that language | Report follows user's language |

#### What "ALL content" means — EVERY element must be in the matched language:

| Element | Must Match Language |
|---------|-------------------|
| Section titles & sidebar labels | YES — MUST be fully translated to match the report language (see SIDEBAR NAVIGATION & CHAPTER NAMING table) |
| Table headers | YES |
| Button labels ("Xem Chi Tiết" / "View Details" / "查看详情") | YES |
| Analysis text and descriptions | YES |
| Executive summary | YES |
| Strategy recommendations | YES |
| Source list labels | YES |
| Sidebar navigation labels | YES |
| Metadata (date format, currency labels) | YES |

#### EXCEPTIONS (keep original language regardless):
- Supplier company names → Keep original (e.g., "AURORA JSC" stays English)
- Product listing titles → Keep original from Alibaba (usually English)
- URLs → Keep as-is
- Certification names (ISO, FSC, BSCI) → Keep original
- Technical terms with no translation → Keep original + add translation in parentheses

#### Origin Country Matching Rule:

The report MUST focus on the country/region specified by the user, NOT default to Vietnam:

| User Request | Origin Country | Suppliers From |
|-------------|----------------|----------------|
| "report for pepper from India" | India | Indian suppliers on Alibaba |
| "báo cáo gốm sứ Việt Nam" | Vietnam | Vietnamese suppliers on Alibaba |
| "report for furniture from China" | China | Chinese suppliers on Alibaba |
| "análisis de café de Colombia" | Colombia | Colombian suppliers on Alibaba |
| No country specified | Vietnam (default) | Vietnamese suppliers on Alibaba |

**Rules:**
1. If the user specifies a country, ALL supplier research must focus on that country's sellers on Alibaba.com.
2. Only default to Vietnam if NO origin country is mentioned or implied.
3. The report title, industry slug, and file name must reflect the correct origin country.
4. File naming: `b2b-reports/Bao_cao_nganh_INDUSTRY_COUNTRY_Alibaba.html` (e.g., `Bao_cao_nganh_Pepper_India_Alibaba.html`)
5. If the report language is English, use English file naming: `b2b-reports/Report_INDUSTRY_COUNTRY_Alibaba.html`

#### Language Detection Flow:

| Step | Action |
|------|--------|
| 1 | Detect the language of the user's prompt |
| 2 | Set report language = detected language |
| 3 | Detect origin country from prompt (default: Vietnam if not specified) |
| 4 | Set `origin_country` = detected country |
| 5 | Generate ALL report content in the detected language |
| 6 | Search Alibaba for suppliers from `origin_country` |
| 7 | Name output file using language conventions |

#### UI Label Translation Table (MANDATORY):

All report UI labels MUST be translated to match the report language. Use these exact translations:

| Vietnamese (default) | English | Chinese (中文) | Usage |
|---------------------|---------|---------------|-------|
| Ghi chú nghiên cứu | Research Notes | 研究笔记 | Subsection at end of Chapter 8 |
| Nguồn tham khảo chương này | Chapter References | 本章参考来源 | Source block in Chapter 8 |
| Danh sách nguồn tham khảo | Reference List | 参考来源列表 | Compiled source list in Chapter 8 |
| Xem Chi Tiết | View Details | 查看详情 | Product link button |
| Xem Store | View Store | 查看店铺 | Supplier store link button |
| Ảnh Sản Phẩm | Product Image | 产品图片 | Table header |
| Tên Sản Phẩm Bán Chạy | Product Name | 产品名称 | Table header |
| Dải Giá FOB | FOB Price Range | FOB价格区间 | Table header |
| Nhà Cung Cấp Uy Tín | Verified Supplier | 优质供应商 | Table header |
| Link Sản Phẩm Thực Tế | Product Link | 产品链接 | Table header |
| STT | # | 序号 | Row number header |
| Nguồn | Source | 来源 | Citation label |
| Nguồn giá | Price Source | 价格来源 | Price citation label |

**RULE: If the report language is NOT Vietnamese, you MUST translate ALL labels above to the matching language column. Do NOT leave any Vietnamese labels in a non-Vietnamese report. This applies to ALL HTML elements including headings, table headers, button text, section titles, and citation labels.**

**If the report language is a language not listed above (e.g., Spanish, Japanese, Korean), translate all labels to that language following the same pattern.**

#### SIDEBAR NAVIGATION & CHAPTER NAMING (MUST MATCH REPORT LANGUAGE):

ALL chapter titles, sidebar navigation labels, and section headings MUST be fully translated to the report language. Do NOT mix languages. Do NOT leave Vietnamese labels in a non-Vietnamese report.

**Sidebar Navigation Translation Table:**

| # | Vietnamese | English | Chinese (中文) |
|---|-----------|---------|---------------|
| Chapter 1 | 🚩 Chương 1: Tóm tắt | 🚩 Chapter 1: Executive Summary | 🚩 第1章: 执行摘要 |
| Chapter 2 | 🌐 Chương 2: Thị trường | 🌐 Chapter 2: Market Overview | 🌐 第2章: 市场概览 |
| Chapter 3 | 🏭 Chương 3: Nhà cung cấp | 🏭 Chapter 3: Supplier Landscape | 🏭 第3章: 供应商概况 |
| Chapter 4 | 🏆 Chương 4: Sản phẩm | 🏆 Chapter 4: Top Products | 🏆 第4章: 热销产品 |
| Chapter 5 | 📝 Chương 5: RFQ | 📝 Chapter 5: RFQ Listings | 📝 第5章: RFQ询价 |
| Chapter 6 | 🔍 Chương 6: Người mua | 🔍 Chapter 6: Buyer Personas | 🔍 第6章: 买家画像 |
| Chapter 7 | 🏷️ Chương 7: Giá bán | 🏷️ Chapter 7: Pricing | 🏷️ 第7章: 价格分析 |
| Chapter 8 | 🚀 Chương 8: Chiến lược | 🚀 Chapter 8: Strategy | 🚀 第8章: 战略与研究 |

**STRICT RULES:**
1. The sidebar navigation `<a>` text MUST use the labels from the column matching the report language.
2. The main content `<h2>` section titles MUST also match the report language (same translations).
3. Do NOT use "Chapter" prefix in non-English reports. Use: Vietnamese = "Chương", Chinese = "第X章", English = "Chapter X".
4. Do NOT mix languages in the sidebar. If ONE label is in Chinese, ALL must be in Chinese.
5. If the report language is not in the table above, translate all labels to that language consistently.

**Sidebar HTML Example (Chinese report):**
```html
<nav>
  <ul>
    <li><a href="#sec1"><i class="fa-solid fa-flag"></i> 第1章: 执行摘要</a></li>
    <li><a href="#sec2"><i class="fa-solid fa-globe"></i> 第2章: 市场概览</a></li>
    <li><a href="#sec3"><i class="fa-solid fa-warehouse"></i> 第3章: 供应商概况</a></li>
    <li><a href="#sec4"><i class="fa-solid fa-award"></i> 第4章: 热销产品</a></li>
    <li><a href="#sec5"><i class="fa-solid fa-clipboard-list"></i> 第5章: RFQ询价</a></li>
    <li><a href="#sec6"><i class="fa-solid fa-magnifying-glass"></i> 第6章: 买家画像</a></li>
    <li><a href="#sec7"><i class="fa-solid fa-tags"></i> 第7章: 价格分析</a></li>
    <li><a href="#sec8"><i class="fa-solid fa-rocket"></i> 第8章: 战略与研究</a></li>
  </ul>
</nav>
```

**Note on LABEL_* placeholders in this skill document:** When you see `LABEL_RESEARCH_NOTES`, `LABEL_CHAPTER_REFERENCES`, `LABEL_REFERENCE_LIST`, `LABEL_VIEW_DETAILS`, or `LABEL_VIEW_STORE` in HTML examples within this skill, replace them with the correct translated text from the UI Label Translation Table above based on the report language. These are NOT literal placeholders to leave in the output HTML — they represent the translated text you must insert.

---

## Part 6: Compliance And Fallbacks

> **Source citations are part of data completeness.** The output HTML file is NOT valid and NOT complete if any chapter is missing source citations with clickable `<a href>` links.

### Fallback Policy

| Failure Case | Fallback | Must be verified | Must be enforced |
|--------------|----------|------------------|------------------|
| Missing data | Mark `Unavailable` and explain | Check all `Unavailable` entries are genuinely missing, not skipped | ENFORCED — No exceptions |
| Thin data / Niche industry | If origin country has fewer than 10 suppliers for the industry: apply NICHE INDUSTRY HANDLING — split into Part A (origin country, verified only) + Part B (global suppliers to reach minimum). Mark as niche market. NEVER pad with fake/non-working links | Verify minimum data quantities are still met | ENFORCED — No exceptions |
| No dedicated industry template | Use `assets/templates/Template.html` and adapt all industry content | Verify all 8 sections adapted, no template-specific content remains | ENFORCED — No exceptions |
| Cannot write HTML file | Explain the blocker and provide complete HTML content | Verify complete HTML content is provided as fallback | ENFORCED — No exceptions |
| Charts unsupported | Replace with tables | Verify chart data is preserved in table format | ENFORCED — No exceptions |
| Images unavailable | Continue without images | Verify `<img>` tags are kept with correct `src` URLs even if not visually verified | ENFORCED — No exceptions |
| HTML failure | Produce simplified responsive HTML that follows the premium template | Verify all 8 sections present in simplified output | ENFORCED — No exceptions |
| JavaScript failure | Disable interactions and preserve static content | Verify static content is complete | ENFORCED — No exceptions |
| Conflicting data | Show conflict, clickable source `<a href>` URLs, and confidence level | Verify conflicting sources are shown as clickable `<a href>` links | ENFORCED — No exceptions |
| Source URL not found | Write “Source: Alibaba.com research [date]” and still provide a clickable `<a href>` link to the relevant Alibaba search or category page — never output a bare URL without a link | Verify every source has a clickable `<a href>` link, even fallback sources | ENFORCED — No exceptions |
| Source citations missing | Do NOT output the HTML file until all citations are added. Go back and add inline `<a href>` links to all factual claims in Chapters 1-7. Ensure Chapter 8 has compiled "Reference List" list. | Pre-output: count inline citations per chapter (Ch1-7: 2+, Ch3: 10+, Ch4: 20+, Ch5: images per card); verify Chapter 8 compiled list exists | ENFORCED — No exceptions |
| Chart.js charts missing | Verify all 5 Chart.js charts present (shareChart, growthChart, exportCountriesChart, importCountriesChart in Ch2; priceChart in Ch7) with real data. Include Chart.js CDN and fallback static tables. | Pre-output: count `<canvas>` elements; if < 5, STOP and add charts | ENFORCED — No exceptions |
| "View on Alibaba" buttons missing | Add "View on Alibaba" button to every Chapter 4 product row before saving. Each button links to real Alibaba product page. | Pre-output: count "View on Alibaba" buttons in Ch4; if < 20, STOP and add missing buttons | ENFORCED — No exceptions |
| Research Notes missing | Add "Research Notes" subsection at the END of Chapter 8 with sources visited table (3+ rows with `<a href>` links and data extracted per source) and search queries list (3+ queries). | Pre-output: verify "Research Notes" subsection exists at the end of Chapter 8 with required content | ENFORCED — No exceptions |

---


---
