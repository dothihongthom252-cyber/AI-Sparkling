import os
import sys
import json
import re
import hashlib


def render_report(template_path, json_data_path, output_path):
    print(f"Reading template from: {template_path}")
    with open(template_path, 'r', encoding='utf-8') as f:
        html_content = f.read()

    print(f"Reading data from: {json_data_path}")
    with open(json_data_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    print("Populating placeholders...")
    # Ensure header_banner_image has a default if not provided
    if 'header_banner_image' not in data:
        data['header_banner_image'] = ''
    # Render direct text placeholders (supports both {KEY} and {{key}} formats)
    for key, val in data.items():
        # Single-brace uppercase: {KEY_NAME}
        placeholder = f"{{{key.upper()}}}"
        # Double-brace lowercase: {{key_name}}
        placeholder_db = f"{{{{{key}}}}}"
        # If val is list or dict, we convert it to JSON-like string for JavaScript/Chart.js
        if isinstance(val, (list, dict)):
            val_str = json.dumps(val, ensure_ascii=False)
            html_content = html_content.replace(placeholder, val_str)
            html_content = html_content.replace(placeholder_db, val_str)
        else:
            html_content = html_content.replace(placeholder, str(val))
            html_content = html_content.replace(placeholder_db, str(val))

    # Create parent directories for output if they don't exist
    output_dir = os.path.dirname(output_path)
    if output_dir and not os.path.exists(output_dir):
        print(f"Creating directory: {output_dir}")
        os.makedirs(output_dir, exist_ok=True)

    print(f"Writing final HTML report to: {output_path}")
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_content)

    print("Success! HTML report generated successfully.")


def validate_structure(html_content):
    """Validate that the rendered HTML has the expected structural elements."""
    all_passed = True

    # Check all 8 section markers
    print("\n--- Structural Validation ---")
    for i in range(1, 9):
        # Match id="sec1", or "Chương 1", or generic section divs like class="section1"
        sec_pattern = (
            rf'(id=["\']sec{i}["\'])'
            rf'|(Chương\s+{i})'
            rf'|(class=["\'][^"\']*section{i}[^"\']*["\'])'
        )
        if re.search(sec_pattern, html_content, re.IGNORECASE):
            print(f"  \u2713 Section {i} marker found")
        else:
            print(f"  \u2717 Section {i} marker NOT found")
            all_passed = False

    # Check CSS <style> block is preserved
    if re.search(r'<style[^>]*>.*?</style>', html_content, re.DOTALL | re.IGNORECASE):
        print(f"  \u2713 CSS <style> block preserved")
    else:
        print(f"  \u2717 CSS <style> block MISSING")
        all_passed = False

    # Check sidebar structure is preserved
    if re.search(r'class=["\'][^"\']*sidebar[^"\']*["\']', html_content, re.IGNORECASE):
        print(f"  \u2713 Sidebar structure preserved")
    else:
        print(f"  \u2717 Sidebar structure MISSING")
        all_passed = False

    # Check for unreplaced PLACEHOLDER tags (both single-brace and double-brace)
    unreplaced = re.findall(r'\{[A-Z_][A-Z0-9_]*\}|\{\{[a-z_][a-z0-9_]*\}\}', html_content)
    # Filter out CSS/JS braces that aren't placeholders (e.g., {display:flex})
    unreplaced = [p for p in unreplaced if not re.match(r'\{[a-z]', p)]
    if unreplaced:
        print(f"  \u2717 Unreplaced placeholders found: {unreplaced}")
        all_passed = False
    else:
        print(f"  \u2713 No unreplaced placeholders found")

    # Check Google Translate widget is preserved
    if re.search(r'id=["\']google_translate_element["\']', html_content):
        print(f"  \u2713 Google Translate widget div preserved")
    else:
        print(f"  \u2717 Google Translate widget div MISSING")
        all_passed = False

    if re.search(r'googleTranslateElementInit', html_content):
        print(f"  \u2713 Google Translate init function preserved")
    else:
        print(f"  \u2717 Google Translate init function MISSING")
        all_passed = False

    if re.search(r'translate\.google\.com/translate_a/element\.js', html_content):
        print(f"  \u2713 Google Translate CDN script preserved")
    else:
        print(f"  \u2717 Google Translate CDN script MISSING")
        all_passed = False

    # Check footer has proper layout (margin-left set)
    if re.search(r'footer\s*\{[^}]*margin-left', html_content, re.DOTALL):
        print(f"  \u2713 Footer has explicit margin-left")
    else:
        print(f"  \u26a0 Footer may be missing explicit margin-left (check layout)")

    if all_passed:
        print("--- Validation PASSED ---\n")
    else:
        print("--- Validation FAILED ---\n")

    return all_passed


def validate_template_unchanged(template_path, original_hash):
    """Verify the source template file was not modified during rendering."""
    current_hash = _compute_md5(template_path)
    if current_hash == original_hash:
        print(f"  \u2713 Template file unchanged (MD5: {original_hash})")
        return True
    else:
        print(f"  \u2717 Template file was MODIFIED! Original MD5: {original_hash}, Current MD5: {current_hash}")
        return False


def _compute_md5(file_path):
    """Compute MD5 hash of a file."""
    hasher = hashlib.md5()
    with open(file_path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            hasher.update(chunk)
    return hasher.hexdigest()


def render_report_safe(template_path, json_data_path, output_path):
    """Safe render with structural validation and template integrity checks."""
    # Prevent overwriting templates by ensuring output is not in the same directory
    template_dir = os.path.dirname(os.path.abspath(template_path))
    output_dir = os.path.dirname(os.path.abspath(output_path))
    if os.path.normpath(template_dir) == os.path.normpath(output_dir):
        raise ValueError(
            f"Output path ({output_path}) is in the same directory as the template ({template_path}). "
            "Overwriting templates is not allowed."
        )

    # Compute MD5 hash of template before rendering
    print("Pre-render checks...")
    original_hash = _compute_md5(template_path)
    print(f"  \u2713 Template MD5 hash computed: {original_hash}")

    # Render the report
    render_report(template_path, json_data_path, output_path)

    # Validate structure of the generated output
    print("Post-render validation...")
    with open(output_path, 'r', encoding='utf-8') as f:
        output_content = f.read()

    structure_ok = validate_structure(output_content)

    # Verify template file was not modified during rendering
    template_ok = validate_template_unchanged(template_path, original_hash)

    if not structure_ok:
        raise RuntimeError("Structural validation failed. See warnings above.")
    if not template_ok:
        raise RuntimeError("Template file was modified during rendering!")

    print("All validations passed. Report is safe.")


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: python render.py <template_path> <json_data_path> <output_path>")
        sys.exit(1)

    template_path = sys.argv[1]
    json_data_path = sys.argv[2]
    output_path = sys.argv[3]

    render_report_safe(template_path, json_data_path, output_path)
