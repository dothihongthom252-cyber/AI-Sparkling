The repository employs a **template-driven configuration system** centered on static HTML templates and a Python-based rendering engine, rather than traditional application configuration files (e.g., `.env`, `config.yaml`).

### 1. Configuration Approach
- **Template-Based Rendering**: The core configuration logic resides in `assets/templates/render.py`, which loads an HTML template and a JSON data file, replacing placeholders (e.g., `{{REPORT_TITLE}}`) to generate final reports.
- **Static Template Storage**: HTML templates (`Gom_su_VietNam.html`, `Template.html`) serve as the structural configuration for reports, defining layout, CSS styles, and section order.
- **Agent Metadata**: Agent-specific behavior is configured via `agents/openai.yaml`, which defines display names, descriptions, and invocation policies for the "Frank B2B Market Intelligence Pro" agent.

### 2. Key Files and Packages
- **`assets/templates/render.py`**: The primary configuration loader and renderer. It handles file I/O, placeholder substitution, and structural validation of the output HTML.
- **`agents/openai.yaml`**: Defines agent interface metadata and policy constraints (e.g., `allow_implicit_invocation`).
- **`SKILL.md`**: Acts as a high-level operational configuration file, defining strict rules for report structure (7 mandatory sections), data quantities (10+ suppliers, 20+ products), and file I/O contracts (read-only templates, output to `b2b-reports/`).
- **`assets/templates/*.html`**: Static HTML files that serve as the visual and structural blueprint for generated reports.

### 3. Architecture and Conventions
- **Read-Only Template Policy**: The system enforces a strict separation between source templates (`assets/templates/`) and generated outputs (`b2b-reports/`). The `render.py` script includes validation logic (`validate_template_unchanged`) to ensure source templates are not modified during rendering.
- **Placeholder Substitution**: Configuration data is injected into templates using a simple key-value replacement strategy. The `render.py` script supports both text and JSON-like data structures for dynamic content (e.g., charts).
- **Structural Validation**: The rendering process includes a post-render validation step (`validate_structure`) that checks for the presence of all 7 mandatory report sections, CSS blocks, and sidebar navigation, ensuring compliance with the `SKILL.md` specifications.
- **Output Directory Management**: The system automatically creates the `b2b-reports/` directory if it does not exist, enforcing a consistent output location for all generated artifacts.

### 4. Rules for Developers
- **Do Not Modify Source Templates**: Treat files in `assets/templates/` as read-only. All changes to report structure must be made by creating new templates or updating the rendering logic, not by editing existing templates in place.
- **Adhere to Section Constraints**: Ensure all generated reports contain the 7 mandatory sections defined in `SKILL.md`. The `render.py` validation will fail if any section marker (e.g., `id="sec1"`) is missing.
- **Use Correct Placeholder Syntax**: Use uppercase placeholders (e.g., `{{SUPPLIER_TABLE}}`) in HTML templates, which are replaced by corresponding keys in the input JSON data.
- **Output to `b2b-reports/`**: Always save generated reports to the `b2b-reports/` directory to maintain separation from source assets and comply with the file I/O contract.