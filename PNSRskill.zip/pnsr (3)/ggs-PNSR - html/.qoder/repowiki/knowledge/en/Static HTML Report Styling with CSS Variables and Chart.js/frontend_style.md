The repository employs a **static, single-file HTML/CSS** approach for frontend styling, specifically designed for generating premium B2B market intelligence reports. There are no modern frontend frameworks (React, Vue, etc.) or build tools (Webpack, Vite) involved. Instead, the visual identity is maintained through rigorous **CSS Custom Properties (Design Tokens)** and inline `<style>` blocks within HTML templates.

### 1. Styling System & Approach
- **Methodology**: Traditional CSS with a focus on **CSS Variables** (`:root`) to enforce consistency across multiple report templates. This allows for easy theming (e.g., changing primary/secondary colors globally).
- **Component Library**: No external UI library is used. Components like cards, sidebars, modals, and tables are hand-coded using custom CSS classes (e.g., `.section-card`, `.sup-card`, `.info-card`).
- **Typography**: The system relies on **Google Fonts** (specifically 'Lexend') for a modern, clean aesthetic, paired with **FontAwesome** for iconography.
- **Responsiveness**: Basic responsive design is implemented via `@media` queries in the CSS, adjusting grid layouts (from 3 columns to 2 or 1) and sidebar positioning for mobile devices.
- **Interactivity**: Minimal JavaScript is used for UI interactions, primarily for **Chart.js** integration (data visualization) and simple modal/sidebar toggling.

### 2. Key Files
- `ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html`: The master template defining the core layout, CSS variables, and structural components.
- `ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html`: A specialized, data-rich instance of the template demonstrating the full application of the styling system (tables, supplier cards, charts).
- `ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py`: A Python script that performs placeholder replacement in the HTML templates, ensuring the static structure remains intact while injecting dynamic data.

### 3. Architecture & Conventions
- **Design Tokens**: Defined in `:root` of the CSS:
  - `--p` (Primary): Deep Cobalt Blue (`#002B5B`)
  - `--s` (Secondary): Royal Blue (`#1F75FE`)
  - `--g` (Accent/Gold): Golden Yellow (`#D4A017`)
  - `--bg` (Background): Light Gray (`#F8F9FA`)
  - `--sidebar-bg`: Dark Navy Gradient base (`#07162C`)
- **Layout Structure**: 
  - **Fixed Sidebar**: Left-aligned navigation with gradient background.
  - **Main Content Area**: Right-aligned, scrollable content with a max-width constraint.
  - **Grid Systems**: Extensive use of CSS Grid (`.grid-2`, `.grid-3`, `.sup-grid`) for responsive card layouts.
- **Visual Consistency**: 
  - **Cards**: Uniform border-radius (`12px`), subtle box-shadows, and hover effects (`transform: translateY(-4px)`).
  - **Tables**: Styled with alternating row colors and sticky headers for large datasets.
  - **Modals**: Custom overlay/modal implementation for detailed views without page reloads.

### 4. Rules for Developers
- **Use CSS Variables**: Always reference `--p`, `--s`, `--g`, etc., instead of hardcoding hex values to maintain theme consistency.
- **Template Integrity**: Do not modify the structural HTML markers (e.g., `id="sec1"`, `class="sidebar"`) as they are validated by `render.py` to ensure correct report generation.
- **Self-Contained Assets**: All CSS and JS (except CDN links for Fonts/Chart.js) should remain inline or within the single HTML file to ensure portability of the generated reports.
- **Responsive Grids**: When adding new content sections, utilize the existing `.grid-2` or `.grid-3` classes to ensure automatic adaptation to screen sizes.