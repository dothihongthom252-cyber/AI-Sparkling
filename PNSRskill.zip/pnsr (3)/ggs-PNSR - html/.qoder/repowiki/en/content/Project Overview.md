# Project Overview

<cite>
**Referenced Files in This Document**
- [SKILL.md](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md)
- [render.py](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py)
- [openai.yaml](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml)
- [Template.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html)
- [Gom_su_VietNam.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document presents the Alibaba B2B Expert HTML Report Generation System overview. The system is an industry-adaptive market intelligence and export strategy analysis tool tailored for Vietnamese manufacturers and B2B brands. It synthesizes verified data from Alibaba.com to produce premium, responsive HTML reports that combine supplier landscape research, competitor benchmarking, pricing intelligence, SEO keyword mapping, and actionable export strategy recommendations. The system emphasizes adaptability across industries, strict adherence to template structure, and robust validation to ensure high-quality, trustworthy outputs.

## Project Structure
The repository organizes the system into a small, focused set of artifacts:
- Skill definition and operational rules: defines capabilities, modes, sections, and quality gates
- Rendering pipeline: a Python script that safely populates HTML templates with JSON data and validates outputs
- Agent interface: a declarative OpenAI agent configuration that exposes the skill to users
- Templates: a premium HTML template and a reference sample report for visual structure and content adaptation

```mermaid
graph TB
A["SKILL.md<br/>Capabilities, modes, sections, rules"] --> B["render.py<br/>Template renderer + validator"]
C["openai.yaml<br/>Agent interface"] --> A
D["Template.html<br/>Premium HTML template"] --> B
E["Gom_su_VietNam.html<br/>Reference sample report"] --> B
B --> F["b2b-reports/<report>.html<br/>Generated premium HTML"]
```

**Diagram sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

**Section sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

## Core Components
- Industry-adaptive intelligence engine
  - Builds a dynamic industry profile for every request, adapting product taxonomy, benchmark criteria, pricing units, MOQ logic, compliance topics, and SEO themes to the requested industry
  - Enforces minimum data quantities and section completeness for full-intelligence reports
- Premium HTML report generator
  - Uses a premium template with a fixed structure and visual identity
  - Supports placeholder replacement from JSON data and preserves template integrity
  - Validates structural elements, CSS, sidebar, and absence of unreplaced placeholders
- Agent interface
  - Exposes the skill as an OpenAI agent with a default prompt that instructs the agent to treat the reference sample as a visual model while adapting content to the requested industry
- Data freshness and export contract
  - Requires verified, current sources and explicit file creation as the final deliverable
  - Enforces output location, naming, and protection of source templates

**Section sources**
- [SKILL.md:41-166](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L41-L166)
- [SKILL.md:241-356](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L241-L356)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)

## Architecture Overview
The system’s runtime architecture centers on a rendering pipeline that transforms structured JSON data into a validated, branded HTML report. The agent orchestrates research and data collection, then delegates report generation to the renderer, which enforces strict structural and template integrity checks.

```mermaid
sequenceDiagram
participant User as "User"
participant Agent as "OpenAI Agent"
participant Renderer as "render.py"
participant FS as "Filesystem"
participant Template as "Template.html / Gom_su_VietNam.html"
User->>Agent : "Create premium HTML report for [Industry]"
Agent->>Agent : "Build industry profile and collect verified data"
Agent->>FS : "Write JSON data payload"
Agent->>Renderer : "Invoke render_report_safe(template, json, output)"
Renderer->>Template : "Read template (read-only)"
Renderer->>Renderer : "Replace placeholders with JSON values"
Renderer->>FS : "Create b2b-reports/ and write HTML"
Renderer->>Renderer : "Validate structure, CSS, sidebar, placeholders"
Renderer-->>Agent : "Success or error with validation details"
Agent-->>User : "Report path and completion note"
```

**Diagram sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

## Detailed Component Analysis

### Skill Definition (SKILL.md)
- Purpose and scope
  - Defines the system as an industry-adaptive Alibaba.com B2B intelligence toolkit for Vietnam suppliers, exporters, and B2B brands
  - Enumerates capabilities: supplier landscape research, competitor benchmarking, pricing intelligence, SEO keyword mapping, product and image benchmarking, and premium HTML export
- Execution modes
  - Default mode: full-intelligence-report with premium-visual HTML output
  - Supported modes: quick-analysis, standard-report, full-intelligence-report
- Report structure
  - Mandated 7-section structure covering executive summary, market overview, supplier landscape, top selling products, pricing intelligence, SEO insights, and export strategy
  - Minimum data thresholds: 10+ suppliers, 20+ products, 10+ SEO keywords
- Output contract
  - Default deliverable: premium responsive HTML file named with an industry slug
  - Output location: b2b-reports/
  - Template selection: workspace sample if present; otherwise reference sample
- Quality gates
  - Structural validation, template integrity checks, placeholder verification, and output path enforcement

**Section sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)

### Rendering Pipeline (render.py)
- Responsibilities
  - Reads a template and a JSON payload
  - Replaces placeholders with values, converting lists/dicts to JSON-like strings for Chart.js/JS contexts
  - Ensures output directory exists and writes the final HTML
  - Validates structural elements (7 sections, CSS, sidebar) and absence of unreplaced placeholders
  - Guards against template modification by computing and comparing MD5 hashes
- Safety and integrity
  - Prevents overwriting templates by forbidding output in the same directory as the template
  - Raises explicit errors on structural failures or template tampering

```mermaid
flowchart TD
Start(["Start"]) --> ReadTemplate["Read template file"]
ReadTemplate --> ReadJSON["Read JSON data"]
ReadJSON --> Replace["Replace placeholders<br/>with values (including JSON for JS)"]
Replace --> EnsureDir["Ensure output directory exists"]
EnsureDir --> Write["Write final HTML"]
Write --> Validate["Validate structure:<br/>sections, CSS, sidebar,<br/>no unreplaced placeholders"]
Validate --> Integrity["Verify template MD5 unchanged"]
Integrity --> Success{"All checks pass?"}
Success --> |Yes| Done(["Done"])
Success --> |No| Fail(["Fail with error"])
```

**Diagram sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

**Section sources**
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)

### Agent Interface (openai.yaml)
- Role
  - Declares the agent display name and short description
  - Provides a default prompt that directs the agent to use the skill to create and save a premium HTML report for the requested industry
  - Instructs the agent to treat the reference sample as a visual model and adapt content to the requested industry
- Invocation policy
  - Allows implicit invocation for seamless user experience

**Section sources**
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)

### Templates
- Premium template (Template.html)
  - Defines a fixed, branded layout with a left-hand sidebar navigation, responsive sections, cards, tables, and optional Chart.js visualizations
  - Preserves CSS, layout, and navigation structure across outputs
- Reference sample (Gom_su_VietNam.html)
  - Demonstrates the premium visual structure and content depth for a ceramics-focused report
  - Used as a reference for adapting industry-specific content, benchmarks, pricing logic, SEO mapping, and export strategy

**Section sources**
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

## Dependency Analysis
- Internal dependencies
  - render.py depends on SKILL.md-defined placeholders and structure
  - openai.yaml depends on SKILL.md capabilities and default prompt behavior
  - Templates depend on each other conceptually: Template.html is the base structure; Gom_su_VietNam.html is the reference sample
- External dependencies
  - Chart.js CDN for optional visualizations
  - Google Fonts for typography
- Coupling and cohesion
  - render.py is cohesive around templating and validation
  - SKILL.md centralizes rules and expectations, minimizing coupling across components

```mermaid
graph LR
SKILL["SKILL.md"] --> Agent["openai.yaml"]
SKILL --> Renderer["render.py"]
Renderer --> Template["Template.html"]
Renderer --> Sample["Gom_su_VietNam.html"]
Renderer --> FS["b2b-reports/"]
```

**Diagram sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

**Section sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

## Performance Considerations
- Rendering performance
  - Placeholder replacement is linear in the number of keys and the size of the HTML content
  - Chart.js initialization occurs only when data supports it; otherwise, fallbacks to static tables are used
- File I/O
  - Directory creation and single-pass write minimize overhead
- Scalability
  - The system is designed for report generation per request; batch processing would require extension of the renderer

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Structural validation failures
  - Symptoms: missing sections, missing CSS, missing sidebar, unreplaced placeholders
  - Resolution: ensure all 7 sections are present, verify placeholders are replaced, and confirm template structure is preserved
- Template integrity violations
  - Symptoms: MD5 mismatch indicating template modification
  - Resolution: do not write to template directories; rerun with a fresh template copy
- Output path conflicts
  - Symptoms: attempting to overwrite templates
  - Resolution: ensure output directory is outside the template directory
- Chart.js or JavaScript failures
  - Symptoms: charts not rendering or interactivity disabled
  - Resolution: the renderer falls back to static HTML; verify data availability and browser support
- Data shortages
  - Symptoms: fewer than minimum suppliers/products/keywords
  - Resolution: include explicit shortage explanations and recommendations

**Section sources**
- [render.py:41-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L157)
- [SKILL.md:393-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L393-L468)

## Conclusion
The Alibaba B2B Expert HTML Report Generation System delivers a robust, industry-adaptive solution for Vietnamese manufacturers and B2B brands. By combining verified Alibaba.com data with a premium, structured HTML template and strict validation, it ensures trustworthy, actionable intelligence reports. The system’s modular design—skill definition, rendering pipeline, agent interface, and templates—enables consistent, scalable delivery of export strategy insights across diverse industries.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Practical Use Cases by Industry
- Ceramics
  - Use the reference sample as a visual model; adapt supplier profiles, product benchmarks, pricing units, and SEO themes to ceramics-specific attributes
- Furniture
  - Adapt product taxonomy to indoor/outdoor, materials (wood, rattan, metal), and use cases (hotel, restaurant, office); adjust pricing logic to pieces/cartons/cbm/container
- Apparel
  - Focus on SKUs, sizes/colors, packaging, OEM/ODM options; align SEO with wholesale/bulk/custom/private label keywords
- Agricultural products
  - Emphasize units (kg/ton/bag/carton/container), MOQs, certifications, and compliance; tailor SEO to origin/value and buyer-intent terms

[No sources needed since this section provides conceptual examples]