# Agent Configuration

<cite>
**Referenced Files in This Document**
- [openai.yaml](file://agents/openai.yaml)
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document explains the OpenAI agent configuration used by the Alibaba B2B Expert system. It focuses on how the agent’s YAML configuration defines the interface identity and default behavior, how the agent orchestrates report generation, and how the rendering pipeline produces premium HTML reports. It also covers customization options for different deployment scenarios, integration patterns with external systems, and best practices for reliable operation.

## Project Structure
The repository organizes agent configuration, agent skill specification, and report generation assets as follows:
- agents/openai.yaml: Defines the agent interface identity and default prompt behavior.
- SKILL.md: Specifies the agent’s capabilities, execution modes, report structure, and quality gates.
- assets/templates/: Contains HTML templates and a Python renderer for transforming JSON data into validated, branded HTML reports.
- assets/templates/Template.html: A minimal template used as a baseline for export.
- assets/templates/Gom_su_VietNam.html: A premium reference template demonstrating structure, branding, interactivity, and report sections.

```mermaid
graph TB
A["agents/openai.yaml<br/>Agent interface settings"] --> B["SKILL.md<br/>Agent capabilities and rules"]
B --> C["assets/templates/Gom_su_VietNam.html<br/>Premium reference template"]
B --> D["assets/templates/Template.html<br/>Minimal export template"]
B --> E["assets/templates/render.py<br/>Renderer validates and writes HTML"]
E --> F["b2b-reports/<br/>Generated HTML outputs"]
```

**Diagram sources**
- [openai.yaml](file://agents/openai.yaml)
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)

**Section sources**
- [openai.yaml](file://agents/openai.yaml)
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)

## Core Components
- Agent interface configuration: Provides display name, short description, and a default prompt that instructs the agent to produce a premium HTML report aligned with the reference template.
- Agent skill specification: Defines execution modes, report structure, data requirements, and quality gates for report generation.
- Rendering pipeline: Validates template integrity, replaces placeholders, enforces structural rules, and writes the final HTML to a designated output directory.

Key responsibilities:
- Interface identity: Ensures consistent branding and discovery of the agent.
- Prompt orchestration: Guides the agent to adapt the reference template to any requested industry while preserving premium structure and quality.
- Report generation contract: Enforces minimum data quantities, section counts, and output location rules.

**Section sources**
- [openai.yaml](file://agents/openai.yaml)
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)

## Architecture Overview
The agent integrates with the report generation workflow as follows:
- The agent receives a user request and applies the default prompt to create a premium HTML report.
- The renderer reads a template (either a workspace sample or the premium reference), replaces placeholders with verified data, validates structure, and writes the final HTML to the output directory.
- The agent’s skill rules govern how data is collected, how sections are composed, and how quality gates are enforced.

```mermaid
sequenceDiagram
participant User as "User"
participant Agent as "OpenAI Agent"
participant Skill as "SKILL.md Rules"
participant Renderer as "render.py"
participant Template as "Template.html / Gom_su_VietNam.html"
participant Output as "b2b-reports/"
User->>Agent : "Generate report for [industry]"
Agent->>Skill : "Apply execution mode and report rules"
Agent->>Renderer : "Provide JSON data and template selection"
Renderer->>Template : "Read selected template"
Renderer->>Renderer : "Replace placeholders and validate structure"
Renderer->>Output : "Write final HTML"
Renderer-->>Agent : "Report path and validation status"
Agent-->>User : "Deliver HTML report and completion note"
```

**Diagram sources**
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)

## Detailed Component Analysis

### Agent Interface Configuration (agents/openai.yaml)
- Display name: Used for agent discovery and branding in the platform.
- Short description: Communicates the agent’s purpose to users.
- Default prompt: Instructs the agent to create and save a premium HTML report using a specific template reference and to adapt logic to the requested industry.

Configuration impact:
- Controls how the agent appears and what the agent’s initial instruction is when invoked implicitly.
- Establishes expectations for report style and content alignment with the reference template.

**Section sources**
- [openai.yaml](file://agents/openai.yaml)

### Agent Skill Specification (SKILL.md)
Capabilities and rules:
- Execution modes: Default to full-intelligence-report and premium-visual unless the user requests a lighter mode.
- Report structure: Requires exactly seven sections with minimum content thresholds.
- Data requirements: Minimum supplier and product counts, and minimum keyword categories.
- Output contract: Always creates a premium responsive HTML file, naming and saving to a specific directory, and preserves template structure and integrity.
- Quality gates: Structural validation, placeholder replacement checks, and template protection rules.

How it affects report generation:
- The agent must adhere to the skill rules when composing the report, ensuring consistent quality and completeness.
- The renderer enforces structural and integrity checks to guarantee the final HTML meets the agent’s requirements.

**Section sources**
- [SKILL.md](file://SKILL.md)

### Rendering Pipeline (assets/templates/render.py)
Responsibilities:
- Reads template and JSON data, replaces placeholders, and writes the final HTML.
- Validates structural elements, CSS preservation, sidebar structure, and absence of unreplaced placeholders.
- Verifies template integrity by computing and comparing MD5 hashes before and after rendering.
- Prevents accidental overwrites by rejecting output paths that would overwrite templates.

Safety and validation:
- Pre-render checks compute the template’s MD5 to detect modifications.
- Post-render validation ensures all seven sections exist and the template remains unchanged.
- Raises explicit errors on validation failures to prevent invalid outputs.

**Section sources**
- [render.py](file://assets/templates/render.py)

### Templates (assets/templates/)
- Template.html: Minimal template used as a baseline for export when a workspace sample is not available.
- Gom_su_VietNam.html: Premium reference template demonstrating:
  - Seven-section structure with consistent IDs and navigation.
  - Dashboard layout, responsive grids, and interactive elements.
  - Placeholders and data-driven sections ready for substitution.
  - Chart.js integration and modal interactions.

Adaptation rule:
- When adapting the reference template for a new industry, replace all industry-specific content while preserving layout, typography, and structural elements.

**Section sources**
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)

### Report Generation Workflow
```mermaid
flowchart TD
Start(["Start"]) --> Identify["Identify requested industry"]
Identify --> BuildProfile["Build dynamic industry profile"]
BuildProfile --> SelectTemplate["Select template:<br/>Workspace sample or Gom_su_VietNam.html"]
SelectTemplate --> CollectData["Collect verified data from Alibaba.com"]
CollectData --> Populate["Populate placeholders with JSON data"]
Populate --> Validate["Validate structure and template integrity"]
Validate --> Write["Write final HTML to b2b-reports/"]
Write --> Complete(["Complete"])
Validate --> |Fail| Error["Raise validation error"]
Error --> Complete
```

**Diagram sources**
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)

## Dependency Analysis
- agents/openai.yaml depends on SKILL.md for behavior alignment and on the renderer for report delivery.
- SKILL.md depends on templates for structure and on the renderer for validation.
- render.py depends on templates for content and on the output directory for persistence.
- Templates depend on Chart.js and FontAwesome for interactivity and styling.

```mermaid
graph LR
OpenAI["agents/openai.yaml"] --> Skill["SKILL.md"]
Skill --> Renderer["assets/templates/render.py"]
Renderer --> TemplateRef["assets/templates/Gom_su_VietNam.html"]
Renderer --> TemplateBase["assets/templates/Template.html"]
Renderer --> Output["b2b-reports/"]
```

**Diagram sources**
- [openai.yaml](file://agents/openai.yaml)
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)

**Section sources**
- [openai.yaml](file://agents/openai.yaml)
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)

## Performance Considerations
- Template size and complexity: Larger templates with many charts and modals increase rendering time. Prefer the minimal template when performance is critical.
- Data volume: The renderer replaces placeholders and validates structure; larger datasets increase processing time. Batch or paginate data when possible.
- Chart.js usage: Charts require additional resources; disable or simplify charts when not supported or when performance is constrained.
- Output directory I/O: Ensure the output directory exists and is writable to avoid repeated retries.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Validation failures:
  - Symptom: Structural validation fails or template integrity check fails.
  - Resolution: Review the renderer’s validation messages, ensure all seven sections are present, and confirm no placeholders remain unreplaced.
- Template overwritten:
  - Symptom: Renderer rejects output because it would overwrite the template.
  - Resolution: Save outputs to a different directory (e.g., b2b-reports/) and avoid writing back to assets/templates/.
- Missing data:
  - Symptom: Fewer suppliers/products than required.
  - Resolution: The skill requires minimum counts; if data is thin, include explicit shortage explanations as mandated by the skill rules.
- Chart or JavaScript failures:
  - Symptom: Charts fail to render or interactivity is disabled.
  - Resolution: Fall back to static HTML and ensure Chart.js is available; if not, keep content static and include explanatory notes.

**Section sources**
- [render.py](file://assets/templates/render.py)
- [SKILL.md](file://SKILL.md)

## Conclusion
The OpenAI agent configuration and skill specification define a robust framework for generating premium, industry-adaptive HTML reports. The YAML interface ensures consistent branding and invocation behavior, while the skill rules enforce quality and completeness. The renderer validates structure and integrity, ensuring reliable delivery of reports that meet the agent’s standards. By following the customization and troubleshooting guidance, teams can deploy the agent effectively across diverse scenarios and maintain high-quality outputs.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices

### Deployment Scenarios and Integration Patterns
- Implicit invocation: Enabled by the agent policy, allowing seamless activation when the agent is selected as the default assistant.
- Workspace sample template: If a workspace-provided HTML sample exists, the agent prefers it as the export template; otherwise, it uses the premium reference template.
- External systems: The renderer writes to a designated output directory; integrate with CI/CD or storage systems to publish or archive reports.

**Section sources**
- [openai.yaml](file://agents/openai.yaml)
- [SKILL.md](file://SKILL.md)
- [render.py](file://assets/templates/render.py)

### Practical Customization Examples
- Change display name and description: Modify the interface settings in the agent configuration to reflect team branding.
- Adjust default prompt: Update the default prompt to guide the agent toward different report styles or additional domains.
- Customize execution mode: Use the skill rules to switch between quick, standard, and full-intelligence modes depending on user needs.
- Adapt templates: Replace placeholders and content in the reference template to reflect new industries while preserving structure and branding.

**Section sources**
- [openai.yaml](file://agents/openai.yaml)
- [SKILL.md](file://SKILL.md)
- [Template.html](file://assets/templates/Template.html)
- [Gom_su_VietNam.html](file://assets/templates/Gom_su_VietNam.html)