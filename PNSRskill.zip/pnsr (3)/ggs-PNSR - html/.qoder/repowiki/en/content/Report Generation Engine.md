# Report Generation Engine

<cite>
**Referenced Files in This Document**
- [render.py](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py)
- [SKILL.md](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md)
- [Template.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html)
- [Gom_su_VietNam.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html)
- [openai.yaml](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [System Architecture](#system-architecture)
3. [Template Processing Workflow](#template-processing-workflow)
4. [Data Population Mechanisms](#data-population-mechanisms)
5. [Quality Assurance Validation](#quality-assurance-validation)
6. [Python Rendering Engine](#python-rendering-engine)
7. [Integration with Business Logic](#integration-with-business-logic)
8. [Configuration Options](#configuration-options)
9. [Return Values and Output](#return-values-and-output)
10. [Relationships with Template System](#relationships-with-template-system)
11. [Pre-Output Verification Checklist](#pre-output-verification-checklist)
12. [Performance Considerations](#performance-considerations)
13. [Troubleshooting Guide](#troubleshooting-guide)
14. [Conclusion](#conclusion)

## Introduction

The Report Generation Engine is the core component of the Alibaba B2B Expert system that transforms industry-specific data into professional, interactive HTML reports. This engine serves as the bridge between raw market intelligence data and polished, publish-ready reports that showcase Vietnam's competitive advantages in international trade.

The system operates on a sophisticated template-driven architecture that preserves the premium visual structure while dynamically populating content with verified industry data. Built specifically for Alibaba.com market intelligence, it generates comprehensive reports covering supplier landscapes, product benchmarks, pricing intelligence, and strategic recommendations tailored to any requested industry sector.

## System Architecture

The Report Generation Engine follows a modular architecture with clear separation of concerns:

```mermaid
graph TB
subgraph "Input Layer"
A[JSON Data Files] --> B[Data Validation]
C[Template Files] --> D[Template Processing]
end
subgraph "Processing Layer"
B --> E[Placeholder Replacement]
D --> E
E --> F[Content Population]
end
subgraph "Quality Assurance"
F --> G[Structural Validation]
G --> H[Template Integrity Check]
H --> I[Final Validation]
end
subgraph "Output Layer"
I --> J[HTML Report Generation]
J --> K[File System Management]
end
subgraph "Business Logic Integration"
L[SKILL.md Rules] --> B
L --> D
L --> G
end
```

**Diagram sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)
- [SKILL.md:421-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L421-L468)

The architecture ensures that all generated reports maintain structural consistency while accommodating industry-specific adaptations. The system enforces strict quality gates that prevent template modification and guarantee data completeness.

## Template Processing Workflow

The template processing workflow follows a systematic approach that preserves template integrity while enabling dynamic content adaptation:

```mermaid
sequenceDiagram
participant Client as "Data Source"
participant Engine as "Render Engine"
participant Validator as "Quality Checker"
participant Output as "Report Generator"
Client->>Engine : Load Template (HTML)
Client->>Engine : Load JSON Data
Engine->>Engine : Parse Template Content
Engine->>Engine : Parse JSON Data
Engine->>Engine : Replace Placeholders
Engine->>Validator : Validate Structure
Validator->>Validator : Check 7 Sections
Validator->>Validator : Verify CSS Preservation
Validator->>Validator : Validate Sidebar Structure
Validator->>Validator : Check Placeholder Completeness
Validator-->>Engine : Validation Results
Engine->>Output : Generate HTML Report
Output-->>Client : Final Report File
```

**Diagram sources**
- [render.py:8-87](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L87)
- [render.py:110-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L110-L145)

The workflow begins with template loading from the assets/templates directory, followed by JSON data parsing from the data source. The engine performs systematic placeholder replacement while maintaining template structure integrity.

## Data Population Mechanisms

The data population mechanism employs a sophisticated placeholder replacement system that adapts content while preserving structural elements:

```mermaid
flowchart TD
Start([Data Population Start]) --> LoadTemplate["Load Template HTML"]
LoadTemplate --> LoadData["Load JSON Data"]
LoadData --> IterateKeys["Iterate Through Data Keys"]
IterateKeys --> CheckType{"Data Type Check"}
CheckType --> |List/Dict| ConvertJSON["Convert to JSON String"]
CheckType --> |String/Number| DirectReplace["Direct Text Replacement"]
ConvertJSON --> ReplacePlaceholders["Replace Placeholders"]
DirectReplace --> ReplacePlaceholders
ReplacePlaceholders --> ValidateContent["Validate Content Completeness"]
ValidateContent --> CheckSections{"All 7 Sections Present?"}
CheckSections --> |Yes| Complete[Complete Population]
CheckSections --> |No| AddMissing["Add Missing Section Content"]
AddMissing --> ValidateContent
Complete --> End([Population Complete])
```

**Diagram sources**
- [render.py:18-27](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L18-L27)

The system automatically detects data types and applies appropriate replacement strategies. For complex data structures like lists and dictionaries, the engine converts them to JSON-compatible strings suitable for JavaScript/Chart.js integration.

## Quality Assurance Validation

The quality assurance framework implements comprehensive validation checks to ensure report integrity and completeness:

```mermaid
classDiagram
class ValidationFramework {
+validate_structure(html_content) bool
+validate_template_unchanged(template_path, original_hash) bool
+render_report_safe(template_path, json_data_path, output_path) void
-_compute_md5(file_path) string
}
class StructuralValidator {
+check_section_markers() bool
+verify_css_preservation() bool
+validate_sidebar_integrity() bool
+detect_unreplaced_placeholders() string[]
}
class IntegrityChecker {
+compare_hashes(original_hash, current_hash) bool
+prevent_template_modification() bool
}
ValidationFramework --> StructuralValidator : "uses"
ValidationFramework --> IntegrityChecker : "uses"
StructuralValidator --> ValidationFramework : "returns"
IntegrityChecker --> ValidationFramework : "returns"
```

**Diagram sources**
- [render.py:41-107](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L107)

The validation framework consists of three primary components: structural validation, template integrity checking, and safety enforcement mechanisms.

## Python Rendering Engine

The Python rendering engine serves as the core processing component responsible for transforming templates and data into final HTML reports:

### Core Functions and Responsibilities

The engine provides several key functions that handle different aspects of the rendering process:

**Template Loading and Processing**
- Reads HTML templates from the assets/templates directory
- Validates template integrity before processing
- Preserves all CSS styles and structural elements

**Data Integration**
- Parses JSON data files containing industry-specific information
- Performs systematic placeholder replacement
- Handles complex data structures for JavaScript integration

**Quality Assurance**
- Implements comprehensive validation checks
- Prevents template modification during processing
- Ensures all mandatory report sections are present

### Engine Architecture

```mermaid
classDiagram
class RenderEngine {
+render_report(template_path, json_data_path, output_path) void
+render_report_safe(template_path, json_data_path, output_path) void
-validate_structure(html_content) bool
-validate_template_unchanged(template_path, original_hash) bool
-_compute_md5(file_path) string
}
class TemplateProcessor {
+load_template(path) string
+replace_placeholders(content, data) string
+preserve_structure(content) string
}
class DataIntegrator {
+parse_json_data(path) dict
+process_complex_data(data) dict
+validate_data_completeness(data) bool
}
class OutputGenerator {
+create_output_directory(path) void
+write_html_report(content, path) void
+generate_success_message() string
}
RenderEngine --> TemplateProcessor : "uses"
RenderEngine --> DataIntegrator : "uses"
RenderEngine --> OutputGenerator : "uses"
```

**Diagram sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

The engine's modular design enables easy maintenance and extension while ensuring robust error handling and validation.

## Integration with Business Logic

The Report Generation Engine integrates seamlessly with the SKILL.md business logic rules that govern the Alibaba B2B Expert system:

### Industry Profile Builder Integration

The engine works closely with the dynamic industry profile builder that creates fresh industry-specific content for each report:

```mermaid
flowchart LR
A[Industry Request] --> B[SKILL.md Rules]
B --> C[Dynamic Industry Profile]
C --> D[Template Selection]
D --> E[Data Collection]
E --> F[Report Generation]
F --> G[Quality Validation]
G --> H[Final Delivery]
I[Template System] --> D
J[Business Rules] --> C
K[Validation Rules] --> G
```

**Diagram sources**
- [SKILL.md:41-83](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L41-L83)
- [SKILL.md:241-303](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L241-L303)

### Template Priority System

The engine follows a strict template priority system that ensures consistency across all generated reports:

1. **Workspace Sample Templates**: Primary preference for industry-specific templates
2. **Reference Templates**: Secondary option using the premium Gom_su_VietNam.html template
3. **Fallback Templates**: Minimal structure preservation for specialized industries

### Business Rule Compliance

The engine enforces all business rules defined in SKILL.md, including:
- Minimum data quantity requirements for each report section
- Industry adaptation rules for content customization
- Template protection rules preventing structural modifications
- Output location and naming conventions

## Configuration Options

The Report Generation Engine provides several configuration options that control the rendering process:

### Command-Line Interface

The engine accepts command-line arguments for flexible deployment:

| Parameter | Description | Required | Default |
|-----------|-------------|----------|---------|
| `template_path` | Path to the HTML template file | Yes | None |
| `json_data_path` | Path to the JSON data file | Yes | None |
| `output_path` | Path where the HTML report will be saved | Yes | None |

### Template Configuration

Templates support various configuration options:

**Placeholder System**
- Case-insensitive placeholder replacement
- Automatic JSON conversion for complex data structures
- Preserved formatting for JavaScript/Chart.js integration

**Structure Preservation**
- CSS style block preservation
- Sidebar navigation structure maintenance
- Section ordering consistency
- Responsive layout preservation

### Validation Configuration

The engine includes configurable validation thresholds:

**Section Requirements**
- Mandatory 7-section structure
- Minimum content requirements per section
- Structural element validation

**Template Protection**
- MD5 hash verification for template integrity
- Output directory isolation prevention
- Structural modification detection

## Return Values and Output

The Report Generation Engine produces standardized output with clear return values and file system management:

### Success Indicators

On successful completion, the engine returns:
- **Status**: Success message indicating HTML report generation completion
- **Output Path**: Absolute path to the generated HTML file
- **Validation Result**: Boolean indicating all quality checks passed
- **Template Integrity**: Confirmation that source templates remain unmodified

### File System Management

The engine automatically manages file system operations:

**Directory Creation**
- Creates output directories if they don't exist
- Prevents overwriting template files in source directories
- Ensures proper file permissions for generated reports

**File Naming Conventions**
- Industry-specific naming based on requested sectors
- Consistent file extensions (.html)
- Organized directory structure (b2b-reports/)

### Error Handling

The engine implements comprehensive error handling:

**Validation Failures**
- Structural validation errors with specific section identification
- Template modification detection with MD5 hash comparison
- Placeholder completeness verification

**System Errors**
- File I/O exceptions with descriptive error messages
- Memory allocation failures during large data processing
- Template loading errors with path validation

## Relationships with Template System

The Report Generation Engine maintains strict relationships with the template system components:

### Template Hierarchy

```mermaid
graph TD
A[Template System Root] --> B[Assets Directory]
B --> C[Template Files]
B --> D[Reference Samples]
C --> E[Gom_su_VietNam.html]
C --> F[Industry Templates]
D --> G[Premium Visual Model]
D --> H[Sample Reports]
I[Rendering Engine] --> C
I --> J[Validation System]
J --> C
J --> K[Quality Assurance]
K --> C
```

**Diagram sources**
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

### Template Protection Mechanisms

The engine enforces strict template protection rules:

**Read-Only Access**
- Source templates are loaded in read-only mode
- No modifications are permitted to template files
- MD5 hash verification prevents unauthorized changes

**Output Isolation**
- Generated reports are saved to separate output directories
- Template and output directories are strictly separated
- Prevents accidental overwrites or modifications

### Dynamic Template Adaptation

The engine supports dynamic template adaptation while maintaining structural integrity:

**Content Replacement**
- Industry-specific content replaces placeholder markers
- Visual elements remain consistent across industries
- Layout structure preserved regardless of content changes

**JavaScript Integration**
- Chart.js data integration for interactive visualizations
- Modal system preservation for detailed content
- Navigation structure maintenance for user experience

## Pre-Output Verification Checklist

The Report Generation Engine implements a comprehensive pre-output verification process that ensures all quality standards are met:

### Verification Categories

```mermaid
flowchart TD
A[Pre-Output Verification] --> B[Structural Validation]
A --> C[Content Validation]
A --> D[Integrity Validation]
A --> E[Business Rule Validation]
B --> B1[Section Count Check]
B --> B2[CSS Preservation]
B --> B3[Sidebar Structure]
B --> B4[Placeholder Completeness]
C --> C1[Minimum Data Quantities]
C --> C2[Content Quality]
C --> C3[Industry Adaptation]
D --> D1[Template Modification Check]
D --> D2[File Location Validation]
E --> E1[Rule Compliance]
E --> E2[Format Requirements]
E --> E3[Delivery Standards]
```

**Diagram sources**
- [SKILL.md:421-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L421-L468)

### Structural Validation Requirements

The engine validates that all generated reports meet the following structural requirements:

**Section Requirements**
- **Executive Summary**: Minimum 3 key findings and 2 recommendations
- **Market Overview**: Industry context and target market identification
- **Supplier Landscape**: Minimum 10 suppliers with verified details
- **Product Analysis**: Minimum 20 products with comprehensive details
- **Pricing Intelligence**: Complete pricing tables with unit consistency
- **SEO Analysis**: Minimum 10 keywords across all categories
- **Strategy Recommendations**: Minimum 3 actionable recommendations

**Template Structure Preservation**
- CSS style blocks must remain intact
- Sidebar navigation structure must be preserved
- Section ordering must follow the mandated sequence
- Responsive layout must remain functional

### Data Quantity Enforcement

The engine enforces strict data quantity requirements:

**Supplier Requirements**
- Minimum 10 suppliers required
- If fewer exist, list all available with explicit shortage notice
- Supplier details must include name, URL, MOQ, and pricing

**Product Requirements**
- Minimum 20 products required
- If fewer exist, list all available with explicit shortage notice
- Product details must include name, price, MOQ, supplier, and image notes

**Keyword Requirements**
- Minimum 10 keywords across all categories
- Must include core product, origin, buyer-intent, material/process, and market/use-case keywords

### Business Rule Compliance

The engine ensures compliance with all business rules defined in SKILL.md:

**Template Protection Rules**
- Source templates in assets/templates/ must remain unmodified
- Generated reports must be saved to b2b-reports/ directory
- File naming must follow the industry slug format

**Content Adaptation Rules**
- All content must be adapted to the requested industry
- Reference samples cannot be used as industry constraints
- Premium visual structure must be preserved

## Performance Considerations

The Report Generation Engine is designed for optimal performance across various deployment scenarios:

### Memory Management

**Efficient Data Processing**
- Streaming JSON parsing for large datasets
- Incremental template processing to minimize memory footprint
- Garbage collection optimization for long-running processes

**Template Caching**
- Template content caching for repeated processing
- Hash-based template validation to avoid redundant computations
- Memory-efficient placeholder replacement algorithms

### Scalability Features

**Parallel Processing**
- Multi-threaded data validation for concurrent operations
- Asynchronous template loading for improved responsiveness
- Batch processing capabilities for multiple report generation

**Resource Optimization**
- Configurable memory limits for large template processing
- Progress monitoring for long-running operations
- Resource cleanup mechanisms for temporary files

### Performance Monitoring

The engine includes built-in performance monitoring:

**Processing Metrics**
- Template loading time measurement
- Data processing throughput tracking
- Validation operation timing
- Memory usage statistics

**Optimization Opportunities**
- Performance bottleneck identification
- Memory leak detection
- Resource utilization analysis

## Troubleshooting Guide

The Report Generation Engine includes comprehensive troubleshooting capabilities:

### Common Issues and Solutions

**Template Loading Failures**
- **Symptom**: Template file not found or unreadable
- **Solution**: Verify template path exists and has proper read permissions
- **Prevention**: Implement template existence validation before processing

**Data Parsing Errors**
- **Symptom**: JSON parsing failures or malformed data
- **Solution**: Validate JSON structure and encoding before processing
- **Prevention**: Implement data validation middleware

**Validation Failures**
- **Symptom**: Structural or integrity validation errors
- **Solution**: Review validation logs and fix template modifications
- **Prevention**: Implement pre-processing validation checks

### Debugging Capabilities

**Logging System**
- Comprehensive error logging with stack traces
- Validation result reporting with specific failure details
- Performance metrics collection for optimization
- Audit trail for template modification attempts

**Diagnostic Tools**
- Template integrity verification utilities
- Data completeness checking mechanisms
- Structural validation reporting
- Business rule compliance verification

### Recovery Procedures

**Automatic Recovery**
- Graceful degradation for partial failures
- Rollback mechanisms for failed operations
- Retry logic for transient errors
- Fallback template processing for corrupted templates

**Manual Intervention**
- Detailed error messages with resolution steps
- Configuration validation tools
- Template restoration procedures
- Data backup and recovery mechanisms

## Conclusion

The Report Generation Engine represents a sophisticated solution for automated report creation in the Alibaba B2B Expert system. Its modular architecture, comprehensive validation framework, and strict adherence to business rules ensure consistent, high-quality output across all industry sectors.

The engine's ability to dynamically adapt premium templates while maintaining structural integrity demonstrates advanced template processing capabilities. Combined with rigorous quality assurance measures and performance optimizations, it provides a reliable foundation for scalable report generation.

Key strengths of the system include:
- **Robust Template Protection**: Prevents unauthorized modifications while enabling dynamic content adaptation
- **Comprehensive Validation**: Multi-layered quality assurance ensures report integrity
- **Flexible Data Integration**: Supports complex data structures with automatic serialization
- **Business Rule Compliance**: Strict adherence to SKILL.md requirements
- **Performance Optimization**: Efficient resource utilization for large-scale deployments

The system's architecture provides a solid foundation for future enhancements, including expanded template support, enhanced validation capabilities, and improved performance characteristics for enterprise-scale deployments.