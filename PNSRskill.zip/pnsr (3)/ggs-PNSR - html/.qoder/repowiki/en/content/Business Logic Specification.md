# Business Logic Specification

<cite>
**Referenced Files in This Document**
- [SKILL.md](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md)
- [render.py](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py)
- [openai.yaml](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml)
- [Gom_su_VietNam.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html)
- [Template.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document specifies the business logic governing the Alibaba B2B Expert report generation process. It defines how industry profiles are built, how dynamic schemas are created, how execution modes are selected, and how the research workflow is executed. It also documents quality requirements, validation rules, the mandatory 7-section report structure, template adaptation rules, evidence preservation requirements, fallback policies, compliance frameworks, quality assurance checkpoints, and the relationship between business rules and the rendering engine.

## Project Structure
The repository organizes business logic and rendering assets as follows:
- Skill definition and business rules: SKILL.md
- Rendering engine: assets/templates/render.py
- Agent interface: agents/openai.yaml
- Templates:
  - Premium reference template: assets/templates/Gom_su_VietNam.html
  - Generic template for workspace sample: assets/templates/Template.html

```mermaid
graph TB
A["SKILL.md<br/>Business Rules"] --> B["render.py<br/>Rendering Engine"]
B --> C["Gom_su_VietNam.html<br/>Premium Template"]
B --> D["Template.html<br/>Generic Template"]
E["openai.yaml<br/>Agent Interface"] --> A
E --> B
```

**Diagram sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)

**Section sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)

## Core Components
- Industry Profile Builder: Creates a dynamic, industry-specific profile including taxonomy, benchmark criteria, pricing units, MOQ logic, compliance focus, SEO themes, and export strategy.
- Execution Modes: Selects among quick-analysis, standard-report, and full-intelligence-report, with defaults and minimum evidence thresholds.
- Research Workflow: Defines data collection, supplier intelligence, product benchmarking, pricing intelligence, and SEO mapping.
- Premium Template-Based Output: Enforces strict template adaptation rules, placeholder replacement, and output contract.
- Mandatory 7-Section Report: Specifies content requirements, minimum data quantities, and section enforcement.
- Compliance and Fallbacks: Preserves evidence, separates analysis from facts, and applies fallback policies for missing/conflicting data.
- Final Quality Checklist: Pre-output verification and completion contract.

**Section sources**
- [SKILL.md:41-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L41-L468)

## Architecture Overview
The end-to-end pipeline integrates business rules, rendering, and templates:

```mermaid
sequenceDiagram
participant User as "User"
participant Agent as "Agent (openai.yaml)"
participant Rules as "Business Rules (SKILL.md)"
participant Renderer as "Renderer (render.py)"
participant Tmpl as "Templates (Gom_su_VietNam.html / Template.html)"
User->>Agent : "Generate report for requested industry"
Agent->>Rules : "Apply industry profile, modes, workflow"
Rules-->>Agent : "Structured report data + placeholders"
Agent->>Renderer : "Render(template_path, json_data_path, output_path)"
Renderer->>Tmpl : "Read template (read-only)"
Renderer->>Renderer : "Replace placeholders, validate structure"
Renderer-->>Agent : "Saved HTML path or fallback content"
Agent-->>User : "Final HTML report"
```

**Diagram sources**
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [SKILL.md:100-166](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L100-L166)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)

## Detailed Component Analysis

### Industry Profile Building Rules
- Dynamic Industry Profile Schema: For every report, construct an industry-specific profile including:
  - Industry slug
  - Product scope
  - Target buyers
  - Supplier benchmark criteria
  - Product benchmark criteria
  - Pricing units
  - MOQ logic
  - Compliance focus
  - SEO themes
  - Export strategy angle
- Example Industry Adaptation: Furniture-specific taxonomy, materials, pricing units, MOQ, compliance, benchmark, and SEO are defined for the requested industry.

```mermaid
flowchart TD
Start(["Start"]) --> Identify["Identify requested industry"]
Identify --> BuildSlug["Build industry slug"]
BuildSlug --> Taxonomy["Define product taxonomy"]
Taxonomy --> Benchmarks["Define supplier/product benchmarks"]
Benchmarks --> Pricing["Define pricing units and MOQ logic"]
Pricing --> Compliance["Define compliance/certification topics"]
Compliance --> SEO["Define SEO keyword themes"]
SEO --> Strategy["Define export strategy angle"]
Strategy --> End(["Dynamic profile ready"])
```

**Diagram sources**
- [SKILL.md:67-97](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L67-L97)

**Section sources**
- [SKILL.md:41-97](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L41-L97)

### Dynamic Industry Schema Creation
- Mental profile fields and required content are defined in the skill spec.
- The rendering engine replaces placeholders in templates with verified industry data.

```mermaid
classDiagram
class IndustryProfile {
+string industry_slug
+string product_scope
+string target_buyers
+map supplier_benchmark_criteria
+map product_benchmark_criteria
+string pricing_units
+string moq_logic
+string compliance_focus
+map seo_themes
+string export_strategy_angle
}
class Renderer {
+render_report(template_path, json_data_path, output_path)
+validate_structure(html_content)
+validate_template_unchanged(template_path, original_hash)
}
IndustryProfile --> Renderer : "feeds data"
```

**Diagram sources**
- [SKILL.md:67-97](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L67-L97)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

**Section sources**
- [SKILL.md:67-97](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L67-L97)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

### Execution Mode Selection Logic
- Default mode: full-intelligence-report; default HTML style: premium-visual.
- Mode table defines when to use quick-analysis, standard-report, or full-intelligence-report, with minimum evidence thresholds.
- Output contract requires HTML file creation unless explicitly requested otherwise.

```mermaid
flowchart TD
Request(["Report request"]) --> CheckExplicit["User explicitly requested simplified?"]
CheckExplicit --> |Yes| ChooseMode["Select quick-analysis or standard-report"]
CheckExplicit --> |No| Default["Use full-intelligence-report"]
Default --> MinEvidence["Verify minimum evidence"]
MinEvidence --> OutputFormat["Prepare HTML output"]
ChooseMode --> OutputFormat
```

**Diagram sources**
- [SKILL.md:100-166](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L100-L166)

**Section sources**
- [SKILL.md:100-166](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L100-L166)

### Research Workflow
- Data collection: confirm industry, product scope, origin, target market, buyer segment, language, and output format; build dynamic profile; browse Alibaba for suppliers, listings, pricing, MOQ, certifications, lead times, and credible signals; capture source URLs; preserve original names, titles, URLs, countries, certifications, MOQ, price ranges, and lead times.
- Supplier Intelligence: collect supplier name, Alibaba URL, country/region, product focus, Alibaba tenure, verification status, certifications, MOQ, price range, lead time, strengths/risks.
- Product Benchmarking: compare product type/subcategory, materials/process/specifications/variants, use case/buyer segment, customization/OEM/ODM, packaging/export readiness, listing image quality/presentation, compliance claims, MOQ, price range, lead time, sample policy.
- Pricing Intelligence: build pricing by correct industry unit; include MOQ and confidence notes; if prices are hidden, state “Unavailable”.
- SEO Mapping: map keywords by requested industry: core product, origin/value, buyer intent, material/process, market/use case, compliance.

```mermaid
flowchart TD
Start(["Start research"]) --> Confirm["Confirm industry and scope"]
Confirm --> BuildProfile["Build dynamic industry profile"]
BuildProfile --> Collect["Collect verified data from Alibaba"]
Collect --> Suppliers["Supplier intelligence"]
Collect --> Products["Product benchmarking"]
Collect --> Pricing["Pricing intelligence"]
Collect --> SEO["SEO keyword mapping"]
Suppliers --> Output["Assemble report sections"]
Products --> Output
Pricing --> Output
SEO --> Output
Output --> End(["Complete research workflow"])
```

**Diagram sources**
- [SKILL.md:169-239](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L169-L239)

**Section sources**
- [SKILL.md:169-239](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L169-L239)

### Quality Requirements and Validation Rules
- Evidence preservation: no fake data; preserve originals; separate analysis from facts; current data; source list.
- Data freshness and export contract: never reuse cached content; verify supplier links, product listings, prices, and certifications for each new report; automatically write HTML report file as part of final response.
- Section count enforcement: count sections before finalizing; if fewer than 7, stop and add missing sections; if genuinely unavailable, keep section header and write “Data unavailable for this industry on Alibaba.com. Recommendation: [suggest alternative data source].”
- Data quantity enforcement: suppliers ≥ 10; products ≥ 20; SEO keywords ≥ 10; if fewer, list all available and add explicit shortage explanation.

```mermaid
flowchart TD
Start(["Pre-output verification"]) --> SecCount["Check 7 sections present"]
SecCount --> ExecSum["Executive Summary: 3+ findings, 2+ recommendations"]
ExecSum --> Suppliers["Supplier Landscape: ≥10 suppliers"]
Suppliers --> Products["Products: ≥20 products"]
Products --> SEO["SEO: ≥10 keywords"]
SEO --> Template["Template structure preserved"]
Template --> OutputDir["Saved in b2b-reports/"]
OutputDir --> NoPlaceholders["No unreplaced placeholders"]
NoPlaceholders --> IndustryAdapt["Industry-specific content"]
IndustryAdapt --> End(["All checks passed"])
```

**Diagram sources**
- [SKILL.md:421-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L421-L468)

**Section sources**
- [SKILL.md:395-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L395-L468)

### Mandatory 7-Section Report Structure
- Section 1: Executive Summary (3+ key findings, 2+ recommendations)
- Section 2: Market Overview & Industry Scope (market context, buyer segments)
- Section 3: Supplier Landscape (≥10 suppliers with name, URL, MOQ, price range, strengths)
- Section 4: Top Selling Products & Product Benchmark (≥20 products with name, price, MOQ, supplier, image notes)
- Section 5: Pricing Intelligence (price table with 3+ price tiers, unit consistency)
- Section 6: SEO Keyword Map & Buyer Persona (≥10 keywords mapped by category)
- Section 7: Export Strategy, Channel Strategy & Risk Analysis (3+ recommendations, risk table, source URLs)

Minimum data quantity enforcement and explicit shortage explanations are required when data is limited.

**Section sources**
- [SKILL.md:359-391](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L359-L391)

### Template Adaptation Rules
- Template priority: if a designed HTML/DOCX template is available, use it as the primary output structure; otherwise prefer the premium visual reference.
- For stored templates or workspace-provided samples, prefer the workspace sample if present; otherwise use the premium visual reference.
- Mandatory adaptation rule: when adapting the reference sample for a new industry, replace report title, meta text, sidebar section names, industry wording, all ceramics-specific suppliers/products/market statements/chart values/keywords/recommendations, rebuild benchmark criteria/pricing logic/SEO logic/export strategy for the requested industry, and keep the premium visual structure and interaction style.
- Premium HTML requirements: dashboard layout, responsive sections, executive summary cards, advanced tables, visual benchmark blocks, image comparison sections when data exists, pricing intelligence sections, keyword heatmaps when supported, modern typography, print-friendly formatting, branded visual structure, interactive navigation when supported.
- Template rules: preserve design, replace data, adapt industry, keep structure, handle missing data with “Unavailable”, treat sample as sample, avoid fake content.

```mermaid
flowchart TD
Start(["Template selection"]) --> CheckWorkspace["Workspace sample exists?"]
CheckWorkspace --> |Yes| UseWorkspace["Use workspace sample as export template"]
CheckWorkspace --> |No| UseReference["Use premium visual reference"]
UseWorkspace --> Adapt["Replace placeholders with industry data"]
UseReference --> Adapt
Adapt --> Verify["Verify 7 sections present"]
Verify --> Output["Save to b2b-reports/"]
```

**Diagram sources**
- [SKILL.md:241-357](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L241-L357)

**Section sources**
- [SKILL.md:241-357](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L241-L357)

### Evidence Preservation Requirements and Fallback Policies
- Evidence rules: no fake data; preserve originals; separate analysis; current data; source list.
- Fallback policy: missing data → mark “Unavailable”; thin data → continue with verified evidence and lower confidence; no dedicated industry template → use premium visual reference and adapt all industry content; cannot write HTML → explain blocker and provide complete HTML content; charts unsupported → replace with tables; images unavailable → continue without images; HTML failure → produce simplified responsive HTML; JavaScript failure → disable interactions and preserve static content; conflicting data → show conflict, source URLs, and confidence level.

**Section sources**
- [SKILL.md:395-418](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L395-L418)

### Compliance Framework and Final Verification Processes
- Compliance framework: strict adherence to evidence rules and fallback policies.
- Final quality checklist: pre-output verification must pass before finalizing; completion contract: industry research completed with verified data, 7 sections present, minimum data quantities met, pricing intelligence with correct units, template structure preserved, final HTML saved to b2b-reports/, source templates unchanged, no placeholder remnants, industry adaptation enforced.
- Failure recovery: if missing sections, add immediately; if product count < 20 or supplier count < 10, search for more or add explicit shortage note; if template modified, discard changes, re-read fresh template, restart output generation.

**Section sources**
- [SKILL.md:421-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L421-L468)

### Relationship Between Business Logic and Rendering Engine
- The rendering engine reads a template (read-only), replaces placeholders with verified industry data, validates structural elements, ensures template integrity, and writes the final HTML to the output directory.
- The business rules define the data to be placed into placeholders and enforce structural and content requirements.

```mermaid
sequenceDiagram
participant Rules as "Business Rules (SKILL.md)"
participant Renderer as "Renderer (render.py)"
participant Tmpl as "Template (Gom_su_VietNam.html/Template.html)"
participant FS as "Filesystem"
Rules->>Renderer : "Provide data and placeholders"
Renderer->>Tmpl : "Read template (read-only)"
Renderer->>Renderer : "Replace placeholders"
Renderer->>Renderer : "Validate structure and template integrity"
Renderer->>FS : "Write final HTML to b2b-reports/"
FS-->>Renderer : "Success"
Renderer-->>Rules : "Report path or fallback content"
```

**Diagram sources**
- [SKILL.md:311-357](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L311-L357)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)

**Section sources**
- [SKILL.md:311-357](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L311-L357)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

## Dependency Analysis
- Business rules depend on the rendering engine to enforce structural and content requirements.
- The rendering engine depends on templates for structure and styling.
- The agent interface invokes the business rules and rendering engine.

```mermaid
graph TB
Rules["SKILL.md"] --> Renderer["render.py"]
Renderer --> Tmpl1["Gom_su_VietNam.html"]
Renderer --> Tmpl2["Template.html"]
Agent["openai.yaml"] --> Rules
Agent --> Renderer
```

**Diagram sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)

**Section sources**
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)

## Performance Considerations
- Rendering performance is primarily constrained by template size and placeholder replacement. The renderer validates structure and template integrity post-rendering, which adds minimal overhead.
- Recommendations:
  - Keep templates lean while preserving structure.
  - Avoid excessive JavaScript interactions when not supported.
  - Use static fallbacks when Chart.js or images are unavailable.

[No sources needed since this section provides general guidance]

## Troubleshooting Guide
Common issues and resolutions:
- Structural validation failures: ensure all 7 sections are present and placeholders are replaced.
- Template modification detected: re-read the template and restart rendering.
- Output path conflicts: ensure output is not written to the template directory.
- Missing data: mark “Unavailable” and explain; continue with verified evidence.
- Thin data: lower confidence and continue.
- Charts/images unsupported: replace with tables or continue without images.
- JavaScript failures: disable interactions and preserve static content.

**Section sources**
- [render.py:41-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L145)
- [SKILL.md:395-418](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L395-L418)

## Conclusion
The Alibaba B2B Expert report generation process is governed by strict business rules that ensure industry-adaptive, evidence-based, and quality-assured outputs. The rendering engine enforces structural and content requirements, while the agent interface orchestrates the end-to-end workflow. Adherence to the 7-section structure, minimum data quantities, template adaptation rules, and compliance framework guarantees report completeness and accuracy.

[No sources needed since this section summarizes without analyzing specific files]

## Appendices
- Placeholder map for template editing:
  - {{report_title}}, {{date}}, {{industry_slug}}, {{product_scope}}, {{target_markets}}, {{executive_summary}}, {{supplier_table}}, {{pricing_table}}, {{product_benchmark}}, {{image_benchmark}}, {{seo_keywords}}, {{strategy_recommendations}}, {{sources}}

**Section sources**
- [SKILL.md:318-357](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L318-L357)