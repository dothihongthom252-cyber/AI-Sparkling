# Development and Customization

<cite>
**Referenced Files in This Document**
- [render.py](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py)
- [Template.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html)
- [Gom_su_VietNam.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html)
- [SKILL.md](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md)
- [openai.yaml](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)
10. [Appendices](#appendices)

## Introduction
This document provides development and customization guidelines for the Alibaba B2B Expert system. It explains how to safely modify templates while preserving structural integrity and visual consistency, how to create custom industry adaptations using the established template inheritance patterns, and how to integrate new industries or report formats. It also documents the relationship between template structure requirements and the Python rendering engine capabilities, and offers practical examples and troubleshooting guidance for advanced customization scenarios.

## Project Structure
The repository centers around a reusable HTML template and a Python rendering engine that enforces strict template protection rules and structural validation. The key elements are:
- A premium visual template used as a reference for structure and styling
- A specialized template for a specific industry (Vietnam ceramics)
- A Python script that renders reports from JSON data into validated HTML outputs
- Agent configuration that orchestrates report generation and delivery

```mermaid
graph TB
subgraph "Templates"
T["Template.html<br/>Reference structure and styling"]
V["Gom_su_VietNam.html<br/>Industry-specific sample"]
end
subgraph "Engine"
R["render.py<br/>Rendering, validation, protection"]
end
subgraph "Agent"
A["openai.yaml<br/>Interface and policy"]
S["SKILL.md<br/>Rules, modes, structure, protection"]
end
A --> S
S --> R
R --> T
R --> V
```

**Diagram sources**
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)

**Section sources**
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)

## Core Components
- Rendering Engine: Reads a template and JSON data, replaces placeholders, writes output, validates structure, and enforces template protection.
- Templates: A reference template defines the structural and visual framework; an industry-specific template demonstrates content adaptation.
- Agent and Skill: Define execution modes, report structure, and strict protection rules for template usage.

Key responsibilities:
- Safe rendering and validation
- Structural and visual preservation
- Template integrity enforcement
- Industry adaptation and placeholder replacement

**Section sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [SKILL.md:293-303](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L293-L303)

## Architecture Overview
The system uses a pipeline where the agent orchestrates report generation, the renderer applies data to templates, and validation ensures structural and protection rules are met.

```mermaid
sequenceDiagram
participant Agent as "Agent"
participant Skill as "SKILL Rules"
participant Renderer as "render.py"
participant Tpl as "Template.html"
participant Ind as "Industry Template"
participant Out as "Output HTML"
Agent->>Skill : "Request report for industry"
Skill-->>Agent : "Execution mode, structure, protection rules"
Agent->>Renderer : "Render with template and JSON"
Renderer->>Tpl : "Read reference template"
Renderer->>Ind : "Optionally read industry template"
Renderer->>Renderer : "Replace placeholders"
Renderer->>Renderer : "Validate structure and protection"
Renderer-->>Out : "Write validated HTML"
Out-->>Agent : "Report ready"
```

**Diagram sources**
- [SKILL.md:100-160](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L100-L160)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

## Detailed Component Analysis

### Rendering Engine (render.py)
Responsibilities:
- Read template and JSON data
- Replace placeholders with data values
- Write output HTML
- Validate structural elements and absence of unreplaced placeholders
- Enforce template protection (no overwriting templates, MD5 integrity check)
- Guardrails against unsafe output locations

Processing logic highlights:
- Placeholder replacement uses uppercase keys and supports lists/dicts by converting to JSON-like strings
- Structural validation checks for all seven sections, CSS block presence, sidebar structure, and unreplaced placeholders
- Integrity checks compute MD5 before and after rendering and reject modifications to the template file
- Output path validation prevents writing into the template directory

```mermaid
flowchart TD
Start(["Start"]) --> ReadTpl["Read template file"]
ReadTpl --> ReadJSON["Read JSON data"]
ReadJSON --> Replace["Replace placeholders"]
Replace --> Write["Write output HTML"]
Write --> Validate["Validate structure and placeholders"]
Validate --> Integrity["Check template MD5"]
Integrity --> Guard["Guard output path"]
Guard --> Done(["Done"])
```

**Diagram sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

**Section sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

### Template Structure Requirements
The system enforces a strict 7-section structure and preserves:
- Sidebar navigation
- Header and footer branding
- CSS styles and layout
- Grid and card layouts
- Chart containers
- JavaScript functions and modals

Protection rules:
- Assets templates are read-only
- Outputs must go to a designated reports directory
- Structural elements must remain identical
- Placeholders must be replaced with real data
- Industry-specific content must be adapted without altering structure

```mermaid
classDiagram
class Template {
+sidebar
+header
+sections[7]
+charts
+modals
+styles
}
class IndustryTemplate {
+industry_content
+charts_data
+tables
}
class Output {
+validated_html
+structural_lock
+protection_rules
}
Template <|-- IndustryTemplate
Template --> Output : "rendered into"
```

**Diagram sources**
- [Template.html:99-218](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L99-L218)
- [Gom_su_VietNam.html:131-1048](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L131-L1048)
- [SKILL.md:293-303](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L293-L303)

**Section sources**
- [Template.html:99-218](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L99-L218)
- [Gom_su_VietNam.html:131-1048](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L131-L1048)
- [SKILL.md:293-303](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L293-L303)

### Extension Points and Customization Best Practices
- Use the reference template as the structural and visual baseline
- Replace only placeholders and industry-specific content
- Maintain section order and structural elements
- Keep CSS, layout, and JavaScript intact
- Translate section titles to match the industry
- Add data rows within existing table/grid structures
- Avoid inventing content; verify all claims

Recommended placeholder map:
- Report metadata and industry context
- Executive summary and strategy recommendations
- Supplier landscape, product benchmark, pricing intelligence
- SEO keyword map and buyer persona
- Sources and references

**Section sources**
- [SKILL.md:318-337](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L318-L337)
- [Template.html:132-194](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L132-L194)
- [Gom_su_VietNam.html:165-1023](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L165-L1023)

### Creating Custom Industry Adaptations
Follow the industry adaptation flow:
- Identify the requested industry and build a dynamic industry profile
- Replace report title, meta text, sidebar section names, and all industry wording
- Replace all industry-specific content (suppliers, products, charts, keywords, recommendations)
- Keep premium visual structure and interaction style
- Preserve structural lock and protection rules

```mermaid
flowchart TD
A["Identify Industry"] --> B["Build Industry Profile"]
B --> C["Select Template"]
C --> D["Replace Placeholders"]
D --> E["Validate Structure"]
E --> F["Save to Reports Directory"]
```

**Diagram sources**
- [SKILL.md:54-66](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L54-L66)
- [SKILL.md:254-265](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L254-L265)

**Section sources**
- [SKILL.md:54-66](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L54-L66)
- [SKILL.md:254-265](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L254-L265)

### Integration Mechanisms for New Industries or Report Formats
- Use the workspace sample template when available; otherwise use the reference template
- For new report formats (e.g., DOCX), mirror the premium HTML structure in a clean layout
- Preserve brand colors, typography, and pagination when using a template
- Keep source URLs in tables or footnotes
- Use compact matrices for supplier, product, pricing, and keyword data

**Section sources**
- [SKILL.md:349-356](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L349-L356)
- [SKILL.md:338-348](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L338-L348)

### Relationship Between Template Structure and Rendering Engine Capabilities
- The renderer expects placeholders to be replaced and validates structural elements
- The reference template defines the layout and JavaScript functions; the renderer does not modify them
- Charts and modals rely on Chart.js and DOM elements defined in the template
- The renderer supports lists/dicts by converting them to JSON-like strings for JavaScript/Chart.js consumption

**Section sources**
- [render.py:18-27](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L18-L27)
- [Template.html:230-260](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L230-L260)
- [Gom_su_VietNam.html:1148-1252](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1148-L1252)

### Practical Examples of Template Customization
- Replace industry-specific suppliers and products with verified data
- Adapt pricing intelligence tables and charts to reflect correct units and MOQ logic
- Translate section titles and content to match the new industry
- Keep all structural elements identical (sidebar, section order, header/footer, grid layout)

Examples in the reference template demonstrate:
- Supplier showcase grids and tables
- Product benchmark tables with images and links
- Pricing intelligence charts and tables
- SEO insights and action plans

**Section sources**
- [Gom_su_VietNam.html:208-369](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L208-L369)
- [Gom_su_VietNam.html:709-927](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L709-L927)
- [Gom_su_VietNam.html:953-1004](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L953-L1004)
- [Gom_su_VietNam.html:1007-1023](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1007-L1023)

### Advanced Customization Scenarios
- Custom placeholder definitions: Extend the placeholder map to support new fields (e.g., buyer persona, export strategy angles)
- Enhanced data validation: Add pre-render checks for data completeness and consistency
- Integration with external data sources: Fetch and merge data from APIs or databases before rendering
- Dynamic chart generation: Use Chart.js datasets derived from JSON data to populate charts

**Section sources**
- [render.py:41-87](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L87)
- [Template.html:11-95](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L11-L95)
- [Gom_su_VietNam.html:1148-1252](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1148-L1252)

## Dependency Analysis
The rendering engine depends on:
- Template files for structure and styling
- JSON data for placeholder replacement
- Chart.js for visualizations (when present)
- File system for reading/writing

```mermaid
graph LR
JSON["JSON Data"] --> Engine["render.py"]
RefTpl["Template.html"] --> Engine
IndTpl["Gom_su_VietNam.html"] --> Engine
Engine --> HTML["Output HTML"]
Engine --> Validator["Validation Checks"]
Engine --> Guard["Template Protection"]
```

**Diagram sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)

**Section sources**
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

## Performance Considerations
- Minimize unnecessary DOM manipulations in JavaScript; rely on Chart.js initialization
- Keep JSON data compact and avoid large nested structures unless needed for charts
- Use responsive grid layouts to reduce rendering overhead on mobile devices
- Cache frequently accessed template sections to avoid repeated reads
- Validate early to fail fast and avoid expensive post-processing

## Troubleshooting Guide
Common issues and resolutions:
- Overwriting templates: The renderer prevents writing into the template directory; ensure output goes to the reports directory
- Modified template file: MD5 integrity check rejects changes; revert to the original template
- Unreplaced placeholders: Validation detects remaining placeholders; replace all placeholders with real data
- Missing structural elements: Validation checks for all seven sections, CSS block, and sidebar; ensure these elements are preserved
- Chart.js failures: If Chart.js is unavailable, keep content static; the renderer gracefully handles missing JavaScript

**Section sources**
- [render.py:110-144](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L110-L144)
- [render.py:41-87](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L87)

## Conclusion
The Alibaba B2B Expert system provides a robust framework for creating industry-adaptive, visually consistent HTML reports. By adhering to the template protection rules, preserving structural integrity, and following the customization best practices outlined here, developers can confidently extend the system to new industries and formats while maintaining quality and reliability.

## Appendices
- Agent interface and policy configuration
- Skill rules for execution modes, report structure, and protection

**Section sources**
- [openai.yaml:1-8](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/agents/openai.yaml#L1-L8)
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)