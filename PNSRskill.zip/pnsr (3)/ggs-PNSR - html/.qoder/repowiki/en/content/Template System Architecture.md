# Template System Architecture

<cite>
**Referenced Files in This Document**
- [Template.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html)
- [Gom_su_VietNam.html](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html)
- [render.py](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py)
- [SKILL.md](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md)
</cite>

## Table of Contents
1. [Introduction](#introduction)
2. [Project Structure](#project-structure)
3. [Core Components](#core-components)
4. [Architecture Overview](#architecture-overview)
5. [Detailed Component Analysis](#detailed-component-analysis)
6. [Dependency Analysis](#dependency-analysis)
7. [Performance Considerations](#performance-considerations)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Conclusion](#conclusion)

## Introduction

The Alibaba B2B Expert template system architecture represents a sophisticated template inheritance model designed for generating premium HTML reports for Vietnamese exporters and B2B suppliers. This system combines a reference template with a robust rendering engine to ensure structural integrity while enabling industry-specific content adaptation.

The template system operates on three fundamental pillars: template inheritance, structural validation, and protection mechanisms. The architecture preserves the premium visual design while allowing safe data replacement through a controlled placeholder system and strict template protection rules.

## Project Structure

The template system is organized around a minimal yet powerful file structure that separates concerns between template definition, rendering logic, and operational documentation.

```mermaid
graph TB
subgraph "Template System Structure"
Assets[assets/templates/] --> Template[Template.html]
Assets --> Reference[Gom_su_VietNam.html]
Assets --> Renderer[render.py]
subgraph "Workspace Templates"
Workspace[b2b-reports/] --> Sample[Bao_cao_mau_Alibaba.html]
end
subgraph "Documentation"
Skill[SKILL.md] --> Rules[Template Rules]
Skill --> Workflow[Report Workflow]
Skill --> Requirements[Section Requirements]
end
Template -.-> Renderer
Reference -.-> Renderer
Renderer --> Workspace
Renderer --> Skill
end
```

**Diagram sources**
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)

**Section sources**
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)

## Core Components

### Template Inheritance Model

The template system implements a hierarchical inheritance pattern where the base template serves as the foundation for all generated reports. The architecture establishes a clear separation between structural elements and content placeholders.

```mermaid
classDiagram
class BaseTemplate {
+String template_type
+Array sections
+Object styling_system
+Array validation_rules
+render(data) String
+validate() Boolean
+protect() Boolean
}
class ReferenceTemplate {
+String industry_focus
+Array supplier_data
+Array product_data
+Array chart_configurations
+generate_report() String
}
class RenderingEngine {
+String template_path
+Object data_source
+String output_path
+process_template() String
+validate_output() Boolean
+protect_source() Boolean
}
class ValidationSystem {
+Array structural_checks
+Array css_validations
+Array placeholder_verifications
+perform_validation() Boolean
}
BaseTemplate <|-- ReferenceTemplate
RenderingEngine --> BaseTemplate : "inherits from"
RenderingEngine --> ValidationSystem : "uses"
ReferenceTemplate --> RenderingEngine : "processed by"
```

**Diagram sources**
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

### Template Protection Mechanisms

The system enforces strict protection rules to prevent modification of source templates while allowing safe data replacement. These mechanisms ensure template integrity throughout the generation process.

**Section sources**
- [render.py:90-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L90-L145)
- [SKILL.md:293-303](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L293-L303)

## Architecture Overview

The template system architecture follows a multi-layered approach that separates template definition, data processing, and validation into distinct but interconnected components.

```mermaid
sequenceDiagram
participant Client as "Report Generator"
participant Renderer as "Rendering Engine"
participant Validator as "Validation System"
participant Template as "Source Template"
participant Output as "Generated Report"
Client->>Renderer : render_report_safe(template_path, json_data, output_path)
Renderer->>Renderer : compute_md5(template_path)
Renderer->>Template : read template content
Renderer->>Renderer : populate placeholders
Renderer->>Output : write processed HTML
Renderer->>Validator : validate_structure(output)
Validator->>Validator : check section markers
Validator->>Validator : verify CSS preservation
Validator->>Validator : validate sidebar structure
Validator->>Validator : check placeholder replacement
Validator-->>Renderer : validation results
Renderer->>Renderer : validate_template_unchanged()
Renderer-->>Client : success/failure
Note over Renderer,Validator : Template protection enforced
Note over Template,Output : Source template remains unchanged
```

**Diagram sources**
- [render.py:110-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L110-L145)
- [render.py:41-87](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L87)

### Structural Validation Framework

The validation system performs comprehensive checks to ensure the generated report maintains structural integrity and visual consistency with the reference template.

```mermaid
flowchart TD
Start([Validation Process]) --> LoadOutput["Load Generated HTML"]
LoadOutput --> CheckSections["Check Section Markers<br/>(7 sections present)"]
CheckSections --> SectionsOK{"All Sections Found?"}
SectionsOK --> |No| FailSections["Fail: Missing Sections"]
SectionsOK --> |Yes| CheckCSS["Verify CSS Preservation<br/>(style block intact)"]
CheckCSS --> CSSOK{"CSS Preserved?"}
CSSOK --> |No| FailCSS["Fail: CSS Missing"]
CSSOK --> |Yes| CheckSidebar["Validate Sidebar Structure<br/>(navigation preserved)"]
CheckSidebar --> SidebarOK{"Sidebar Intact?"}
SidebarOK --> |No| FailSidebar["Fail: Sidebar Modified"]
SidebarOK --> |Yes| CheckPlaceholders["Find Unreplaced Placeholders"]
CheckPlaceholders --> PlaceholderOK{"All Placeholders Replaced?"}
PlaceholderOK --> |No| FailPlaceholders["Fail: Unreplaced Tags"]
PlaceholderOK --> |Yes| CheckTemplate["Verify Template Integrity<br/>(MD5 unchanged)"]
CheckTemplate --> TemplateOK{"Template Unchanged?"}
TemplateOK --> |No| FailTemplate["Fail: Template Modified"]
TemplateOK --> |Yes| Success["Validation Passed"]
FailSections --> End([Validation Failed])
FailCSS --> End
FailSidebar --> End
FailPlaceholders --> End
FailTemplate --> End
Success --> End
```

**Diagram sources**
- [render.py:41-87](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L87)
- [render.py:90-99](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L90-L99)

**Section sources**
- [render.py:41-87](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L87)
- [render.py:90-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L90-L145)

## Detailed Component Analysis

### Base Template Structure (Template.html)

The base template serves as the foundational structure for all generated reports, establishing the premium visual design and layout framework.

#### CSS Preservation System

The template implements a comprehensive CSS preservation mechanism that maintains the premium visual identity across all generated reports.

```mermaid
graph LR
subgraph "CSS Preservation Elements"
RootVars[:root Variables<br/>--p, --s, --g, --bg]
LayoutStyles[Layout Styles<br/>.sidebar, .main-content]
CardStyles[Card Styles<br/>.section-card, .info-card]
Typography[Typography<br/>.title, .section-title]
Responsive[Responsive<br/>.grid-2, .grid-3]
end
RootVars --> LayoutStyles
LayoutStyles --> CardStyles
CardStyles --> Typography
Typography --> Responsive
subgraph "Visual Consistency"
Colors[Brand Colors<br/>Deep Blue, Royal Blue, Golden Yellow]
Spacing[Consistent Spacing<br/>2.5rem padding, 12px border radius]
Shadows[Shadow Effects<br/>box-shadow, backdrop-filter]
Transitions[Smooth Transitions<br/>all 0.3s ease]
end
Colors --> Spacing
Spacing --> Shadows
Shadows --> Transitions
```

**Diagram sources**
- [Template.html:13-24](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L13-L24)
- [Template.html:28-95](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L28-L95)

#### Section Structure Framework

The template defines a rigid 7-section framework that provides consistent reporting structure across all industries.

**Section sources**
- [Template.html:132-194](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L132-L194)
- [Template.html:195-216](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L195-L216)

### Reference Template (Gom_su_VietNam.html)

The reference template serves as the premium visual model and demonstrates the complete implementation of the template system's capabilities.

#### Industry-Specific Content Adaptation

The reference template showcases how industry-specific content can be seamlessly integrated while maintaining structural integrity.

```mermaid
graph TB
subgraph "Reference Template Components"
Header[Header Banner<br/>Executive Summary]
Sidebar[Navigation Sidebar<br/>7 Chapters]
SupplierSection[Supplier Landscape<br/>10+ verified suppliers]
ProductSection[Top Selling Products<br/>20+ products]
PricingSection[Pricing Intelligence<br/>FOB comparisons]
ImageSection[Image Analysis<br/>Benchmarking]
SEOSection[SEO Recommendations<br/>Action plan]
Footer[Footer Section<br/>Sources & Contact]
end
Header --> Sidebar
Sidebar --> SupplierSection
SupplierSection --> ProductSection
ProductSection --> PricingSection
PricingSection --> ImageSection
ImageSection --> SEOSection
SEOSection --> Footer
```

**Diagram sources**
- [Gom_su_VietNam.html:153-163](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L153-L163)
- [Gom_su_VietNam.html:203-704](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L203-L704)

#### Data Replacement Patterns

The reference template demonstrates various data replacement patterns that enable industry adaptation while preserving structure.

**Section sources**
- [Gom_su_VietNam.html:165-186](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L165-L186)
- [Gom_su_VietNam.html:706-928](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L706-L928)

### Rendering Engine (render.py)

The rendering engine provides the core functionality for template processing, data replacement, and validation.

#### Placeholder System Implementation

The placeholder system enables flexible data replacement while maintaining template structure integrity.

```mermaid
flowchart LR
subgraph "Placeholder Processing"
Input[JSON Data] --> Extract[Extract Key-Value Pairs]
Extract --> Transform[Transform Keys to Uppercase]
Transform --> Replace[Replace Placeholders]
Replace --> Output[Processed HTML]
end
subgraph "Data Types Handling"
Primitive[Primitive Values<br/>Strings, Numbers]
List[List Data<br/>JavaScript Arrays]
Dict[Dictionary Data<br/>JavaScript Objects]
end
Primitive --> Replace
List --> Replace
Dict --> Replace
```

**Diagram sources**
- [render.py:18-27](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L18-L27)

#### Safety and Protection Mechanisms

The rendering engine implements multiple safety mechanisms to prevent template corruption and ensure output integrity.

**Section sources**
- [render.py:110-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L110-L145)
- [render.py:90-99](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L90-L99)

### Template Protection Rules

The system enforces strict protection rules to prevent unauthorized modifications to source templates.

#### Output Location Restrictions

The template protection system implements output location restrictions to ensure reports are generated in designated directories.

```mermaid
flowchart TD
Start([Template Generation Request]) --> CheckLocation["Check Output Directory"]
CheckLocation --> ComparePaths["Compare Template vs Output Paths"]
ComparePaths --> SameDir{"Same Directory?"}
SameDir --> |Yes| BlockGeneration["Block Generation<br/>Raise ValueError"]
SameDir --> |No| ComputeHash["Compute Template Hash"]
ComputeHash --> ProcessTemplate["Process Template<br/>with Data"]
ProcessTemplate --> ValidateOutput["Validate Generated Output"]
ValidateOutput --> CheckTemplate["Verify Template Unchanged"]
CheckTemplate --> TemplateOK{"Template Intact?"}
TemplateOK --> |No| FailTemplate["Fail: Template Modified"]
TemplateOK --> |Yes| Complete["Complete Successfully"]
BlockGeneration --> End([Operation Blocked])
FailTemplate --> End
Complete --> End
```

**Diagram sources**
- [render.py:110-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L110-L145)

**Section sources**
- [render.py:110-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L110-L145)
- [SKILL.md:293-303](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L293-L303)

## Dependency Analysis

The template system exhibits a well-structured dependency hierarchy that promotes modularity and maintainability.

```mermaid
graph TB
subgraph "Primary Dependencies"
TemplateHTML[Template.html] --> RenderEngine[render.py]
ReferenceHTML[Gom_su_VietNam.html] --> RenderEngine
RenderEngine --> ValidationSystem[Validation Functions]
RenderEngine --> SecurityChecks[Security Checks]
end
subgraph "External Dependencies"
ChartJS[Chart.js CDN] --> TemplateHTML
FontCDN[Google Fonts CDN] --> TemplateHTML
FontAwesomeCDN[FontAwesome CDN] --> TemplateHTML
end
subgraph "Internal Dependencies"
ValidationSystem --> TemplateHTML
ValidationSystem --> ReferenceHTML
SecurityChecks --> TemplateHTML
SecurityChecks --> ReferenceHTML
end
subgraph "Documentation Dependencies"
SKILLDoc[SKILL.md] --> TemplateRules[Template Rules]
SKILLDoc --> WorkflowRules[Workflow Rules]
TemplateRules --> RenderEngine
WorkflowRules --> RenderEngine
end
```

**Diagram sources**
- [Template.html:8-11](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L8-L11)
- [render.py:1-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L1-L157)
- [SKILL.md:1-468](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/SKILL.md#L1-L468)

### Template Relationship Between Base and Reference

The relationship between the base Template.html and the premium Gom_su_VietNam.html reference template demonstrates the inheritance model in action.

```mermaid
classDiagram
class TemplateBase {
<<abstract>>
+String title
+Array sections
+Object styling
+validateStructure() Boolean
+preserveCSS() Boolean
+checkSidebar() Boolean
}
class GomSuVietNam {
+String industry
+Array suppliers
+Array products
+Array charts
+generateReport() String
+benchmarkAnalysis() Object
+pricingIntelligence() Object
}
class RenderEngine {
+processTemplate() String
+validateOutput() Boolean
+protectSource() Boolean
+replacePlaceholders() String
}
TemplateBase <|-- GomSuVietNam
RenderEngine --> TemplateBase : "processes"
RenderEngine --> GomSuVietNam : "uses for reference"
```

**Diagram sources**
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

**Section sources**
- [Template.html:1-263](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Template.html#L1-L263)
- [Gom_su_VietNam.html:1-1256](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/Gom_su_VietNam.html#L1-L1256)
- [render.py:8-157](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L8-L157)

## Performance Considerations

The template system is designed with performance optimization in mind, particularly for handling large datasets and complex visualizations.

### Memory Management

The rendering engine implements efficient memory management strategies to handle large template files and extensive data replacement operations.

### Validation Performance

The validation system employs optimized regular expression patterns and targeted checks to minimize processing overhead while maintaining comprehensive validation coverage.

### Template Processing Efficiency

The placeholder replacement mechanism uses efficient string replacement algorithms and handles different data types appropriately to optimize processing speed.

## Troubleshooting Guide

### Common Issues and Solutions

#### Template Modification Detection

The system includes robust detection mechanisms for unauthorized template modifications:

- **Issue**: Template hash mismatch during validation
- **Cause**: Source template file was modified
- **Solution**: Restore original template file or regenerate from source

#### Output Location Conflicts

The system prevents accidental overwriting of template files:

- **Issue**: ValueError about output path in template directory
- **Cause**: Attempting to save report to the same directory as source template
- **Solution**: Specify output directory outside of assets/templates/

#### Structural Validation Failures

Common structural validation failures and their resolutions:

- **Missing Section Markers**: Ensure all 7 sections are present in generated report
- **CSS Preservation Issues**: Verify style block integrity and external CDN accessibility
- **Sidebar Structure Problems**: Check navigation element preservation
- **Unreplaced Placeholders**: Review JSON data completeness and placeholder naming consistency

**Section sources**
- [render.py:41-87](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L41-L87)
- [render.py:110-145](file://ggs-Alibaba-B2B-Expert/ggs-Alibaba-B2B-Expert/assets/templates/render.py#L110-L145)

## Conclusion

The Alibaba B2B Expert template system architecture represents a sophisticated approach to template inheritance and validation in the context of premium HTML report generation. The system successfully balances flexibility with structural integrity, enabling industry-specific content adaptation while maintaining the premium visual design and layout framework.

Key achievements of the architecture include:

- **Robust Template Protection**: Multiple layers of protection prevent unauthorized template modifications
- **Flexible Data Replacement**: Comprehensive placeholder system enables seamless industry adaptation
- **Comprehensive Validation**: Multi-stage validation ensures structural and content integrity
- **Performance Optimization**: Efficient processing mechanisms handle complex template operations
- **Scalable Architecture**: Modular design supports easy maintenance and extension

The system's adherence to strict template protection rules and validation protocols ensures that generated reports consistently maintain the premium visual identity while accommodating diverse industry requirements. This architecture provides a solid foundation for scalable report generation across multiple industries while preserving the high-quality visual standards established by the reference template.